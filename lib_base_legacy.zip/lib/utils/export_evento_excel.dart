// [Archivo FINAL: lib/utils/export_evento_excel.dart]
import 'dart:typed_data';
import 'package:excel/excel.dart';
import 'package:file_saver/file_saver.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/evento_model.dart';
import '../models/servicio_realizado_model.dart';

Future<void> exportarResumenEvento(EventoModel evento) async {
  final registrosSnap = await FirebaseFirestore.instance
      .collection('eventos')
      .doc(evento.id)
      .collection('registros')
      .get();

  final registros = registrosSnap.docs
      .map((e) => ServicioRealizadoModel.fromMap(e.data(), e.id))
      .toList();

  final Excel excel = Excel.createExcel();
  final Sheet sheet = excel['Resumen'];

  // 🟣 Encabezado general del evento
  sheet.appendRow(['Resumen del Evento']);
  sheet.appendRow(['Nombre:', evento.nombre]);
  sheet.appendRow(['Empresa:', evento.empresa]);
  sheet.appendRow(['Ubicación:', evento.ubicacion]);
  sheet.appendRow(['Fecha:', evento.fecha.toIso8601String()]);
  sheet.appendRow([]);
  sheet.appendRow(['Total de registros:', registros.length.toString()]);
  sheet.appendRow([]);

  // 🟢 Combinaciones Servicio + Profesional
  sheet.appendRow(['Combinaciones Servicio + Profesional']);
  sheet.appendRow(['Servicio ID', 'Profesional ID', 'Cantidad']);

  final Map<String, int> conteo = {};

  for (var r in registros) {
    final clave = '${r.servicioId} | ${r.profesionalId}';
    conteo[clave] = (conteo[clave] ?? 0) + 1;
  }

  for (final entrada in conteo.entries) {
    final partes = entrada.key.split('|');
    sheet.appendRow([partes[0].trim(), partes[1].trim(), entrada.value]);
  }

  sheet.appendRow([]);
  sheet.appendRow(['Encuestas']);

  // 🟡 Preguntas de encuesta
  List<String> preguntas = ['preg0', 'preg1', 'preg2', 'preg3', 'preg4'];
  Map<String, List<double>> notas = {
    for (var key in preguntas) key: [],
  };
  List<String> comentarios = [];

  for (var r in registros) {
    if (r.encuesta != null) {
      for (var key in preguntas) {
        final valor = r.encuesta![key];
        if (valor != null && valor is String) {
          notas[key]?.add(_parseEstrellas(valor));
        }
      }
      final coment = r.encuesta?['comentario'];
      if (coment != null && (coment as String).trim().isNotEmpty) {
        comentarios.add(coment.trim());
      }
    }
  }

  sheet.appendRow(['Pregunta', 'Promedio']);

  for (var key in preguntas) {
    final promedio = notas[key]!.isEmpty
        ? 0.0
        : (notas[key]!.reduce((a, b) => a + b) / notas[key]!.length);
    sheet.appendRow([key, promedio.toStringAsFixed(2)]);
  }

  sheet.appendRow([]);
  sheet.appendRow(['Comentarios']);
  for (var coment in comentarios) {
    sheet.appendRow([coment]);
  }

  // ✅ Guardar archivo con extensión .xlsx (sin mimeType)
  final List<int>? fileBytes = excel.save();
  if (fileBytes == null) return;

  final Uint8List bytes = Uint8List.fromList(fileBytes);

  await FileSaver.instance.saveFile(
    name: 'resumen_evento_${evento.id}',
    bytes: bytes,
    ext: 'xlsx',
  );
}

double _parseEstrellas(String estrella) {
  switch (estrella.trim()) {
    case '⭐':
      return 1.0;
    case '⭐⭐':
      return 2.0;
    case '⭐⭐⭐':
      return 3.0;
    case '⭐⭐⭐⭐':
      return 4.0;
    case '⭐⭐⭐⭐⭐':
      return 5.0;
    default:
      return 0.0;
  }
}
