// [Archivo: lib/utils/qr_pdf_utils.dart]

import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class QRPdfGenerator {
  static Future<void> generarQRComoPDF({
    required BuildContext context,
    required String url,
    required String servicio,
    required String profesional,
  }) async {
    // 🔄 Mostrar mensaje de carga
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Generando PDF, por favor espera...'),
        duration: Duration(seconds: 2),
      ),
    );

    final doc = pw.Document();

    // Tipografías profesionales
    final font = await PdfGoogleFonts.poppinsRegular();
    final boldFont = await PdfGoogleFonts.poppinsSemiBold();

    // Cargar logo
    final ByteData logoBytes =
        await rootBundle.load('assets/images/logo_kym_black.png');
    final Uint8List logoData = logoBytes.buffer.asUint8List();

    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(40),
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              pw.Image(pw.MemoryImage(logoData), height: 80),
              pw.SizedBox(height: 24),
              pw.Text('Registro de servicio',
                  style: pw.TextStyle(font: boldFont, fontSize: 18)),
              pw.SizedBox(height: 16),
              pw.Text('Servicio: $servicio',
                  style: pw.TextStyle(font: font, fontSize: 14)),
              pw.Text('Profesional: $profesional',
                  style: pw.TextStyle(font: font, fontSize: 14)),
              pw.SizedBox(height: 30),
              pw.BarcodeWidget(
                data: url,
                barcode: pw.Barcode.qrCode(),
                width: 200,
                height: 200,
              ),
              pw.SizedBox(height: 20),
              pw.Text(url,
                  textAlign: pw.TextAlign.center,
                  style: pw.TextStyle(font: font, fontSize: 10)),
            ],
          );
        },
      ),
    );

    // ✅ Mostrar confirmación visual
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('✅ PDF generado correctamente'),
        duration: Duration(seconds: 2),
      ),
    );

    // 📤 Mostrar en nueva ventana / impresión
    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => doc.save(),
    );
  }
}
