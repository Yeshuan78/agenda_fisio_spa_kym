// [Archivo: lib/utils/export_evento_pdf.dart]
import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/evento_model.dart';
import '../models/servicio_realizado_model.dart';

Future<void> exportarEventoComoPDF(EventoModel evento) async {
  final doc = pw.Document();

  // Cargar logo institucional
  final ByteData logoData =
      await rootBundle.load('assets/images/logo_kym_black.png');
  final Uint8List logoBytes = logoData.buffer.asUint8List();

  // Leer registros del evento desde Firestore
  final snap = await FirebaseFirestore.instance
      .collection('eventos')
      .doc(evento.id)
      .collection('registros')
      .get();

  final registros = snap.docs
      .map((e) => ServicioRealizadoModel.fromMap(e.data(), e.id))
      .toList();

  final servicios = <String, int>{};
  final profesionales = <String, int>{};
  final combinaciones = <String, int>{};
  final comentarios = <String>[];
  final preguntas = ['preg0', 'preg1', 'preg2', 'preg3', 'preg4'];
  final Map<String, List<double>> notas = {
    for (var key in preguntas) key: [],
  };

  for (var r in registros) {
    final comb = '${r.servicioId} | ${r.profesionalId}';
    combinaciones[comb] = (combinaciones[comb] ?? 0) + 1;
    servicios[r.servicioId] = (servicios[r.servicioId] ?? 0) + 1;
    profesionales[r.profesionalId] = (profesionales[r.profesionalId] ?? 0) + 1;

    if (r.encuesta != null) {
      for (var key in preguntas) {
        final val = r.encuesta![key];
        if (val != null && val is String) {
          notas[key]!.add(_parseEstrellas(val));
        }
      }
      final coment = r.encuesta?['comentario'];
      if (coment != null && (coment as String).trim().isNotEmpty) {
        comentarios.add(coment.trim());
      }
    }
  }

  // Generar página PDF
  doc.addPage(pw.Page(
    pageFormat: PdfPageFormat.a4,
    margin: const pw.EdgeInsets.all(40),
    build: (_) {
      return pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Center(
            child: pw.Image(pw.MemoryImage(logoBytes), height: 70),
          ),
          pw.SizedBox(height: 20),
          pw.Text('Resumen del Evento',
              style:
                  pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 12),
          pw.Text('🗓️ ${evento.nombre}',
              style: const pw.TextStyle(fontSize: 14)),
          pw.Text('🏢 Empresa: ${evento.empresa}'),
          pw.Text('📍 Ubicación: ${evento.ubicacion}'),
          pw.Text(
              '📆 Fecha: ${evento.fecha.day.toString().padLeft(2, '0')}/${evento.fecha.month.toString().padLeft(2, '0')}/${evento.fecha.year}'),
          pw.SizedBox(height: 20),
          pw.Text('📊 Totales',
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          pw.Bullet(text: 'Registros escaneados: ${registros.length}'),
          pw.Bullet(text: 'Servicios involucrados: ${servicios.length}'),
          pw.Bullet(text: 'Profesionales asignados: ${profesionales.length}'),
          pw.Bullet(text: 'Combinaciones únicas: ${combinaciones.length}'),
          pw.SizedBox(height: 16),
          pw.Text('📌 Combinaciones Servicio + Profesional',
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          pw.Table.fromTextArray(
            headers: ['Servicio ID', 'Profesional ID', 'Cantidad'],
            data: combinaciones.entries.map((e) {
              final partes = e.key.split('|');
              return [partes[0].trim(), partes[1].trim(), e.value.toString()];
            }).toList(),
            headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            cellPadding:
                const pw.EdgeInsets.symmetric(vertical: 4, horizontal: 6),
          ),
          pw.SizedBox(height: 20),
          pw.Text('⭐ Resultados de encuesta',
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 6),
          pw.Table.fromTextArray(
            headers: ['Pregunta', 'Promedio'],
            data: preguntas.map((key) {
              final promedio = notas[key]!.isEmpty
                  ? 0.0
                  : (notas[key]!.reduce((a, b) => a + b) / notas[key]!.length);
              return [key, promedio.toStringAsFixed(2)];
            }).toList(),
            headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            cellPadding:
                const pw.EdgeInsets.symmetric(vertical: 4, horizontal: 6),
          ),
          pw.SizedBox(height: 20),
          if (comentarios.isNotEmpty)
            pw.Column(children: [
              pw.Text('💬 Comentarios recibidos:',
                  style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 8),
              ...comentarios.map((c) => pw.Padding(
                    padding: const pw.EdgeInsets.only(bottom: 6),
                    child: pw.Text('- $c',
                        style: const pw.TextStyle(fontSize: 11)),
                  )),
            ])
        ],
      );
    },
  ));

  // Mostrar diálogo de impresión / descarga
  await Printing.layoutPdf(
    onLayout: (PdfPageFormat format) async => doc.save(),
  );
}

double _parseEstrellas(String estrella) {
  switch (estrella.trim()) {
    case '⭐':
      return 1.0;
    case '⭐⭐':
      return 2.0;
    case '⭐⭐⭐':
      return 3.0;
    case '⭐⭐⭐⭐':
      return 4.0;
    case '⭐⭐⭐⭐⭐':
      return 5.0;
    default:
      return 0.0;
  }
}
