import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/evento_model.dart';

class EventoService {
  final _db = FirebaseFirestore.instance;

  Future<List<EventoModel>> getEventos() async {
    final query = await _db
        .collection('eventos')
        .orderBy('fecha', descending: true)
        .get();

    return query.docs.map((doc) {
      return EventoModel.fromMap(doc.data() as Map<String, dynamic>, doc.id);
    }).toList();
  }

  Future<void> createEvento(EventoModel evento) async {
    final ref = _db.collection('eventos').doc(evento.id);
    await ref.set(evento.toMap()); // ✅ eventoId y empresaId ya incluidos
  }

  Future<void> updateEvento(EventoModel evento) async {
    final ref = _db.collection('eventos').doc(evento.id);
    await ref.update(evento.toMap());
  }

  Future<void> deleteEvento(String eventoId) async {
    await _db.collection('eventos').doc(eventoId).delete();
  }

  Future<EventoModel?> getEventoById(String eventoId) async {
    final doc = await _db.collection('eventos').doc(eventoId).get();
    if (!doc.exists) return null;
    return EventoModel.fromMap(doc.data() as Map<String, dynamic>, doc.id);
  }

  Future<List<EventoModel>> getEventosFiltrados({String? empresaId}) async {
    Query query = _db.collection('eventos');

    if (empresaId != null && empresaId.isNotEmpty) {
      query = query.where('empresaId', isEqualTo: empresaId); // ✅ correcto
    }

    query = query.orderBy('fecha', descending: true);
    final snapshot = await query.get();

    return snapshot.docs
        .map((doc) =>
            EventoModel.fromMap(doc.data() as Map<String, dynamic>, doc.id))
        .toList();
  }
}
