import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/servicio_model.dart';

class ServicioService {
  final _db = FirebaseFirestore.instance;

  // Obtener todos los servicios
  Future<List<ServicioModel>> getServicios() async {
    final query = await _db.collection('services').orderBy('name').get();
    return query.docs.map((doc) {
      final data = doc.data();
      return ServicioModel.fromMap(data);
    }).toList();
  }

  // Crear un nuevo servicio
  Future<void> crearServicio(ServicioModel servicio) async {
    await _db
        .collection('services')
        .doc(servicio.serviceId)
        .set(servicio.toMap());
  }

  // Actualizar un servicio existente
  Future<void> actualizarServicio(ServicioModel servicio) async {
    await _db
        .collection('services')
        .doc(servicio.serviceId)
        .update(servicio.toMap());
  }

  // Eliminar un servicio por ID
  Future<void> eliminarServicio(String serviceId) async {
    await _db.collection('services').doc(serviceId).delete();
  }

  // Obtener un solo servicio por ID
  Future<ServicioModel?> getServicioPorId(String serviceId) async {
    final doc = await _db.collection('services').doc(serviceId).get();
    if (!doc.exists) return null;
    return ServicioModel.fromMap(doc.data()!);
  }
}
