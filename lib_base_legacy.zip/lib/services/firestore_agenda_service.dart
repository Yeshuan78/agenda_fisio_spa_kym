import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreAgendaService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<Map<DateTime, List<DocumentSnapshot>>> loadCitas(
      String? profesionalId) async {
    Query<Map<String, dynamic>> query =
        _db.collection('bookings').orderBy('fecha');

    if (profesionalId != null) {
      query = query.where('profesionalId', isEqualTo: profesionalId);
    }

    final snapshot = await query.get();

    final Map<DateTime, List<DocumentSnapshot>> result = {};

    for (var doc in snapshot.docs) {
      final data = doc.data();
      if (!data.containsKey('fecha') || data['fecha'] == null) continue;

      DateTime fecha;

      if (data['fecha'] is Timestamp) {
        fecha = (data['fecha'] as Timestamp).toDate();
      } else if (data['fecha'] is String) {
        fecha = DateTime.tryParse(data['fecha']) ?? DateTime.now();
      } else {
        continue;
      }

      final fechaKey = DateTime(fecha.year, fecha.month, fecha.day);
      result.putIfAbsent(fechaKey, () => []).add(doc);
    }

    return result;
  }

  Future<List<DocumentSnapshot>> loadClients() async {
    final snapshot = await _db.collection('clients').orderBy('nombre').get();
    return snapshot.docs;
  }

  Future<List<DocumentSnapshot>> loadServicesFromCategories() async {
    final snapshot = await _db.collection('services').orderBy('nombre').get();
    return snapshot.docs;
  }

  Future<List<DocumentSnapshot>> loadProfesionalesForm() async {
    final snapshot =
        await _db.collection('profesionales').orderBy('nombre').get();
    return snapshot.docs;
  }

  Future<List<DocumentSnapshot>> loadProfesionalesFiltro() async {
    final snapshot =
        await _db.collection('profesionales').orderBy('nombre').get();
    return snapshot.docs;
  }

  Future<DocumentSnapshot?> buscarClientePorTelefono(String telefono) async {
    final query = await _db
        .collection('clients')
        .where('telefono', isEqualTo: telefono)
        .limit(1)
        .get();

    if (query.docs.isNotEmpty) {
      return query.docs.first;
    }
    return null;
  }

  Future<void> actualizarEstadoCita(
      String bookingId, String nuevoEstado) async {
    await _db.collection('bookings').doc(bookingId).update({
      'estado': nuevoEstado,
    });
  }

  // ✅ Método para cancelar cita (estado = 'cancelado')
  Future<void> cancelarCita(String bookingId) async {
    await _db.collection('bookings').doc(bookingId).update({
      'estado': 'cancelado',
    });
  }

  // ✅ Método original usado por professional_calendar_loader
  Future<Map<String, dynamic>> loadProfesionalCalendar(
      String profesionalId) async {
    final doc = await _db.collection('profesionales').doc(profesionalId).get();
    return doc.data()?['disponibilidad'] ?? {};
  }

  Future<String?> loadProfesionalPhoto(String profesionalId) async {
    final doc = await _db.collection('profesionales').doc(profesionalId).get();
    return doc.data()?['fotoUrl'];
  }
}
