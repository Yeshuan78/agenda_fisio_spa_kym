// clients_screen.dart — PARTE 1 DE 4

import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:csv/csv.dart';
import 'package:excel/excel.dart' as xlsx;
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/widgets/clients_panel.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/widgets/confirm_delete_client_dialog.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/widgets/csv_preview_dialog.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/client_crud_screen.dart';
import 'package:agenda_fisio_spa_kym/services/export_csv.dart';
import 'package:agenda_fisio_spa_kym/models/filter_clients_enum.dart';
import 'package:agenda_fisio_spa_kym/models/resumen_cliente_model.dart'; // ✅ Import necesario

class ClientsScreen extends StatefulWidget {
  const ClientsScreen({super.key});

  @override
  State<ClientsScreen> createState() => _ClientsScreenState();
}

class _ClientsScreenState extends State<ClientsScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _filtroBusqueda = '';
  FiltroClientes _filtroActivo = FiltroClientes.todos;
  List<QueryDocumentSnapshot> _clientesRaw = [];
  List<DocumentSnapshot> _clientesActuales = [];
  Set<String> _seleccionados = {};
  String? _selectedAlcaldia;

  Map<String, ResumenCliente> _resumenesClientes = {}; // ✅ PASO 1

  final List<String> _etiquetasBase = [
    'VIP',
    'Corporativo',
    'Nuevo',
    'Recurrente',
    'Promoción',
    'Consentido',
    'Especial'
  ];

  @override
  void initState() {
    super.initState();
    _recargarClientes();
    _searchController.addListener(() {
      setState(() {
        _filtroBusqueda = _searchController.text.trim().toLowerCase();
      });
    });
  }

  Future<Map<String, ResumenCliente>> _cargarResumenesClientes() async {
    final snapshot =
        await FirebaseFirestore.instance.collection('bookings').get();
    final Map<String, List<Map<String, dynamic>>> agrupadasPorCliente = {};

    for (var doc in snapshot.docs) {
      final data = doc.data();
      final clienteId = data['clienteId'];
      if (clienteId == null || clienteId.isEmpty) continue;
      agrupadasPorCliente.putIfAbsent(clienteId, () => []).add(data);
    }

    final Map<String, ResumenCliente> resumenes = {};

    agrupadasPorCliente.forEach((clienteId, citas) {
      int asistidas = 0, noAsistidas = 0, pendientes = 0;
      DateTime? ultima;
      final detalles = <Map<String, dynamic>>[];

      for (var c in citas) {
        final estado = (c['estado'] ?? '').toString().toLowerCase();
        final rawFecha = c['fecha'];
        DateTime? fecha;
        if (rawFecha is Timestamp) {
          fecha = rawFecha.toDate();
        } else if (rawFecha is String) {
          try {
            fecha = DateTime.parse(rawFecha);
          } catch (_) {
            fecha = null;
          }
        }

        if (estado == 'cita_realizada')
          asistidas++;
        else if (estado == 'cancelado')
          noAsistidas++;
        else
          pendientes++;

        if (fecha != null && (ultima == null || fecha.isAfter(ultima))) {
          ultima = fecha;
        }

        detalles.add({
          'fecha': fecha,
          'estado': estado,
          'profesional': c['profesionalNombre'] ?? '',
          'notas': c['comentariosTexto'] ?? '',
        });
      }

      resumenes[clienteId] = ResumenCliente(
        asistidas: asistidas,
        noAsistidas: noAsistidas,
        pendientes: pendientes,
        ultimaCita: ultima,
        detalleUltimasCitas: detalles.take(5).toList(),
      );
    });

    return resumenes;
  }

  Future<void> _recargarClientes() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('clients')
        .orderBy('nombre')
        .get();

    final resumenes = await _cargarResumenesClientes();

    if (!mounted) return;
    setState(() {
      _clientesRaw = snapshot.docs;
      _resumenesClientes = resumenes;
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _toggleSeleccion(String clienteId) {
    setState(() {
      if (_seleccionados.contains(clienteId)) {
        _seleccionados.remove(clienteId);
      } else {
        _seleccionados.add(clienteId);
      }
    });
  }

  Future<void> _crearNuevoCliente() async {
    final resultado = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const ClientCrudScreen(),
      ),
    );

    if (resultado == true && mounted) {
      await _recargarClientes();
      setState(() {
        _filtroBusqueda = '';
        _filtroActivo = FiltroClientes.todos;
        _selectedAlcaldia = null;
        _searchController.clear();
        _clientesActuales = _clientesRaw;
      });
    }
  }

  Future<void> _editarCliente(DocumentSnapshot cliente) async {
    final resultado = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ClientCrudScreen(cliente: cliente),
      ),
    );

    if (resultado == true && mounted) {
      await _recargarClientes();
      setState(() {
        _filtroBusqueda = '';
        _filtroActivo = FiltroClientes.todos;
        _selectedAlcaldia = null;
        _searchController.clear();
        _clientesActuales = _clientesRaw;
      });
    }
  }

  Future<void> _eliminarCliente(String clienteId) async {
    final confirmar = await ConfirmDeleteClientDialog.mostrar(
      context: context,
      titulo: '¿Eliminar cliente?',
      mensaje: 'Esta acción no se puede deshacer.',
    );

    if (confirmar) {
      await FirebaseFirestore.instance
          .collection('clients')
          .doc(clienteId)
          .delete();
      await _recargarClientes();
    }
  }

  Future<void> _eliminarSeleccionados() async {
    final confirmar = await ConfirmDeleteClientDialog.mostrar(
      context: context,
      titulo: '¿Eliminar seleccionados?',
      mensaje:
          'Esta acción eliminará a todos los clientes seleccionados. ¿Continuar?',
    );

    if (confirmar) {
      for (final id in _seleccionados) {
        await FirebaseFirestore.instance.collection('clients').doc(id).delete();
      }
      setState(() => _seleccionados.clear());
      await _recargarClientes();
    }
  }

  void _exportarCSV(List<Map<String, dynamic>> datos) {
    ExportCSV.generarArchivo(datos, nombreArchivo: 'clientes_exportados');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        backgroundColor: kBrandPurple,
        centerTitle: true,
        title: const Text(
          'Listado de Clientes',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
            letterSpacing: 0.5,
            color: Colors.white,
          ),
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _crearNuevoCliente,
        backgroundColor: kBrandPurple,
        child: const Icon(Icons.add, size: 28, color: Colors.white),
      ),
      body: ClientsPanel(
        searchController: _searchController,
        filtroBusqueda: _filtroBusqueda,
        filtroActivo: _filtroActivo,
        clientesRaw: _clientesRaw,
        clientesActuales: _clientesActuales,
        seleccionados: _seleccionados,
        selectedAlcaldia: _selectedAlcaldia,
        resumenClientes: _resumenesClientes, // ✅ PASO 4 aplicado aquí
        hayFiltrosActivos: _hayFiltrosActivos,
        onFiltroSeleccionado: (f) => setState(() => _filtroActivo = f),
        onAlcaldiaSeleccionada: (a) => setState(() => _selectedAlcaldia = a),
        onResetFiltros: () => setState(() {
          _filtroActivo = FiltroClientes.todos;
          _selectedAlcaldia = null;
          _searchController.clear();
        }),
        onImportar: _importarDesdeCSV,
        onExportar: _exportarCSV,
        onSeleccionarTodo: (selectAll) {
          setState(() {
            if (selectAll) {
              _seleccionados = _clientesActuales.map((c) => c.id).toSet();
            } else {
              _seleccionados.clear();
            }
          });
        },
        onEditarCliente: _editarCliente,
        onEliminarCliente: _eliminarCliente,
        toggleSeleccion: _toggleSeleccion,
        onClientesActualizados: (lista) =>
            setState(() => _clientesActuales = lista),
      ),
    );
  }

  Future<void> _importarDesdeCSV() async {
    final resultado = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['csv', 'xlsx'],
    );
    if (resultado != null) {
      final archivo = resultado.files.single;
      final ext = archivo.extension?.toLowerCase();

      if (ext == 'csv') {
        final contenido = utf8.decode(archivo.bytes!);
        await _procesarCSV(contenido);
      } else if (ext == 'xlsx') {
        await _procesarXLSX(archivo.bytes!);
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('❌ Formato no compatible')),
        );
      }
    }
  }

  Future<void> _procesarCSV(String rawCSV) async {
    final List<List<dynamic>> filas =
        const CsvToListConverter().convert(rawCSV, eol: '\n');

    if (filas.isEmpty || filas.first.length < 4) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('❌ El archivo no tiene el formato esperado')),
      );
      return;
    }

    final encabezados =
        filas.first.map((e) => e.toString().trim().toLowerCase()).toList();
    final List<Map<String, dynamic>> registros = [];

    for (int i = 1; i < filas.length; i++) {
      final fila = filas[i];
      final Map<String, dynamic> registro = {};

      for (int j = 0; j < encabezados.length && j < fila.length; j++) {
        registro[encabezados[j]] = fila[j].toString().trim();
      }

      if (_esRegistroValido(registro)) {
        registros.add(registro);
      }
    }

    await _previsualizarRegistros(registros);
  }

  Future<void> _procesarXLSX(Uint8List rawBytes) async {
    final excel = xlsx.Excel.decodeBytes(rawBytes);
    final sheet = excel.tables.values.first;
    if (sheet == null || sheet.maxRows < 2) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('❌ Excel vacío o mal formado')),
      );
      return;
    }

    final encabezados = sheet.rows.first
        .map((c) => c?.value?.toString().trim().toLowerCase())
        .toList();
    final List<Map<String, dynamic>> registros = [];

    for (int i = 1; i < sheet.rows.length; i++) {
      final fila = sheet.rows[i];
      final Map<String, dynamic> registro = {};

      for (int j = 0; j < encabezados.length && j < fila.length; j++) {
        final valor = fila[j]?.value?.toString().trim() ?? '';
        final key = encabezados[j] ?? '';
        if (key.isNotEmpty) registro[key] = valor;
      }

      if (_esRegistroValido(registro)) {
        registros.add(registro);
      }
    }

    await _previsualizarRegistros(registros);
  }

  bool _esRegistroValido(Map<String, dynamic> r) {
    final nombre = r['nombre'] ?? '';
    final apellidos = r['apellidos'] ?? '';
    final correo = r['correo'] ?? '';
    final telefono = r['telefono'] ?? '';
    return nombre.isNotEmpty &&
        apellidos.isNotEmpty &&
        correo.contains('@') &&
        telefono.length >= 8;
  }

  Future<void> _previsualizarRegistros(
      List<Map<String, dynamic>> registros) async {
    if (registros.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('❌ No se encontraron registros válidos')),
      );
      return;
    }

    final snapshot =
        await FirebaseFirestore.instance.collection('clients').get();
    final existentes =
        snapshot.docs.map((d) => d.data() as Map<String, dynamic>).toList();

    final Set<String> correosExistentes = existentes
        .map((e) => (e['correo'] ?? '').toString().toLowerCase())
        .where((e) => e.isNotEmpty)
        .toSet();

    final Set<String> telefonosExistentes = existentes
        .map((e) => (e['telefono'] ?? '').toString().replaceAll(' ', ''))
        .where((e) => e.isNotEmpty)
        .toSet();

    final List<Map<String, dynamic>> nuevos = [];
    int duplicados = 0;

    for (final r in registros) {
      final correo = (r['correo'] ?? '').toString().toLowerCase();
      final telefono = (r['telefono'] ?? '').toString().replaceAll(' ', '');

      if (correosExistentes.contains(correo) ||
          telefonosExistentes.contains(telefono)) {
        duplicados++;
      } else {
        nuevos.add(r);
      }
    }

    if (nuevos.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('❌ Todos los registros ya existen')),
      );
      return;
    }

    if (!mounted) return;
    final msg = '✅ ${nuevos.length} nuevos. '
        '${duplicados > 0 ? 'Se omitieron $duplicados duplicados.' : ''}';

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

    await mostrarCSVPreviewDialog(
      context: context,
      registrosValidos: nuevos,
      onGuardar: _guardarRegistrosDesdeCSV,
    );
  }

  Future<void> _guardarRegistrosDesdeCSV(
      List<Map<String, dynamic>> registros) async {
    try {
      for (final r in registros) {
        final tiposRaw = (r['tiposcliente'] ?? '').toString().split(',');
        final etiquetasLimpias =
            tiposRaw.map((e) => e.trim()).where((e) => e.isNotEmpty).toList();

        final List<Map<String, dynamic>> tiposCliente = [];
        final List<String> base = etiquetasLimpias
            .where((e) => _etiquetasBase
                .map((b) => b.toLowerCase())
                .contains(e.toLowerCase()))
            .toList();
        final List<String> pers = etiquetasLimpias
            .where((e) => !_etiquetasBase
                .map((b) => b.toLowerCase())
                .contains(e.toLowerCase()))
            .toList();

        for (final b in base) {
          tiposCliente.add({'label': b});
        }

        int colorIndex = 0;
        final List<String> colors = [
          "#7c4dff",
          "#009688",
          "#795548",
          "#3f51b5",
          "#00bcd4",
          "#ff5722",
          "#cddc39",
          "#607d8b",
          "#e91e63",
          "#ffc107"
        ];

        for (final p in pers) {
          final color = colors[colorIndex % colors.length];
          tiposCliente.add({'label': p, 'color': color});
          colorIndex++;
        }

        final nuevoCliente = {
          'nombre': r['nombre'],
          'apellidos': r['apellidos'],
          'correo': r['correo'],
          'telefono': r['telefono'],
          'empresa': r['empresa'] ?? '',
          'calle': r['calle'] ?? '',
          'numeroInterior': r['numerointerior'] ?? '',
          'numeroExterior': r['numeroexterior'] ?? '',
          'colonia': r['colonia'] ?? '',
          'codigoPostal': r['codigopostal'] ?? '',
          'alcaldia': r['alcaldia'] ?? '',
          'tiposCliente': tiposCliente,
          'createdAt': FieldValue.serverTimestamp(),
        };

        await FirebaseFirestore.instance
            .collection('clients')
            .add(nuevoCliente);
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ Clientes importados correctamente')),
      );
      await _recargarClientes();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('❌ Error al guardar: $e')),
      );
    }
  }

  bool _hayFiltrosActivos() {
    return _filtroBusqueda.isNotEmpty ||
        _selectedAlcaldia != null ||
        _filtroActivo != FiltroClientes.todos;
  }
}
