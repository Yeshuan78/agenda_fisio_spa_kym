// clients_panel.dart
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:agenda_fisio_spa_kym/theme/theme.dart';

import 'package:agenda_fisio_spa_kym/screens/clients/widgets/clients_sidebar.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/widgets/clients_toolbar.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/widgets/clients_container.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/widgets/clients_list.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/widgets/selected_clients_summary.dart';

import 'package:agenda_fisio_spa_kym/models/filter_clients_enum.dart';
import 'package:agenda_fisio_spa_kym/models/resumen_cliente_model.dart';

class ClientsPanel extends StatelessWidget {
  final TextEditingController searchController;
  final String filtroBusqueda;
  final FiltroClientes filtroActivo;
  final List<QueryDocumentSnapshot> clientesRaw;
  final List<DocumentSnapshot> clientesActuales;
  final Set<String> seleccionados;
  final String? selectedAlcaldia;
  final bool Function() hayFiltrosActivos;
  final Map<String, ResumenCliente> resumenClientes; // ✅ NUEVO

  final void Function(FiltroClientes filtro) onFiltroSeleccionado;
  final void Function(String? alcaldia) onAlcaldiaSeleccionada;
  final VoidCallback onResetFiltros;
  final VoidCallback onImportar;
  final void Function(List<Map<String, dynamic>> datos) onExportar;
  final void Function(bool seleccionarTodo) onSeleccionarTodo;

  final void Function(DocumentSnapshot cliente) onEditarCliente;
  final void Function(String clienteId) onEliminarCliente;
  final void Function(String clienteId) toggleSeleccion;
  final void Function(List<DocumentSnapshot>) onClientesActualizados;

  const ClientsPanel({
    super.key,
    required this.searchController,
    required this.filtroBusqueda,
    required this.filtroActivo,
    required this.clientesRaw,
    required this.clientesActuales,
    required this.seleccionados,
    required this.selectedAlcaldia,
    required this.hayFiltrosActivos,
    required this.resumenClientes, // ✅ NUEVO
    required this.onFiltroSeleccionado,
    required this.onAlcaldiaSeleccionada,
    required this.onResetFiltros,
    required this.onImportar,
    required this.onExportar,
    required this.onSeleccionarTodo,
    required this.onEditarCliente,
    required this.onEliminarCliente,
    required this.toggleSeleccion,
    required this.onClientesActualizados,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            width: 240,
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: kBrandPurple, width: 1),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: kBrandPurple.withAlpha(13),
                  blurRadius: 6,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ClientsSidebar(
              filtroActual: filtroActivo,
              alcaldiasDisponibles: clientesRaw
                  .map((doc) =>
                      (doc.data() as Map<String, dynamic>)['alcaldia']
                          ?.toString() ??
                      '')
                  .where((a) => a.isNotEmpty)
                  .toSet()
                  .toList(),
              selectedAlcaldia: selectedAlcaldia,
              onFiltroSeleccionado: onFiltroSeleccionado,
              onAlcaldiaSeleccionada: onAlcaldiaSeleccionada,
              onResetFiltros: onResetFiltros,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClientsToolbar(
                  controller: searchController,
                  onImportar: onImportar,
                  onExportar: () {
                    final datos = clientesActuales.map((doc) {
                      final data = doc.data() as Map<String, dynamic>;
                      return {
                        'Nombre':
                            '${data['nombre'] ?? ''} ${data['apellidos'] ?? ''}',
                        'Correo': data['correo'] ?? '',
                        'Teléfono': data['telefono'] ?? '',
                        'Empresa': data['empresa'] ?? '',
                        'Fecha de alta':
                            (data['createdAt'] as Timestamp?) != null
                                ? DateFormat('yyyy-MM-dd').format(
                                    (data['createdAt'] as Timestamp).toDate())
                                : '',
                      };
                    }).toList();
                    onExportar(datos);
                  },
                ),
                const SizedBox(height: 12),
                SelectedClientsSummary(
                  seleccionados: seleccionados,
                  totalClientes: clientesActuales.length,
                  onSeleccionarTodo: onSeleccionarTodo,
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: ClientsContainer(
                    child: ClientsList(
                      filtroBusqueda: filtroBusqueda,
                      selectedAlcaldia: selectedAlcaldia,
                      filtroActivo: filtroActivo,
                      clientesRaw: clientesRaw,
                      resumenClientes: resumenClientes, // ✅ PASADO A LISTA
                      onEditarCliente: onEditarCliente,
                      onEliminarCliente: onEliminarCliente,
                      toggleSeleccion: toggleSeleccion,
                      seleccionados: seleccionados,
                      hayFiltrosActivos: hayFiltrosActivos,
                      onClientesActualizados: onClientesActualizados,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
