// clients_list.dart — Parte 1 de 2
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:agenda_fisio_spa_kym/screens/clients/widgets/client_card.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/models/filter_clients_enum.dart';
import 'package:agenda_fisio_spa_kym/models/resumen_cliente_model.dart';

class ClientsList extends StatelessWidget {
  final String filtroBusqueda;
  final String? selectedAlcaldia;
  final FiltroClientes filtroActivo;
  final List<QueryDocumentSnapshot> clientesRaw;
  final void Function(DocumentSnapshot cliente) onEditarCliente;
  final void Function(String clienteId) onEliminarCliente;
  final void Function(String clienteId) toggleSeleccion;
  final Set<String> seleccionados;
  final bool Function() hayFiltrosActivos;
  final void Function(List<DocumentSnapshot>) onClientesActualizados;

  final Map<String, ResumenCliente> resumenClientes; // ✅ NUEVO

  const ClientsList({
    super.key,
    required this.filtroBusqueda,
    required this.selectedAlcaldia,
    required this.filtroActivo,
    required this.clientesRaw,
    required this.onEditarCliente,
    required this.onEliminarCliente,
    required this.toggleSeleccion,
    required this.seleccionados,
    required this.hayFiltrosActivos,
    required this.onClientesActualizados,
    required this.resumenClientes, // ✅ NUEVO
  });

  Map<String, List<DocumentSnapshot>> _agruparPorAlcaldia(
      List<DocumentSnapshot> clientes) {
    final Map<String, List<DocumentSnapshot>> agrupados = {};
    for (final cliente in clientes) {
      final data = cliente.data() as Map<String, dynamic>;
      final alcaldia = (data['alcaldia'] ?? 'Sin alcaldía').toString();
      agrupados.putIfAbsent(alcaldia, () => []).add(cliente);
    }
    return agrupados;
  }

  @override
  Widget build(BuildContext context) {
    final List<DocumentSnapshot> clientes = clientesRaw;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      onClientesActualizados(clientes);
    });

    if (clientes.isEmpty) {
      return const Center(
        child: Text('No se encontraron clientes que coincidan.'),
      );
    }

    final agrupados = _agruparPorAlcaldia(clientes);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: kBrandPurple, width: 1),
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4)],
      ),
      child: Column(
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              '${clientes.length} clientes encontrados',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 13,
                color: kBrandPurple,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: agrupados.entries.map((entry) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      entry.key,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 6),
                    ...entry.value.map((cliente) {
                      final id = cliente.id;
                      final data = cliente.data() as Map<String, dynamic>;
                      return ClientCard(
                        data: data,
                        onEdit: () => onEditarCliente(cliente),
                        onDelete: () => onEliminarCliente(id),
                        seleccionable: true,
                        seleccionado: seleccionados.contains(id),
                        onSeleccionar: () => toggleSeleccion(id),
                        resumen: resumenClientes[id], // ✅ INTEGRACIÓN
                      );
                    }).toList(),
                    const SizedBox(height: 12),
                  ],
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}
