import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/widgets/hover_card_overlay.dart';

class EstadoHoverChip extends StatelessWidget {
  final Color color;
  final int count;
  final String label;
  final List<Map<String, dynamic>> detalleCitas;

  const EstadoHoverChip({
    super.key,
    required this.color,
    required this.count,
    required this.label,
    required this.detalleCitas,
  });

  @override
  Widget build(BuildContext context) {
    if (count == 0 || detalleCitas.isEmpty) {
      return _buildVisualChip();
    }

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (event) =>
          HoverCardOverlay.show(context, event.position, detalleCitas),
      onExit: (_) => HoverCardOverlay.hide(),
      child: _buildVisualChip(),
    );
  }

  Widget _buildVisualChip() {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 14,
          height: 14,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 6),
        Text(
          '$count',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
        ),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(fontSize: 14)),
      ],
    );
  }
}
