// ===============================================================
// [Parte 1/3] — Imports, definición de StatefulWidget y controladores
// ===============================================================

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';

class ClientFormDialog extends StatefulWidget {
  final DocumentSnapshot? cliente;

  const ClientFormDialog({super.key, this.cliente});

  @override
  State<ClientFormDialog> createState() => _ClientFormDialogState();
}

// ===============================================================
// [Sección 1.2] — Declaraciones de controladores y variables
// ===============================================================

class _ClientFormDialogState extends State<ClientFormDialog> {
  final _formKey = GlobalKey<FormState>();
  final _nombreController = TextEditingController();
  final _apellidosController = TextEditingController();
  final _correoController = TextEditingController();
  final _telefonoController = TextEditingController();
  final _empresaController = TextEditingController();
  final _calleController = TextEditingController();
  final _numeroExteriorController = TextEditingController();
  final _numeroInteriorController = TextEditingController();
  final _codigoPostalController = TextEditingController();
  final _nuevaEtiquetaController = TextEditingController();

  String? _alcaldiaSeleccionada;
  bool _cargando = false;
  bool _guardando = false;

  List<String> _tiposClienteSeleccionados = [];
  final List<String> _opcionesEtiquetas = [
    'VIP',
    'Corporativo',
    'Nuevo',
    'Recurrente',
    'Promoción',
    'Consentido',
    'Especial',
  ];

  final List<String> _opcionesAlcaldias = [
    'Álvaro Obregón',
    'Azcapotzalco',
    'Benito Juárez',
    'Coyoacán',
    'Cuajimalpa de Morelos',
    'Cuauhtémoc',
    'Gustavo A. Madero',
    'Iztacalco',
    'Iztapalapa',
    'La Magdalena Contreras',
    'Miguel Hidalgo',
    'Milpa Alta',
    'Tláhuac',
    'Tlalpan',
    'Venustiano Carranza',
    'Xochimilco',
  ];

  // ===============================================================
  // [Sección 1.3] — initState: inicializar datos si estamos editando
  // ===============================================================
  @override
  void initState() {
    super.initState();
    if (widget.cliente != null) {
      final data = widget.cliente!.data() as Map<String, dynamic>;
      _nombreController.text = data['nombre'] ?? '';
      _apellidosController.text = data['apellidos'] ?? '';
      _correoController.text = data['correo'] ?? '';
      _telefonoController.text = data['telefono'] ?? '';
      _empresaController.text = data['empresa'] ?? '';
      _calleController.text = data['calle'] ?? '';
      _numeroExteriorController.text = data['numeroExterior'] ?? '';
      _numeroInteriorController.text = data['numeroInterior'] ?? '';
      _codigoPostalController.text = data['codigoPostal'] ?? '';
      _alcaldiaSeleccionada = data['alcaldia'];
      _tiposClienteSeleccionados =
          List<String>.from(data['tiposCliente'] ?? []);
    }
  }

  // ===============================================================
  // [Sección 1.4] — Guardar cliente (nuevo o editar existente)
  // ===============================================================
  Future<void> _guardarCliente() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _guardando = true;
    });

    final nuevoCliente = {
      'nombre': _nombreController.text.trim(),
      'apellidos': _apellidosController.text.trim(),
      'correo': _correoController.text.trim(),
      'telefono': _telefonoController.text.trim(),
      'empresa': _empresaController.text.trim(),
      'calle': _calleController.text.trim(),
      'numeroExterior': _numeroExteriorController.text.trim(),
      'numeroInterior': _numeroInteriorController.text.trim(),
      'codigoPostal': _codigoPostalController.text.trim(),
      'alcaldia': _alcaldiaSeleccionada ?? '',
      'tiposCliente': _tiposClienteSeleccionados,
      'idUsuario': FirebaseAuth.instance.currentUser?.uid,
      'createdAt': Timestamp.now(),
    };

    try {
      DocumentReference ref;
      if (widget.cliente != null) {
        await widget.cliente!.reference.update(nuevoCliente);
        ref = widget.cliente!.reference;
      } else {
        ref = await FirebaseFirestore.instance
            .collection('clients')
            .add(nuevoCliente);
      }

      final snapshot = await ref.get();
      if (!mounted) return;

      setState(() {
        _guardando = false;
      });

      await Future.delayed(const Duration(seconds: 1));
      Navigator.of(context).pop(snapshot);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al guardar cliente: $e')),
      );
      setState(() {
        _guardando = false;
      });
    }
  }
// ===============================================================
// [Parte 2/3] — Build completo, Inputs principales del cliente
// ===============================================================

  // ===============================================================
  // [Sección 1.5] — Build Widget
  // ===============================================================
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 60),
      content: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 500),
        child: _cargando
            ? const SizedBox(
                height: 200, child: Center(child: CircularProgressIndicator()))
            : Form(
                key: _formKey,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // ===============================================================
                      // [Sección 1.6] — Inputs principales
                      // ===============================================================
                      TextFormField(
                        controller: _nombreController,
                        decoration: const InputDecoration(labelText: 'Nombre'),
                        validator: (v) => v!.isEmpty ? 'Campo requerido' : null,
                      ),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: _apellidosController,
                        decoration:
                            const InputDecoration(labelText: 'Apellidos'),
                        validator: (v) => v!.isEmpty ? 'Campo requerido' : null,
                      ),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: _correoController,
                        decoration: const InputDecoration(labelText: 'Correo'),
                        keyboardType: TextInputType.emailAddress,
                        validator: (v) {
                          if (v == null || v.trim().isEmpty) {
                            return 'Campo requerido';
                          }
                          final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
                          if (!emailRegex.hasMatch(v.trim())) {
                            return 'Correo no válido';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: _telefonoController,
                        decoration:
                            const InputDecoration(labelText: 'Teléfono'),
                        keyboardType: TextInputType.number,
                        maxLength: 14,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly
                        ],
                        validator: (v) {
                          if (v == null || v.trim().isEmpty) {
                            return 'Campo requerido';
                          }
                          if (v.trim().length > 14) {
                            return 'Máximo 14 dígitos';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: _empresaController,
                        decoration: const InputDecoration(
                            labelText: 'Empresa (opcional)'),
                      ),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: _calleController,
                        decoration: const InputDecoration(labelText: 'Calle'),
                        validator: (v) => v!.isEmpty ? 'Campo requerido' : null,
                      ),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: _numeroExteriorController,
                        decoration:
                            const InputDecoration(labelText: 'Número exterior'),
                        validator: (v) => v!.isEmpty ? 'Campo requerido' : null,
                      ),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: _numeroInteriorController,
                        decoration: const InputDecoration(
                            labelText: 'Número interior (opcional)'),
                      ),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: _codigoPostalController,
                        decoration:
                            const InputDecoration(labelText: 'Código Postal'),
                        keyboardType: TextInputType.number,
                        validator: (v) => v!.isEmpty ? 'Campo requerido' : null,
                      ),
                      const SizedBox(height: 8),
                      DropdownButtonFormField<String>(
                        value:
                            _opcionesAlcaldias.contains(_alcaldiaSeleccionada)
                                ? _alcaldiaSeleccionada
                                : null,
                        items: _opcionesAlcaldias.map((alcaldia) {
                          return DropdownMenuItem(
                            value: alcaldia,
                            child: Text(alcaldia),
                          );
                        }).toList(),
                        onChanged: (valor) {
                          setState(() {
                            _alcaldiaSeleccionada = valor;
                          });
                        },
                        decoration:
                            const InputDecoration(labelText: 'Alcaldía'),
                        validator: (v) => v == null || v.isEmpty
                            ? 'Seleccione una alcaldía'
                            : null,
                      ),
                      const SizedBox(height: 16),
// ===============================================================
// [Parte 3/3] — Nueva Etiqueta, Etiquetas Base, Botones, Dispose
// ===============================================================

                      // ===============================================================
                      // [Sección 1.7] — Campo Nueva Etiqueta Personalizada
                      // ===============================================================
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: _nuevaEtiquetaController,
                              decoration: const InputDecoration(
                                labelText: 'Nueva etiqueta',
                                hintText: 'Ej: Preferente, Gold, etc.',
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          SizedBox(
                            width: 50,
                            child: ElevatedButton(
                              onPressed: () {
                                final nueva =
                                    _nuevaEtiquetaController.text.trim();
                                if (nueva.isNotEmpty &&
                                    !_tiposClienteSeleccionados
                                        .contains(nueva)) {
                                  setState(() {
                                    _tiposClienteSeleccionados.add(nueva);
                                  });
                                  _nuevaEtiquetaController.clear();
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: kBrandPurple,
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 0, vertical: 14),
                              ),
                              child: const Icon(Icons.add,
                                  size: 18, color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // ===============================================================
                      // [Sección 1.8] — Etiquetas Base (FilterChip) y Nuevas (Chip)
                      // ===============================================================
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: _opcionesEtiquetas.map((etiqueta) {
                            final estaSeleccionada =
                                _tiposClienteSeleccionados.contains(etiqueta);

                            Color colorEtiqueta;
                            switch (etiqueta) {
                              case 'VIP':
                                colorEtiqueta = kBrandPurple;
                                break;
                              case 'Corporativo':
                                colorEtiqueta = Colors.blueAccent;
                                break;
                              case 'Nuevo':
                                colorEtiqueta = Colors.green;
                                break;
                              case 'Recurrente':
                                colorEtiqueta = Colors.amber;
                                break;
                              case 'Promoción':
                                colorEtiqueta = Colors.deepOrangeAccent;
                                break;
                              case 'Consentido':
                                colorEtiqueta = Colors.pinkAccent;
                                break;
                              case 'Especial':
                                colorEtiqueta = Colors.redAccent;
                                break;
                              default:
                                colorEtiqueta = kBrandPurple;
                            }

                            return FilterChip(
                              label: Text(
                                etiqueta,
                                style: const TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                              ),
                              selected: estaSeleccionada,
                              selectedColor: colorEtiqueta,
                              backgroundColor: colorEtiqueta.withOpacity(0.5),
                              checkmarkColor: Colors.white,
                              onSelected: (valor) {
                                setState(() {
                                  if (valor) {
                                    _tiposClienteSeleccionados.add(etiqueta);
                                  } else {
                                    _tiposClienteSeleccionados.remove(etiqueta);
                                  }
                                });
                              },
                            );
                          }).toList(),
                        ),
                      ),
                      const SizedBox(height: 16),

                      // 🔵 Etiquetas personalizadas
                      if (_tiposClienteSeleccionados
                          .where((etiqueta) =>
                              !_opcionesEtiquetas.contains(etiqueta))
                          .isNotEmpty)
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: _tiposClienteSeleccionados
                                .where((etiqueta) =>
                                    !_opcionesEtiquetas.contains(etiqueta))
                                .map((etiqueta) {
                              return Chip(
                                label: Text(
                                  etiqueta,
                                  style: const TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                backgroundColor: kBrandPurple.withOpacity(0.1),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                deleteIcon: const Icon(Icons.close, size: 18),
                                onDeleted: () {
                                  setState(() {
                                    _tiposClienteSeleccionados.remove(etiqueta);
                                  });
                                },
                              );
                            }).toList(),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
      ),
      actions: [
        // ===============================================================
        // [Sección 1.9] — Botones Guardar / Cancelar
        // ===============================================================
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text(
            'Cancelar',
            style: TextStyle(color: kBrandPurple),
          ),
        ),
        ElevatedButton(
          onPressed: _guardando ? null : _guardarCliente,
          style: ElevatedButton.styleFrom(
            backgroundColor: kBrandPurple,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
          child: _guardando
              ? const Icon(Icons.check_circle, color: Colors.white, size: 24)
              : const Text('Guardar', style: TextStyle(fontSize: 15)),
        ),
      ],
    );
  }

  // ===============================================================
  // [Sección 1.10] — Dispose: liberar controladores
  // ===============================================================
  @override
  void dispose() {
    _nombreController.dispose();
    _apellidosController.dispose();
    _correoController.dispose();
    _telefonoController.dispose();
    _empresaController.dispose();
    _calleController.dispose();
    _numeroExteriorController.dispose();
    _numeroInteriorController.dispose();
    _codigoPostalController.dispose();
    _nuevaEtiquetaController.dispose();
    super.dispose();
  }
}
