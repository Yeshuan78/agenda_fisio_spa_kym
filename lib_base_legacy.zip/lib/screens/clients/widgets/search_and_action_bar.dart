// search_and_action_bar.dart

import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';

class SearchAndActionBar extends StatelessWidget {
  final TextEditingController searchController;
  final Set<String> seleccionados;
  final List<dynamic> clientesRaw;
  final VoidCallback onExportarTodo;
  final VoidCallback onExportarSeleccionados;
  final VoidCallback onEliminarSeleccionados;

  const SearchAndActionBar({
    super.key,
    required this.searchController,
    required this.seleccionados,
    required this.clientesRaw,
    required this.onExportarTodo,
    required this.onExportarSeleccionados,
    required this.onEliminarSeleccionados,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: TextField(
            controller: searchController,
            decoration: const InputDecoration(
              hintText: 'Buscar por nombre, empresa, correo o teléfono',
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(8)),
              ),
              filled: true,
              fillColor: Colors.white,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Row(
              children: [
                if (seleccionados.isEmpty) ...[
                  SizedBox(
                    width: 180,
                    height: 42,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kAccentBlue,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      icon: const Icon(Icons.download),
                      label: const Text('Exportar Todo'),
                      onPressed: onExportarTodo,
                    ),
                  ),
                ] else ...[
                  Row(
                    children: [
                      SizedBox(
                        width: 180,
                        height: 42,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.orange,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          icon: const Icon(Icons.download),
                          label: const Text('Exportar Seleccionados'),
                          onPressed: onExportarSeleccionados,
                        ),
                      ),
                      const SizedBox(width: 8),
                      SizedBox(
                        width: 180,
                        height: 42,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          icon: const Icon(Icons.delete),
                          label: const Text('Eliminar Seleccionados'),
                          onPressed: onEliminarSeleccionados,
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ],
        ),
      ],
    );
  }
}
