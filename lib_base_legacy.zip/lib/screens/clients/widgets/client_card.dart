import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/models/resumen_cliente_model.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/widgets/estado_hover_chip.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class ClientCard extends StatelessWidget {
  final Map<String, dynamic> data;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final bool seleccionable;
  final bool seleccionado;
  final VoidCallback? onSeleccionar;
  final ResumenCliente? resumen;

  ClientCard({
    super.key,
    required this.data,
    required this.onEdit,
    required this.onDelete,
    this.seleccionable = false,
    this.seleccionado = false,
    this.onSeleccionar,
    this.resumen,
  });

  final List<String> _etiquetasBase = [
    'VIP',
    'Corporativo',
    'Nuevo',
    'Recurrente',
    'Promoción',
    'Consentido',
    'Especial'
  ];

  final List<Color> _paletaPersonalizadas = [
    Colors.deepPurpleAccent,
    Colors.teal,
    Colors.brown,
    Colors.indigo,
    Colors.cyan,
    Colors.deepOrange,
    Colors.lime,
    Colors.blueGrey,
    Colors.pinkAccent,
    Colors.amberAccent,
  ];

  Color _colorEtiquetaBase(String etiqueta) {
    switch (etiqueta.toLowerCase()) {
      case 'vip':
        return kBrandPurple;
      case 'corporativo':
        return kAccentBlue;
      case 'nuevo':
        return Colors.green;
      case 'recurrente':
        return Colors.amber;
      case 'promoción':
        return Colors.orangeAccent;
      case 'consentido':
        return Colors.pinkAccent;
      case 'especial':
        return Colors.redAccent;
      default:
        return kBrandPurple;
    }
  }

  Map<String, Color> _mapearColoresUnicos(List<String> etiquetas) {
    final Map<String, Color> resultado = {};
    int colorIndex = 0;

    for (var e in etiquetas) {
      if (!resultado.containsKey(e)) {
        resultado[e] =
            _paletaPersonalizadas[colorIndex % _paletaPersonalizadas.length]
                .withAlpha(38);
        colorIndex++;
      }
    }
    return resultado;
  }

  @override
  Widget build(BuildContext context) {
    final nombre = '${data['nombre'] ?? ''} ${data['apellidos'] ?? ''}'.trim();
    final empresa = (data['empresa'] ?? '').toString();
    final correo = (data['correo'] ?? '').toString();
    final telefono = (data['telefono'] ?? '').toString();

    final calle = (data['calle'] ?? '').toString();
    final numeroExterior = (data['numeroExterior'] ?? '').toString();
    final numeroInterior = (data['numeroInterior'] ?? '').toString();
    final colonia = (data['colonia'] ?? '').toString();
    final alcaldia = (data['alcaldia'] ?? '').toString();
    final cp = (data['codigoPostal'] ?? '').toString();

    final direccion = [
      if (calle.isNotEmpty) calle,
      if (numeroExterior.isNotEmpty) 'No. Ext $numeroExterior',
      if (numeroInterior.isNotEmpty) 'Int $numeroInterior',
      if (colonia.isNotEmpty) colonia,
      if (alcaldia.isNotEmpty) alcaldia,
      if (cp.isNotEmpty) 'CP $cp',
    ].join(', ');
    final tiposRaw = List.from(data['tiposCliente'] ?? []);
    final tiposCliente = tiposRaw
        .map((e) => e is String ? e : (e['label'] ?? '').toString())
        .where((e) => e.toString().isNotEmpty)
        .toList();
    final etiquetasBase = tiposCliente
        .where((e) => _etiquetasBase
            .map((b) => b.toLowerCase())
            .contains(e.toLowerCase()))
        .toList();

    final etiquetasPersonalizadas = tiposCliente
        .where((e) => !_etiquetasBase
            .map((b) => b.toLowerCase())
            .contains(e.toLowerCase()))
        .toList();

    final Map<String, Color> coloresPersonalizados =
        _mapearColoresUnicos(etiquetasPersonalizadas);

    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: kBrandPurple, width: 1),
      ),
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 40,
              child: Checkbox(
                value: seleccionado,
                onChanged: (_) => onSeleccionar?.call(),
                visualDensity: VisualDensity.compact,
              ),
            ),
            const Icon(Icons.person_outline, size: 24, color: kBrandPurple),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    nombre,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                  if (empresa.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Row(
                        children: [
                          const Icon(Icons.business,
                              size: 14, color: Colors.black45),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              empresa,
                              style: const TextStyle(
                                  fontSize: 13, color: Colors.black54),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  if (correo.isNotEmpty || telefono.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Row(
                        children: [
                          if (correo.isNotEmpty)
                            Row(
                              children: [
                                const Icon(Icons.email_outlined,
                                    size: 13, color: Colors.black45),
                                const SizedBox(width: 3),
                                Text(correo,
                                    style: const TextStyle(fontSize: 12)),
                              ],
                            ),
                          if (correo.isNotEmpty && telefono.isNotEmpty)
                            const SizedBox(width: 12),
                          if (telefono.isNotEmpty)
                            Row(
                              children: [
                                const Icon(Icons.phone_android,
                                    size: 13, color: Colors.black45),
                                const SizedBox(width: 3),
                                Text(telefono,
                                    style: const TextStyle(fontSize: 12)),
                              ],
                            ),
                        ],
                      ),
                    ),
                  if (direccion.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.location_on_outlined,
                              size: 13, color: Colors.black45),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              direccion,
                              style: const TextStyle(fontSize: 12),
                            ),
                          ),
                        ],
                      ),
                    ),
                  if (tiposCliente.isNotEmpty) const SizedBox(height: 8),
                  if (tiposCliente.isNotEmpty)
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        ...etiquetasBase.map(
                          (e) => Chip(
                            label: Text(
                              e,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 11),
                            ),
                            backgroundColor:
                                _colorEtiquetaBase(e).withAlpha(230),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            materialTapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                          ),
                        ),
                        ...etiquetasPersonalizadas.map(
                          (e) => Chip(
                            label: Text(
                              e,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.black87,
                                fontSize: 11,
                              ),
                            ),
                            backgroundColor: coloresPersonalizados[e]!,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            materialTapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                          ),
                        ),
                      ],
                    ),
                ],
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          EstadoHoverChip(
                            color: Colors.blue,
                            count: resumen?.asistidas ?? 0,
                            label: 'Reservadas',
                            detalleCitas: resumen?.detalleUltimasCitas
                                    ?.where((c) => c['estado'] == 'Reservada')
                                    .toList() ??
                                [],
                          ),
                          const SizedBox(width: 12),
                          EstadoHoverChip(
                            color: Colors.amber,
                            count: resumen?.noAsistidas ?? 0,
                            label: 'Confirmadas',
                            detalleCitas: resumen?.detalleUltimasCitas
                                    ?.where((c) => c['estado'] == 'Confirmada')
                                    .toList() ??
                                [],
                          ),
                          const SizedBox(width: 12),
                          EstadoHoverChip(
                            color: Colors.green,
                            count: resumen?.asistidas ?? 0,
                            label: 'Asistidas',
                            detalleCitas: resumen?.detalleUltimasCitas
                                    ?.where((c) => c['estado'] == 'Asistida')
                                    .toList() ??
                                [],
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          EstadoHoverChip(
                            color: Colors.red,
                            count: resumen?.noAsistidas ?? 0,
                            label: 'Canceladas',
                            detalleCitas: resumen?.detalleUltimasCitas
                                    ?.where((c) => c['estado'] == 'Cancelada')
                                    .toList() ??
                                [],
                          ),
                          const SizedBox(width: 12),
                          EstadoHoverChip(
                            color: Colors.orange,
                            count: resumen?.noAsistidas ?? 0,
                            label: 'No asistidas',
                            detalleCitas: resumen?.detalleUltimasCitas
                                    ?.where((c) => c['estado'] == 'No asistida')
                                    .toList() ??
                                [],
                          ),
                          const SizedBox(width: 12),
                          EstadoHoverChip(
                            color: Colors.pink,
                            count: resumen?.pendientes ?? 0,
                            label: 'Pendientes',
                            detalleCitas: resumen?.detalleUltimasCitas
                                    ?.where((c) => c['estado'] == 'Pendiente')
                                    .toList() ??
                                [],
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(width: 8),
                  Column(
                    children: [
                      IconButton(
                        icon: const FaIcon(FontAwesomeIcons.penToSquare,
                            size: 15, color: Colors.green),
                        onPressed: onEdit,
                        tooltip: 'Editar',
                      ),
                      IconButton(
                        icon: const FaIcon(FontAwesomeIcons.trashCan,
                            size: 15, color: Colors.red),
                        onPressed: onDelete,
                        tooltip: 'Eliminar',
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
