// clients_toolbar.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';

class ClientsToolbar extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onImportar;
  final VoidCallback onExportar;

  const ClientsToolbar({
    super.key,
    required this.controller,
    required this.onImportar,
    required this.onExportar,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: controller,
            decoration: const InputDecoration(
              hintText: 'Buscar por nombre, empresa, correo o teléfono',
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(8)),
              ),
              filled: true,
              fillColor: Colors.white,
            ),
          ),
        ),
        const SizedBox(width: 12),
        SizedBox(
          width: 160,
          height: 42,
          child: ElevatedButton.icon(
            onPressed: onImportar,
            icon: const Icon(Icons.upload_file),
            label: const Text('Importar CSV/XLSX'),
            style: ElevatedButton.styleFrom(
              backgroundColor: kBrandPurple.withAlpha(180),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        SizedBox(
          width: 160,
          height: 42,
          child: ElevatedButton.icon(
            onPressed: onExportar,
            icon: const Icon(Icons.download),
            label: const Text('Exportar Todo'),
            style: ElevatedButton.styleFrom(
              backgroundColor: kAccentBlue,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
