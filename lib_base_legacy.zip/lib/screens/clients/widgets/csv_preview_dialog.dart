// [Sección 1.1] – csv_preview_dialog.dart
import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';

Future<void> mostrarCSVPreviewDialog({
  required BuildContext context,
  required List<Map<String, dynamic>> registrosValidos,
  required Function(List<Map<String, dynamic>> datos) onGuardar,
}) async {
  await showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: Text(
          'Vista previa (${registrosValidos.length} válidos)',
          style:
              const TextStyle(fontWeight: FontWeight.bold, color: kBrandPurple),
        ),
        content: SizedBox(
          width: 600,
          height: 400,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              headingRowColor:
                  MaterialStateProperty.all(kBrandPurple.withAlpha(30)),
              columns: const [
                DataColumn(label: Text('Nombre')),
                DataColumn(label: Text('Apellidos')),
                DataColumn(label: Text('Correo')),
                DataColumn(label: Text('Teléfono')),
                DataColumn(label: Text('Empresa')),
              ],
              rows: registrosValidos.map((registro) {
                return DataRow(
                  cells: [
                    DataCell(Text(registro['nombre'] ?? '')),
                    DataCell(Text(registro['apellidos'] ?? '')),
                    DataCell(Text(registro['correo'] ?? '')),
                    DataCell(Text(registro['telefono'] ?? '')),
                    DataCell(Text(registro['empresa'] ?? '')),
                  ],
                );
              }).toList(),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              onGuardar(registrosValidos);
            },
            child: const Text('Guardar'),
          ),
        ],
      );
    },
  );
}
