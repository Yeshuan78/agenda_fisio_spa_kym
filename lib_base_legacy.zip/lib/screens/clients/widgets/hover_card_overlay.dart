import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class HoverCardOverlay {
  static OverlayEntry? _overlayEntry;

  static void show(BuildContext context, Offset position,
      List<Map<String, dynamic>> detalleCitas) {
    hide();

    final overlay = Overlay.of(context);
    if (overlay == null) return;

    _overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        left: position.dx + 12,
        top: position.dy + 12,
        child: Material(
          elevation: 4,
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 280,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              boxShadow: const [
                BoxShadow(
                  blurRadius: 8,
                  color: Colors.black26,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: detalleCitas.take(5).map((cita) {
                final fecha = cita['fecha'] is DateTime
                    ? cita['fecha']
                    : cita['fecha'].toDate();
                final fechaStr = DateFormat('dd/MM/yyyy – HH:mm').format(fecha);
                final estado = cita['estado'] ?? '-';
                final profesional = cita['profesional'] ?? '-';

                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Text(
                    '$fechaStr\n$estado | $profesional',
                    style: const TextStyle(fontSize: 13),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
      ),
    );

    overlay.insert(_overlayEntry!);
  }

  static void hide() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }
}
