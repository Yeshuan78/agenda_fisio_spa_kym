// selected_clients_summary.dart

import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';

class SelectedClientsSummary extends StatelessWidget {
  final Set<String> seleccionados;
  final int totalClientes;
  final void Function(bool) onSeleccionarTodo;

  const SelectedClientsSummary({
    super.key,
    required this.seleccionados,
    required this.totalClientes,
    required this.onSeleccionarTodo,
  });

  @override
  Widget build(BuildContext context) {
    if (seleccionados.isEmpty) return const SizedBox.shrink();

    final bool todosSeleccionados =
        seleccionados.length == totalClientes && totalClientes > 0;

    return Padding(
      padding: const EdgeInsets.only(top: 12, bottom: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            '${seleccionados.length} clientes seleccionados',
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: kBrandPurple,
            ),
          ),
          StatefulBuilder(
            builder: (context, setState) {
              return Row(
                children: [
                  Checkbox(
                    value: todosSeleccionados,
                    onChanged: (val) {
                      onSeleccionarTodo(val ?? false);
                      // 🔥 No hacemos setState local aquí porque el padre actualizará
                    },
                    visualDensity: VisualDensity.compact,
                    side: const BorderSide(color: kBrandPurple, width: 2),
                  ),
                  const Text(
                    'Seleccionar todo',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: kBrandPurple,
                    ),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}
