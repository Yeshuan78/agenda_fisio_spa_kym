// clients_sidebar.dart — Parte 1 de 2 (BASE FIEL, SOLO COLOR ALCALDÍAS)

import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/models/filter_clients_enum.dart';

class ClientsSidebar extends StatelessWidget {
  final FiltroClientes filtroActual;
  final void Function(FiltroClientes) onFiltroSeleccionado;
  final String? selectedAlcaldia;
  final List<String> alcaldiasDisponibles;
  final void Function(String?) onAlcaldiaSeleccionada;
  final VoidCallback onResetFiltros;

  const ClientsSidebar({
    super.key,
    required this.filtroActual,
    required this.alcaldiasDisponibles,
    required this.selectedAlcaldia,
    required this.onFiltroSeleccionado,
    required this.onAlcaldiaSeleccionada,
    required this.onResetFiltros,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Filtros',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 12),
          _buildFiltroButton(context, FiltroClientes.todos, 'Todos'),
          _buildFiltroButton(context, FiltroClientes.activos, 'Corporativos'),
          _buildFiltroButton(context, FiltroClientes.inactivos, 'Incompletos'),
          const SizedBox(height: 10),
          const Divider(),
          const SizedBox(height: 8),
          _buildAlcaldiaSection(context),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: onResetFiltros,
              icon: const Icon(Icons.refresh, size: 16),
              label: const Text('Reiniciar Filtros'),
              style: ElevatedButton.styleFrom(
                backgroundColor: kBrandPurple,
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(40),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
// clients_sidebar.dart — Parte 2 de 2 (BASE FIEL, SOLO COLOR ALCALDÍAS)

  Widget _buildFiltroButton(
      BuildContext context, FiltroClientes filtro, String nombre) {
    final bool isSelected = filtro == filtroActual;
    final IconData icono = _getIconoFiltro(filtro);

    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      child: Align(
        alignment: Alignment.center,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 220),
          child: OutlinedButton(
            onPressed: () => onFiltroSeleccionado(filtro),
            style: OutlinedButton.styleFrom(
              backgroundColor:
                  isSelected ? kBrandPurple.withAlpha(26) : Colors.transparent,
              foregroundColor: kBrandPurple,
              side: const BorderSide(color: kBrandPurple, width: 1),
              minimumSize: const Size.fromHeight(38),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
            ).copyWith(
              overlayColor: WidgetStateProperty.all(
                kBrandPurple.withValues(
                  alpha: 255,
                  red: 220,
                  green: 220,
                  blue: 255,
                ),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icono, size: 18),
                const SizedBox(width: 8),
                Text(
                  nombre,
                  style: const TextStyle(
                      fontSize: 13, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAlcaldiaSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Alcaldía',
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: alcaldiasDisponibles.map((alcaldia) {
            final isSelected = selectedAlcaldia == alcaldia;
            return ChoiceChip(
              label: Text(
                alcaldia,
                style: TextStyle(
                  fontSize: 11,
                  color: isSelected ? Colors.white : Colors.blue.shade600,
                ),
              ),
              selected: isSelected,
              selectedColor: Colors.blue.shade600,
              backgroundColor: Colors.blue.shade50,
              shape: StadiumBorder(
                side: BorderSide(
                  color:
                      isSelected ? Colors.blue.shade600 : Colors.blue.shade600,
                  width: 1.5,
                ),
              ),
              onSelected: (selected) {
                onAlcaldiaSeleccionada(selected ? alcaldia : null);
              },
            );
          }).toList(),
        ),
      ],
    );
  }

  IconData _getIconoFiltro(FiltroClientes filtro) {
    switch (filtro) {
      case FiltroClientes.todos:
        return Icons.group;
      case FiltroClientes.activos:
        return Icons.business_center;
      case FiltroClientes.inactivos:
        return Icons.error_outline;
      default:
        return Icons.filter_list;
    }
  }
}
