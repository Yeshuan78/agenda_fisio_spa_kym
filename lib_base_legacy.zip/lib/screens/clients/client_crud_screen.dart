// client_crud_screen.dart — PARTE 1 DE 4 (con FocusNode + Fix pop)

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';

class ClientCrudScreen extends StatefulWidget {
  final DocumentSnapshot? cliente;
  const ClientCrudScreen({super.key, this.cliente});

  @override
  State<ClientCrudScreen> createState() => _ClientCrudScreenState();
}

class _ClientCrudScreenState extends State<ClientCrudScreen> {
  final _formKey = GlobalKey<FormState>();

  final _nombreController = TextEditingController();
  final _apellidosController = TextEditingController();
  final _correoController = TextEditingController();
  final _telefonoController = TextEditingController();
  final _empresaController = TextEditingController();
  final _calleController = TextEditingController();
  final _numeroInteriorController = TextEditingController();
  final _numeroExteriorController = TextEditingController();
  final _coloniaController = TextEditingController();
  final _codigoPostalController = TextEditingController();
  final _nuevaEtiquetaController = TextEditingController();

  // 🔧 FocusNodes en orden de tabulación
  final _focusNombre = FocusNode();
  final _focusApellidos = FocusNode();
  final _focusCorreo = FocusNode();
  final _focusTelefono = FocusNode();
  final _focusEmpresa = FocusNode();
  final _focusCalle = FocusNode();
  final _focusNumExt = FocusNode();
  final _focusNumInt = FocusNode();
  final _focusColonia = FocusNode();
  final _focusCP = FocusNode();

  String? _alcaldiaSeleccionada;

  final List<String> _etiquetasBase = [
    'VIP',
    'Corporativo',
    'Nuevo',
    'Recurrente',
    'Promoción',
    'Consentido',
    'Especial'
  ];
  final Set<String> _etiquetasBaseSeleccionadas = {};
  final List<String> _etiquetasPersonalizadas = [];

  @override
  void initState() {
    super.initState();
    if (widget.cliente != null) {
      final data = widget.cliente!.data() as Map<String, dynamic>;
      _nombreController.text = data['nombre'] ?? '';
      _apellidosController.text = data['apellidos'] ?? '';
      _correoController.text = data['correo'] ?? '';
      _telefonoController.text = data['telefono'] ?? '';
      _empresaController.text = data['empresa'] ?? '';
      _calleController.text = data['calle'] ?? '';
      _numeroInteriorController.text = data['numeroInterior'] ?? '';
      _numeroExteriorController.text = data['numeroExterior'] ?? '';
      _coloniaController.text = data['colonia'] ?? '';
      _codigoPostalController.text = data['codigoPostal'] ?? '';
      _alcaldiaSeleccionada = data['alcaldia'];

      final etiquetas = List<dynamic>.from(data['tiposCliente'] ?? []);
      for (final e in etiquetas) {
        final label = e is String ? e : e['label'] ?? '';
        if (_etiquetasBase
            .map((b) => b.toLowerCase())
            .contains(label.toLowerCase())) {
          _etiquetasBaseSeleccionadas.add(_etiquetasBase
              .firstWhere((b) => b.toLowerCase() == label.toLowerCase()));
        } else if (label.toString().isNotEmpty) {
          _etiquetasPersonalizadas.add(label);
        }
      }
    }
  }

  @override
  void dispose() {
    _nombreController.dispose();
    _apellidosController.dispose();
    _correoController.dispose();
    _telefonoController.dispose();
    _empresaController.dispose();
    _calleController.dispose();
    _numeroInteriorController.dispose();
    _numeroExteriorController.dispose();
    _coloniaController.dispose();
    _codigoPostalController.dispose();
    _nuevaEtiquetaController.dispose();

    // 🔧 Liberar focus
    _focusNombre.dispose();
    _focusApellidos.dispose();
    _focusCorreo.dispose();
    _focusTelefono.dispose();
    _focusEmpresa.dispose();
    _focusCalle.dispose();
    _focusNumExt.dispose();
    _focusNumInt.dispose();
    _focusColonia.dispose();
    _focusCP.dispose();

    super.dispose();
  }

  void _guardarCliente() async {
    if (!_formKey.currentState!.validate()) return;

    try {
      final List<Map<String, dynamic>> tiposCliente = [];
      final List<String> base = _etiquetasBaseSeleccionadas.toList();
      final List<String> pers = _etiquetasPersonalizadas.toList();
      for (final e in base) {
        tiposCliente.add({"label": e});
      }
      int colorIndex = 0;
      final List<String> colors = [
        "#7c4dff",
        "#009688",
        "#795548",
        "#3f51b5",
        "#00bcd4",
        "#ff5722",
        "#cddc39",
        "#607d8b",
        "#e91e63",
        "#ffc107"
      ];
      for (final e in pers) {
        final color = colors[colorIndex % colors.length];
        tiposCliente.add({"label": e, "color": color});
        colorIndex++;
      }

      final data = {
        'nombre': _nombreController.text.trim(),
        'apellidos': _apellidosController.text.trim(),
        'correo': _correoController.text.trim(),
        'telefono': _telefonoController.text.trim(),
        'empresa': _empresaController.text.trim(),
        'calle': _calleController.text.trim(),
        'numeroInterior': _numeroInteriorController.text.trim(),
        'numeroExterior': _numeroExteriorController.text.trim(),
        'colonia': _coloniaController.text.trim(),
        'codigoPostal': _codigoPostalController.text.trim(),
        'alcaldia': _alcaldiaSeleccionada ?? '',
        'tiposCliente': tiposCliente,
        'createdAt': FieldValue.serverTimestamp(),
      };

      if (widget.cliente != null) {
        await widget.cliente!.reference.update(data);
        if (!mounted) return;
        Navigator.of(context).pop(true);
        return; // 🔥 Se ejecuta antes del SnackBar
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Cliente actualizado')),
        );
      } else {
        await FirebaseFirestore.instance.collection('clients').add(data);
        if (!mounted) return;
        Navigator.of(context).pop(true);
        return; // 🔥 Se ejecuta antes del SnackBar
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Cliente guardado')),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final inputBorder = OutlineInputBorder(
      borderSide: const BorderSide(color: kBrandPurple, width: 1),
    );

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.cliente != null ? 'Editar Cliente' : 'Nuevo Cliente',
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            color: kWhite,
          ),
        ),
        backgroundColor: kBrandPurple,
        centerTitle: true,
        iconTheme: const IconThemeData(color: kWhite),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(32),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1000),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(child: _columnaDatosPersonales(inputBorder)),
                        const SizedBox(width: 24),
                        Expanded(child: _columnaDireccion(inputBorder)),
                      ],
                    ),
                    const SizedBox(height: 32),
                    _seccionEtiquetas(inputBorder),
                    const SizedBox(height: 40),
                    _botonesFinales(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _columnaDatosPersonales(InputBorder border) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Datos Personales',
            style: Theme.of(context)
                .textTheme
                .headlineSmall
                ?.copyWith(fontWeight: FontWeight.bold, color: kBrandPurple)),
        const SizedBox(height: 16),
        _input(_nombreController, 'Nombre', true, border,
            focus: _focusNombre, next: _focusApellidos),
        const SizedBox(height: 16),
        _input(_apellidosController, 'Apellidos', true, border,
            focus: _focusApellidos, next: _focusCorreo),
        const SizedBox(height: 16),
        _input(_correoController, 'Correo electrónico', true, border,
            type: TextInputType.emailAddress,
            focus: _focusCorreo,
            next: _focusTelefono),
        const SizedBox(height: 16),
        _input(_telefonoController, 'Teléfono', true, border,
            type: TextInputType.phone,
            maxLength: 14,
            digitsOnly: true,
            focus: _focusTelefono,
            next: _focusEmpresa),
        const SizedBox(height: 16),
        _input(_empresaController, 'Empresa (opcional)', false, border,
            focus: _focusEmpresa, next: _focusCalle),
      ],
    );
  }

  Widget _columnaDireccion(InputBorder border) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Dirección',
            style: Theme.of(context)
                .textTheme
                .headlineSmall
                ?.copyWith(fontWeight: FontWeight.bold, color: kBrandPurple)),
        const SizedBox(height: 16),
        _input(_calleController, 'Calle', true, border,
            focus: _focusCalle, next: _focusNumExt),
        const SizedBox(height: 16),
        _input(_numeroExteriorController, 'Número exterior', true, border,
            focus: _focusNumExt, next: _focusNumInt),
        const SizedBox(height: 16),
        _input(_numeroInteriorController, 'Número interior (opcional)', false,
            border,
            focus: _focusNumInt, next: _focusColonia),
        const SizedBox(height: 16),
        _input(_coloniaController, 'Colonia', true, border,
            focus: _focusColonia, next: _focusCP),
        const SizedBox(height: 16),
        _input(_codigoPostalController, 'Código Postal', true, border,
            type: TextInputType.number, focus: _focusCP),
        const SizedBox(height: 16),
        DropdownButtonFormField<String>(
          value: _alcaldiaSeleccionada,
          decoration: InputDecoration(
            labelText: 'Alcaldía',
            border: border,
            enabledBorder: border,
            focusedBorder: border.copyWith(
              borderSide: const BorderSide(color: kBrandPurple, width: 1.4),
            ),
          ),
          items: [
            'Álvaro Obregón',
            'Azcapotzalco',
            'Benito Juárez',
            'Coyoacán',
            'Cuajimalpa de Morelos',
            'Cuauhtémoc',
            'Gustavo A. Madero',
            'Iztacalco',
            'Iztapalapa',
            'La Magdalena Contreras',
            'Miguel Hidalgo',
            'Milpa Alta',
            'Tláhuac',
            'Tlalpan',
            'Venustiano Carranza',
            'Xochimilco'
          ].map((a) => DropdownMenuItem(value: a, child: Text(a))).toList(),
          onChanged: (v) => setState(() => _alcaldiaSeleccionada = v),
          validator: (v) =>
              v == null || v.isEmpty ? 'Seleccione una alcaldía' : null,
        ),
      ],
    );
  }

  Widget _input(
    TextEditingController ctrl,
    String label,
    bool required,
    InputBorder border, {
    TextInputType? type,
    int? maxLength,
    bool digitsOnly = false,
    FocusNode? focus,
    FocusNode? next,
  }) {
    return TextFormField(
      controller: ctrl,
      focusNode: focus,
      decoration: InputDecoration(
        labelText: label,
        border: border,
        enabledBorder: border,
        focusedBorder: border.copyWith(
          borderSide: const BorderSide(color: kBrandPurple, width: 1.4),
        ),
      ),
      keyboardType: type,
      maxLength: maxLength,
      inputFormatters:
          digitsOnly ? [FilteringTextInputFormatter.digitsOnly] : null,
      validator: (v) => required && (v == null || v.trim().isEmpty)
          ? 'Campo requerido'
          : null,
      onFieldSubmitted: (_) {
        if (next != null) FocusScope.of(context).requestFocus(next);
      },
    );
  }

  Widget _seccionEtiquetas(InputBorder border) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Etiquetas',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: kBrandPurple,
              ),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            ..._etiquetasBase.map((e) {
              final seleccionado = _etiquetasBaseSeleccionadas.contains(e);
              return FilterChip(
                label: Text(
                  e,
                  style: const TextStyle(
                    color: kWhite,
                    fontWeight: FontWeight.bold,
                    fontSize: 11,
                  ),
                ),
                selected: seleccionado,
                onSelected: (_) {
                  setState(() {
                    if (seleccionado) {
                      _etiquetasBaseSeleccionadas.remove(e);
                    } else {
                      _etiquetasBaseSeleccionadas.add(e);
                    }
                  });
                },
                selectedColor: _colorEtiquetaBase(e).withAlpha(230),
                backgroundColor: _colorEtiquetaBase(e).withAlpha(80),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              );
            }),
            SizedBox(
              width: 160,
              child: TextFormField(
                controller: _nuevaEtiquetaController,
                onFieldSubmitted: (_) => _agregarEtiquetaPersonalizada(),
                decoration: InputDecoration(
                  labelText: 'Nueva etiqueta',
                  border: border,
                  enabledBorder: border,
                  focusedBorder: border.copyWith(
                    borderSide:
                        const BorderSide(color: kBrandPurple, width: 1.4),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 48,
              width: 48,
              child: ElevatedButton(
                onPressed: _agregarEtiquetaPersonalizada,
                style: ElevatedButton.styleFrom(
                  backgroundColor: kBrandPurple,
                  padding: EdgeInsets.zero,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Icon(Icons.add, color: kWhite, size: 20),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        if (_etiquetasPersonalizadas.isNotEmpty)
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _etiquetasPersonalizadas.map((e) {
              return Chip(
                label: Text(
                  e,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                    fontSize: 11,
                  ),
                ),
                backgroundColor: kBrandPurple.withAlpha(38),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                deleteIcon: const Icon(Icons.close),
                onDeleted: () => setState(() {
                  _etiquetasPersonalizadas.remove(e);
                }),
              );
            }).toList(),
          ),
      ],
    );
  }

  Widget _botonesFinales() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          style: TextButton.styleFrom(
            foregroundColor: kBrandPurple,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
          child: const Text('Cancelar',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ),
        const SizedBox(width: 16),
        Flexible(
          child: SizedBox(
            height: 48,
            child: ElevatedButton(
              onPressed: _guardarCliente,
              style: ElevatedButton.styleFrom(
                backgroundColor: kBrandPurple,
                padding: const EdgeInsets.symmetric(horizontal: 32),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              child: Text(widget.cliente != null ? 'Actualizar' : 'Guardar',
                  style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: kWhite)), // 🔥 Texto blanco estándar
            ),
          ),
        ),
      ],
    );
  }

  void _agregarEtiquetaPersonalizada() {
    final nueva = _nuevaEtiquetaController.text.trim();
    if (nueva.isEmpty) return;
    final lower = nueva.toLowerCase();
    final existentes = [
      ..._etiquetasBaseSeleccionadas,
      ..._etiquetasPersonalizadas
    ].map((e) => e.toLowerCase());
    if (!existentes.contains(lower)) {
      setState(() {
        _etiquetasPersonalizadas.add(nueva);
        _nuevaEtiquetaController.clear();
      });
    }
  }

  Color _colorEtiquetaBase(String etiqueta) {
    switch (etiqueta.toLowerCase()) {
      case 'vip':
        return kBrandPurple;
      case 'corporativo':
        return Colors.blueAccent;
      case 'nuevo':
        return Colors.green;
      case 'recurrente':
        return Colors.amber;
      case 'promoción':
        return Colors.orangeAccent;
      case 'consentido':
        return Colors.pinkAccent;
      case 'especial':
        return Colors.redAccent;
      default:
        return kBrandPurple;
    }
  }
}
