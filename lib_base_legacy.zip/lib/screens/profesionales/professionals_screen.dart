import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:agenda_fisio_spa_kym/screens/profesionales/widgets/professionals_panel.dart';
import 'package:agenda_fisio_spa_kym/screens/profesionales/widgets/professional_crud_dialog.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';

class ProfessionalsScreen extends StatefulWidget {
  final Future<void> Function()? onNuevoProfesional;

  const ProfessionalsScreen({super.key, this.onNuevoProfesional});

  @override
  State<ProfessionalsScreen> createState() => _ProfessionalsScreenState();
}

class _ProfessionalsScreenState extends State<ProfessionalsScreen> {
  String _filtroBusqueda = '';
  String? _filtroCategoria;
  List<Map<String, dynamic>> _serviciosDisponibles = [];
  Map<String, int> _conteoProfesionales = {};
  Map<String, int> _conteoServicios = {};

  @override
  void initState() {
    super.initState();
    _cargarServicios();
    _cargarConteosProfesionales();

    // ✅ Detectar navegación con key especial para abrir CRUD automáticamente
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final isDesdeSidebar = widget.key == const ValueKey('crear_nuevo');
      if (isDesdeSidebar) {
        await _abrirDialogoCrearProfesional();
        if (!mounted) return;
        // ❌ Se eliminó pushReplacementNamed('/profesionales')
        // ✅ No hacer nada: el listado ya está renderizado
      }
    });
  }

  Future<void> _cargarServicios() async {
    final snapshot =
        await FirebaseFirestore.instance.collection('services').get();

    final servicios = snapshot.docs
        .map((doc) => {'serviceId': doc.id, ...doc.data()})
        .toList();

    setState(() {
      _serviciosDisponibles = servicios;
    });

    final Map<String, int> conteo = {};
    for (final s in servicios) {
      final cat = (s['category'] ?? '').toString();
      conteo[cat] = (conteo[cat] ?? 0) + 1;
    }

    setState(() {
      _conteoServicios = conteo;
    });
  }

  Future<void> _cargarConteosProfesionales() async {
    final snapshot =
        await FirebaseFirestore.instance.collection('profesionales').get();

    final Map<String, Set<String>> profesionalesPorCategoria = {};

    for (var doc in snapshot.docs) {
      final profesionalId = doc.id;
      final servicios = List<Map<String, dynamic>>.from(doc['servicios'] ?? []);

      final Set<String> categoriasUnicas = servicios
          .map((s) => s['category']?.toString())
          .where((c) => c != null && c.isNotEmpty)
          .cast<String>()
          .toSet();

      for (var categoria in categoriasUnicas) {
        profesionalesPorCategoria
            .putIfAbsent(categoria, () => <String>{})
            .add(profesionalId);
      }
    }

    final Map<String, int> conteoFinal = {
      for (var entry in profesionalesPorCategoria.entries)
        entry.key: entry.value.length,
    };

    setState(() {
      _conteoProfesionales = conteoFinal;
    });
  }

  void _recargarProfesionales() {
    _cargarConteosProfesionales();
    setState(() {});
  }

  void _actualizarBusqueda(String texto) {
    setState(() {
      _filtroBusqueda = texto;
    });
  }

  void _actualizarCategoria(String? categoria) {
    setState(() {
      _filtroCategoria = categoria;
    });
  }

  Future<void> _abrirDialogoCrearProfesional() async {
    final creado = await showDialog(
      context: context,
      builder: (_) => ProfessionalCrudDialog(
        serviciosDisponibles: _serviciosDisponibles,
      ),
    );
    if (creado != null) {
      _recargarProfesionales();
    }
  }

  Color _colorFondoCategoria(String categoria) {
    final base = categoria.trim().toLowerCase();
    final colores = {
      'masajes': const Color(0xFFE1F5FE),
      'faciales': const Color(0xFFFFF3E0),
      'fisioterapia': const Color(0xFFE8F5E9),
      'podología': const Color(0xFFF3E5F5),
      'cosmetología': const Color(0xFFFFEBEE),
    };
    return colores[base] ?? Colors.grey.shade200;
  }

  Widget _buildFiltroCategorias() {
    final categorias = _serviciosDisponibles
        .map((s) => s['category']?.toString())
        .toSet()
        .whereType<String>()
        .toList()
      ..sort();

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        ChoiceChip(
          label: const Text('Todas'),
          selected: _filtroCategoria == null,
          selectedColor: kBrandPurple.withAlpha(38),
          backgroundColor: Colors.grey.shade100,
          avatar: _filtroCategoria == null
              ? const Icon(Icons.check, size: 16, color: kBrandPurple)
              : null,
          labelStyle: TextStyle(
            color: _filtroCategoria == null ? kBrandPurple : Colors.black87,
          ),
          onSelected: (_) => _actualizarCategoria(null),
        ),
        ...categorias.map((categoria) {
          final isSelected = _filtroCategoria == categoria;
          final colorFondo = _colorFondoCategoria(categoria);
          final pCount = _conteoProfesionales[categoria] ?? 0;
          final sCount = _conteoServicios[categoria] ?? 0;

          final tooltip =
              '👥 $pCount profesionales asignados\n📦 $sCount servicios activos';

          return Tooltip(
            message: tooltip,
            preferBelow: false,
            child: ChoiceChip(
              label: Text(categoria),
              selected: isSelected,
              selectedColor: colorFondo,
              backgroundColor: Colors.grey.shade100,
              avatar: isSelected
                  ? const Icon(Icons.check, size: 16, color: kBrandPurple)
                  : null,
              labelStyle: TextStyle(
                color: Colors.black87,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
              ),
              onSelected: (_) => _actualizarCategoria(categoria),
            ),
          );
        }),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 24),
            Center(
              child: Text(
                'Gestión de Profesionales',
                style: TextStyle(
                  color: kBrandPurple,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 24),
            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 800),
                child: TextField(
                  onChanged: _actualizarBusqueda,
                  decoration: InputDecoration(
                    hintText: 'Buscar por nombre...',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                    fillColor: Colors.white,
                    filled: true,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: _buildFiltroCategorias(),
            ),
            const SizedBox(height: 24),
            Expanded(
              child: ProfessionalsPanel(
                filtroTexto: _filtroBusqueda,
                filtroCategoria: _filtroCategoria,
                serviciosDisponibles: _serviciosDisponibles,
                onUpdated: _recargarProfesionales,
              ),
            ),
          ],
        ),
        Positioned(
          bottom: 24,
          right: 24,
          child: FloatingActionButton.extended(
            onPressed:
                widget.onNuevoProfesional ?? _abrirDialogoCrearProfesional,
            backgroundColor: kBrandPurple,
            foregroundColor: Colors.white,
            elevation: 4,
            icon: const Icon(Icons.person),
            label: const Row(
              children: [
                Text('Agregar'),
                SizedBox(width: 4),
                Icon(Icons.add),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
