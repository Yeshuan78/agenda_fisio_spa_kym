// [Sección 1.3] profesionales_screen.dart

/*****************************************************
 * PROFESIONALES_SCREEN.DART
 * Cambios solicitados:
 * 1) Bordes y líneas divisorias con un color acorde (gris violáceo).
 * 2) Sección Servicios con menús desplegables (ExpansionTile) para las categorías.
 * 3) Sección Horarios con un estilo similar al de categorías (fondo blanco, bordes suaves).
 *****************************************************/

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart'; // Para inputFormatters
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart';

const Color kBrandPurple = Color(0xFF9920A7);
// [Nuevo] Color para bordes y líneas: un gris violáceo
const Color kBorderColor = Color(0xFFCCAEE0); // Ejemplo: un lila claro

int _toInt(dynamic value, {int defaultValue = 0}) {
  if (value is int) return value;
  if (value is String) return int.tryParse(value) ?? defaultValue;
  return defaultValue;
}

int _normalizeHour(dynamic value, {int defaultValue = 10}) {
  int v = _toInt(value, defaultValue: defaultValue);
  if (v < 6 || v > 21) return defaultValue;
  return v;
}

int _normalizeMinute(dynamic value, {int defaultValue = 0}) {
  int v = _toInt(value, defaultValue: defaultValue);
  const validMinutes = [0, 15, 30, 45];
  if (!validMinutes.contains(v)) return defaultValue;
  return v;
}

class ProfesionalesScreen extends StatefulWidget {
  const ProfesionalesScreen({Key? key}) : super(key: key);

  @override
  State<ProfesionalesScreen> createState() => _ProfesionalesScreenState();
}

class _ProfesionalesScreenState extends State<ProfesionalesScreen> {
  List<DocumentSnapshot> _profesionales = [];

  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _apellidosController = TextEditingController();
  final TextEditingController _correoController = TextEditingController();
  final TextEditingController _telefonoController = TextEditingController();
  final TextEditingController _fotoController = TextEditingController();

  bool _profesionalActivo = true;

  final List<String> _opcionesEspecialidad = [
    'Terapeuta',
    'Fisioterapeuta',
    'Podóloga',
    'Cosmetóloga',
  ];
  final Set<String> _especialidadesSeleccionadas = {};

  final List<String> _diasSemana = [
    'Lunes',
    'Martes',
    'Miércoles',
    'Jueves',
    'Viernes',
    'Sábado',
    'Domingo'
  ];
  late List<Map<String, dynamic>> _horarios;

  List<Map<String, dynamic>> _serviciosPorCategoria = [];
  final Map<String, Map<String, bool>> _serviciosSeleccionados = {};

  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";

  @override
  void initState() {
    super.initState();
    _cargarProfesionales();
    _initHorarios();
    _loadServicesFromFirestore();

    // Búsqueda en tiempo real (opcional)
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text.toLowerCase().trim();
      });
    });
  }

  Future<void> _cargarProfesionales() async {
    final snap = await FirebaseFirestore.instance
        .collection('profesionales')
        .orderBy('fullName')
        .get();
    if (mounted) {
      setState(() {
        _profesionales = snap.docs;
      });
    }
  }

  void _initHorarios() {
    _horarios = _diasSemana.map((dia) {
      return {
        'day': dia,
        'active': false,
        'startHour': 10,
        'startMinute': 0,
        'endHour': 21,
        'endMinute': 0,
        'bloqueos': <Map<String, dynamic>>[],
      };
    }).toList();
  }

  Future<void> _loadServicesFromFirestore() async {
    final catSnap = await FirebaseFirestore.instance.collection('categories').get();
    final List<Map<String, dynamic>> loadedList = [];
    for (final catDoc in catSnap.docs) {
      final catName = catDoc.id;
      final servSnap = await catDoc.reference.collection('services').get();
      final List<Map<String, dynamic>> servicesList = servSnap.docs.map((sdoc) {
        final sdata = sdoc.data();
        return {
          'docId': sdoc.id,
          'name': sdata['name'] ?? 'Servicio sin nombre',
          'duration': sdata['duration'] ?? 0,
          'price': sdata['price'] ?? 0,
          'image': sdata['image'] ?? '',
          'description': sdata['description'] ?? '',
        };
      }).toList();
      loadedList.add({'category': catName, 'services': servicesList});
    }
    if (mounted) {
      setState(() {
        _serviciosPorCategoria = loadedList;
      });
      _initServiciosSeleccionados();
    }
  }

  void _initServiciosSeleccionados() {
    _serviciosSeleccionados.clear();
    for (final catMap in _serviciosPorCategoria) {
      final String category = catMap['category'];
      final List<dynamic> services = catMap['services'];
      final Map<String, bool> mapServ = {};
      for (final servData in services) {
        final String docId = servData['docId'] as String;
        mapServ[docId] = false;
      }
      _serviciosSeleccionados[category] = mapServ;
    }
  }

  Widget _inputConEstilo({
    required TextEditingController controller,
    required String label,
    TextInputType keyboardType = TextInputType.text,
    List<TextInputFormatter>? inputFormatters,
    int? maxLength,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      inputFormatters: inputFormatters,
      maxLength: maxLength,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderSide: BorderSide(color: kBorderColor),
          borderRadius: BorderRadius.circular(8),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: kBrandPurple, width: 2),
          borderRadius: BorderRadius.circular(8),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      ),
      validator: validator,
    );
  }

  Widget _dropdownHoras({required int value, required void Function(int) onChanged}) {
    final horas = List.generate(16, (i) => i + 6);
    return SizedBox(
      width: 60,
      child: DropdownButton<int>(
        isExpanded: true,
        value: value,
        onChanged: (v) {
          if (v != null) onChanged(v);
        },
        items: horas.map((h) => DropdownMenuItem(value: h, child: Text('$h'))).toList(),
      ),
    );
  }

  Widget _dropdownMinutos({required int value, required void Function(int) onChanged}) {
    final minutos = [0, 15, 30, 45];
    return SizedBox(
      width: 60,
      child: DropdownButton<int>(
        isExpanded: true,
        value: value,
        onChanged: (v) {
          if (v != null) onChanged(v);
        },
        items: minutos
            .map((m) => DropdownMenuItem(value: m, child: Text(m.toString().padLeft(2, '0'))))
            .toList(),
      ),
    );
  }

  Future<void> _pickImage() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image);
    if (result != null && result.files.single.path != null) {
      setState(() {
        _fotoController.text = result.files.single.path!;
      });
    }
  }

  Future<void> _guardarProfesional({required GlobalKey<FormState> formKey}) async {
    if (formKey.currentState == null || !formKey.currentState!.validate()) return;
    try {
      final List<String> especialidades = _especialidadesSeleccionadas.toList();
      final List<String> serviciosMarcados = [];
      _serviciosSeleccionados.forEach((cat, mapServ) {
        mapServ.forEach((docId, selected) {
          if (selected) serviciosMarcados.add('$cat|$docId');
        });
      });
      final fullName = '${_nombreController.text.trim()} ${_apellidosController.text.trim()}';

      final docRef = await FirebaseFirestore.instance.collection('profesionales').add({
        'nombre': _nombreController.text.trim(),
        'apellidos': _apellidosController.text.trim(),
        'fullName': fullName,
        'correo': _correoController.text.trim(),
        'telefono': _telefonoController.text.trim(),
        'photo': _fotoController.text.trim(),
        'activo': _profesionalActivo,
        'especialidades': especialidades,
        'servicios': serviciosMarcados,
        'createdAt': FieldValue.serverTimestamp(),
      });
      final profId = docRef.id;
      await FirebaseFirestore.instance.collection('calendarios').doc(profId).set({
        'profesionalId': profId,
        'calendarName': '$fullName Calendar',
        'availableDays': _horarios,
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profesional guardado con éxito')),
      );
      Navigator.pop(context);
      _cargarProfesionales();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al guardar: $e')),
      );
    }
  }

  Future<void> _eliminarProfesional(String profId) async {
    try {
      await FirebaseFirestore.instance.collection('profesionales').doc(profId).delete();
      await FirebaseFirestore.instance.collection('calendarios').doc(profId).delete();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profesional eliminado con éxito')),
      );
      _cargarProfesionales();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al eliminar: $e')),
      );
    }
  }

  void _showDialogAltaProfesional() {
    _initHorarios();
    _initServiciosSeleccionados();
    _especialidadesSeleccionadas.clear();
    _nombreController.clear();
    _apellidosController.clear();
    _correoController.clear();
    _telefonoController.clear();
    _fotoController.clear();
    _profesionalActivo = true;

    final GlobalKey<FormState> dialogFormKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (ctx) {
        return Dialog(
          insetPadding: const EdgeInsets.all(24),
          child: DefaultTabController(
            length: 3,
            child: StatefulBuilder(
              builder: (context, setStateDialog) {
                return Form(
                  key: dialogFormKey,
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFf5f5f9),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    constraints: const BoxConstraints(maxWidth: 750, maxHeight: 600),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        AppBar(
                          automaticallyImplyLeading: false,
                          backgroundColor: kBrandPurple,
                          centerTitle: true,
                          title: const Text('Profesionales'),
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                              top: Radius.circular(12),
                              bottom: Radius.circular(12),
                            ),
                          ),
                          leading: IconButton(
                            icon: const Icon(Icons.close, color: Colors.white),
                            onPressed: () => Navigator.pop(ctx),
                          ),
                        ),
                        TabBar(
                          labelColor: kBrandPurple,
                          unselectedLabelColor: Colors.black54,
                          indicatorColor: kBrandPurple,
                          labelStyle: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                          unselectedLabelStyle: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.normal,
                          ),
                          tabs: const [
                            Tab(text: 'Datos'),
                            Tab(text: 'Servicios'),
                            Tab(text: 'Horarios'),
                          ],
                        ),
                        Expanded(
                          child: TabBarView(
                            children: [
                              _buildTabDatos(setStateDialog),
                              _buildTabServicios(setStateDialog),
                              _buildTabHorarios(setStateDialog),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: kBrandPurple,
                              minimumSize: const Size.fromHeight(40),
                            ),
                            onPressed: () => _guardarProfesional(formKey: dialogFormKey),
                            child: const Text('Guardar'),
                          ),
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }

  Future<void> _editarProfesional(DocumentSnapshot doc) async {
    final data = doc.data() as Map<String, dynamic>;
    _nombreController.text = data['nombre'] ?? '';
    _apellidosController.text = data['apellidos'] ?? '';
    _correoController.text = data['correo'] ?? '';
    _telefonoController.text = data['telefono'] ?? '';
    _fotoController.text = data['photo'] ?? '';
    _profesionalActivo = (data['activo'] == null) ? true : (data['activo'] as bool);

    _especialidadesSeleccionadas.clear();
    if (data['especialidades'] != null) {
      for (final esp in data['especialidades']) {
        _especialidadesSeleccionadas.add(esp);
      }
    }

    _initServiciosSeleccionados();
    if (data['servicios'] != null) {
      List<dynamic> serviciosGuardados = data['servicios'];
      for (final servStr in serviciosGuardados) {
        if (servStr is String) {
          final parts = servStr.split('|');
          if (parts.length == 2) {
            final catNameSaved = parts[0];
            final docIdSaved = parts[1];
            if (_serviciosSeleccionados.containsKey(catNameSaved)) {
              _serviciosSeleccionados[catNameSaved]?[docIdSaved] = true;
            }
          }
        }
      }
    }

    final calDoc = await FirebaseFirestore.instance
        .collection('calendarios')
        .doc(doc.id)
        .get();
    if (calDoc.exists && calDoc.data() != null) {
      _horarios = (calDoc.data()!['availableDays'] as List).map((day) {
        final map = Map<String, dynamic>.from(day);
        map['startHour'] = _normalizeHour(map['startHour'], defaultValue: 10);
        map['startMinute'] = _normalizeMinute(map['startMinute'], defaultValue: 0);
        map['endHour'] = _normalizeHour(map['endHour'], defaultValue: 21);
        map['endMinute'] = _normalizeMinute(map['endMinute'], defaultValue: 0);
        if (map['bloqueos'] != null) {
          map['bloqueos'] = (map['bloqueos'] as List).map((b) {
            final bMap = Map<String, dynamic>.from(b);
            bMap['startHour'] = _normalizeHour(bMap['startHour'], defaultValue: 12);
            bMap['startMinute'] = _normalizeMinute(bMap['startMinute'], defaultValue: 0);
            bMap['endHour'] = _normalizeHour(bMap['endHour'], defaultValue: 13);
            bMap['endMinute'] = _normalizeMinute(bMap['endMinute'], defaultValue: 0);
            return bMap;
          }).toList();
        }
        return map;
      }).toList();
    } else {
      _initHorarios();
    }

    final GlobalKey<FormState> dialogFormKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (ctx) {
        return Dialog(
          insetPadding: const EdgeInsets.all(24),
          child: DefaultTabController(
            length: 3,
            child: StatefulBuilder(
              builder: (context, setStateDialog) {
                return Form(
                  key: dialogFormKey,
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFf5f5f9),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    constraints: const BoxConstraints(maxWidth: 750, maxHeight: 600),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        AppBar(
                          automaticallyImplyLeading: false,
                          backgroundColor: kBrandPurple,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                              top: Radius.circular(12),
                              bottom: Radius.circular(12),
                            ),
                          ),
                          title: Text(
                              'Editando ${_nombreController.text.trim()} ${_apellidosController.text.trim()}'),
                          centerTitle: true,
                          leading: IconButton(
                            icon: const Icon(Icons.close, color: Colors.white),
                            onPressed: () => Navigator.pop(ctx),
                          ),
                        ),
                        TabBar(
                          labelColor: kBrandPurple,
                          unselectedLabelColor: Colors.black54,
                          indicatorColor: kBrandPurple,
                          labelStyle: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                          unselectedLabelStyle: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.normal,
                          ),
                          tabs: const [
                            Tab(text: 'Datos'),
                            Tab(text: 'Servicios'),
                            Tab(text: 'Horarios'),
                          ],
                        ),
                        Expanded(
                          child: TabBarView(
                            children: [
                              _buildTabDatos(setStateDialog),
                              _buildTabServicios(setStateDialog),
                              _buildTabHorarios(setStateDialog),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: kBrandPurple,
                              minimumSize: const Size.fromHeight(40),
                            ),
                            onPressed: () async {
                              if (dialogFormKey.currentState == null ||
                                  !dialogFormKey.currentState!.validate()) return;
                              try {
                                final List<String> especialidades =
                                    _especialidadesSeleccionadas.toList();
                                final List<String> serviciosMarcados = [];
                                _serviciosSeleccionados.forEach((cat, mapServ) {
                                  mapServ.forEach((docId, selected) {
                                    if (selected) serviciosMarcados.add('$cat|$docId');
                                  });
                                });
                                final updatedFullName =
                                    '${_nombreController.text.trim()} ${_apellidosController.text.trim()}';

                                await FirebaseFirestore.instance
                                    .collection('profesionales')
                                    .doc(doc.id)
                                    .update({
                                  'nombre': _nombreController.text.trim(),
                                  'apellidos': _apellidosController.text.trim(),
                                  'fullName': updatedFullName,
                                  'correo': _correoController.text.trim(),
                                  'telefono': _telefonoController.text.trim(),
                                  'photo': _fotoController.text.trim(),
                                  'activo': _profesionalActivo,
                                  'especialidades': especialidades,
                                  'servicios': serviciosMarcados,
                                });

                                await FirebaseFirestore.instance
                                    .collection('calendarios')
                                    .doc(doc.id)
                                    .update({
                                  'calendarName': '$updatedFullName Calendar',
                                  'availableDays': _horarios,
                                });

                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Profesional actualizado')),
                                );
                                Navigator.pop(ctx);
                                _cargarProfesionales();
                              } catch (e) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('Error al actualizar: $e')),
                                );
                              }
                            },
                            child: const Text('Guardar'),
                          ),
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }

  /// TAB 1: Datos
  Widget _buildTabDatos(void Function(void Function()) setStateDialog) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 2,
                child: Column(
                  children: [
                    _inputConEstilo(
                      controller: _nombreController,
                      label: 'Nombre',
                      maxLength: 50,
                      validator: (value) => (value == null || value.isEmpty) ? 'Ingresa el nombre' : null,
                    ),
                    const SizedBox(height: 8),
                    _inputConEstilo(
                      controller: _apellidosController,
                      label: 'Apellidos',
                      maxLength: 50,
                      validator: (value) =>
                          (value == null || value.isEmpty) ? 'Ingresa los apellidos' : null,
                    ),
                    const SizedBox(height: 8),
                    _inputConEstilo(
                      controller: _correoController,
                      label: 'Correo',
                      keyboardType: TextInputType.emailAddress,
                      validator: (value) {
                        if (value == null || value.isEmpty) return 'Ingresa el correo';
                        final pattern = RegExp(r'^[^@]+@[^@]+\.[^@]+');
                        if (!pattern.hasMatch(value)) return 'Correo inválido';
                        return null;
                      },
                    ),
                    const SizedBox(height: 8),
                    _inputConEstilo(
                      controller: _telefonoController,
                      label: 'Teléfono',
                      keyboardType: TextInputType.phone,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      maxLength: 10,
                      validator: (value) =>
                          (value == null || value.isEmpty) ? 'Ingresa el teléfono' : null,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                flex: 1,
                child: Column(
                  children: [
                    Container(
                      width: 110,
                      height: 110,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: kBrandPurple, width: 3),
                        color: Colors.white,
                      ),
                      child: ClipOval(
                        child: (_fotoController.text.trim().isNotEmpty)
                            ? Image.network(
                                _fotoController.text.trim(),
                                fit: BoxFit.cover,
                                errorBuilder: (ctx, e, stack) =>
                                    const Icon(Icons.person, size: 64, color: Colors.grey),
                              )
                            : const Icon(Icons.person, size: 64, color: kBrandPurple),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Center(
                      child: SizedBox(
                        width: 160,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(backgroundColor: kBrandPurple),
                          icon: const Icon(Icons.photo_camera, color: Colors.white),
                          label: const Text('Cargar Imagen', style: TextStyle(color: Colors.white)),
                          onPressed: _pickImage,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Align(
            alignment: Alignment.centerLeft,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Checkbox(
                  activeColor: kBrandPurple,
                  checkColor: Colors.white,
                  value: _profesionalActivo,
                  onChanged: (val) {
                    setStateDialog(() {
                      _profesionalActivo = val ?? true;
                    });
                  },
                ),
                const Text('¿Profesional Activo?'),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Especialidades',
            style: TextStyle(fontWeight: FontWeight.bold, color: kBrandPurple),
          ),
          const SizedBox(height: 8),
          Column(
            children: _opcionesEspecialidad.map((esp) {
              return CheckboxListTile(
                activeColor: kBrandPurple,
                checkColor: Colors.white,
                title: Text(esp),
                value: _especialidadesSeleccionadas.contains(esp),
                onChanged: (val) {
                  setStateDialog(() {
                    if (val == true) {
                      _especialidadesSeleccionadas.add(esp);
                    } else {
                      _especialidadesSeleccionadas.remove(esp);
                    }
                  });
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
          Text(
            'URL de la foto (opcional)',
            style: TextStyle(fontWeight: FontWeight.bold, color: kBrandPurple),
          ),
          const SizedBox(height: 8),
          _inputConEstilo(
            controller: _fotoController,
            label: 'URL Foto',
            keyboardType: TextInputType.url,
          ),
        ],
      ),
    );
  }

  /// TAB 2: Servicios como menú desplegable
  Widget _buildTabServicios(void Function(void Function()) setStateDialog) {
    if (_serviciosPorCategoria.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: _serviciosPorCategoria.map((cat) {
          final String catName = cat['category'] as String;
          final List<Map<String, dynamic>> services =
              List<Map<String, dynamic>>.from(cat['services'] as List);
          // [CAMBIO 2] - Usamos ExpansionTile para mostrar las categorías
          return Container(
            margin: const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              // Borde con color lila y esquinas redondeadas
              border: Border.all(color: kBorderColor, width: 1),
              borderRadius: BorderRadius.circular(8),
              boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4)],
            ),
            child: ExpansionTile(
              title: Text(
                catName,
                style: const TextStyle(color: kBrandPurple, fontWeight: FontWeight.bold, fontSize: 18),
              ),
              iconColor: kBrandPurple,
              collapsedIconColor: kBrandPurple,
              children: [
                for (int i = 0; i < services.length; i++)
                  _buildServiceItem(catName, services[i], setStateDialog),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildServiceItem(
    String catName,
    Map<String, dynamic> servData,
    void Function(void Function()) setStateDialog,
  ) {
    final String docId = servData['docId'] as String;
    final String name = servData['name'] ?? 'Sin nombre';
    final int duration = _toInt(servData['duration']);
    final int price = _toInt(servData['price']);
    final String imageUrl = servData['image'] ?? '';
    final bool selected = _serviciosSeleccionados[catName]?[docId] ?? false;

    return Column(
      children: [
        ListTile(
          leading: (imageUrl.isNotEmpty)
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    imageUrl,
                    width: 60,
                    height: 60,
                    fit: BoxFit.cover,
                    errorBuilder: (ctx, e, stack) => const Icon(Icons.broken_image),
                  ),
                )
              : const Icon(Icons.image_not_supported, size: 40, color: Colors.grey),
          title: Text(name),
          subtitle: Text('Duración: $duration min • \$$price'),
          trailing: Checkbox(
            activeColor: kBrandPurple,
            checkColor: Colors.white,
            value: selected,
            onChanged: (val) {
              setStateDialog(() {
                _serviciosSeleccionados[catName]?[docId] = val ?? false;
              });
            },
          ),
        ),
        // Línea divisoria
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          height: 1,
          color: kBorderColor,
        ),
      ],
    );
  }

  /// TAB 3: Horarios con contenedores estilo "categorías"
  Widget _buildTabHorarios(void Function(void Function()) setStateDialog) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: List.generate(_horarios.length, (index) {
          final day = _horarios[index];
          final bool active = day['active'] ?? false;
          if (day['bloqueos'] == null) {
            day['bloqueos'] = <Map<String, dynamic>>[];
          }
          // [CAMBIO 3] - Estilo similar a la categoría: fondo blanco, borde color
          return Container(
            margin: const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: kBorderColor, width: 1),
              borderRadius: BorderRadius.circular(8),
              boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4)],
            ),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  // Fila con el día y el switch
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        day['day'] ?? '',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: kBrandPurple,
                        ),
                      ),
                      Switch(
                        value: active,
                        activeColor: const Color(0xFF8ABF54),
                        inactiveThumbColor: const Color(0xFF4DB1E0),
                        onChanged: (val) {
                          setStateDialog(() {
                            day['active'] = val;
                            if (val) {
                              day['startHour'] = 10;
                              day['startMinute'] = 0;
                              day['endHour'] = 21;
                              day['endMinute'] = 0;
                            }
                          });
                        },
                      ),
                    ],
                  ),
                  if (active) ...[
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text('Entrada: '),
                        _dropdownHoras(
                          value: _toInt(day['startHour'], defaultValue: 10),
                          onChanged: (val) {
                            setStateDialog(() {
                              day['startHour'] = val;
                            });
                          },
                        ),
                        const SizedBox(width: 4),
                        _dropdownMinutos(
                          value: _toInt(day['startMinute'], defaultValue: 0),
                          onChanged: (val) {
                            setStateDialog(() {
                              day['startMinute'] = val;
                            });
                          },
                        ),
                        const SizedBox(width: 16),
                        const Text('Salida: '),
                        _dropdownHoras(
                          value: _toInt(day['endHour'], defaultValue: 21),
                          onChanged: (val) {
                            setStateDialog(() {
                              day['endHour'] = val;
                            });
                          },
                        ),
                        const SizedBox(width: 4),
                        _dropdownMinutos(
                          value: _toInt(day['endMinute'], defaultValue: 0),
                          onChanged: (val) {
                            setStateDialog(() {
                              day['endMinute'] = val;
                            });
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Align(
                      alignment: Alignment.center,
                      child: SizedBox(
                        width: 150,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: kBrandPurple),
                          onPressed: () {
                            setStateDialog(() {
                              (day['bloqueos'] as List<Map<String, dynamic>>).add({
                                'startHour': 14,
                                'startMinute': 0,
                                'endHour': 15,
                                'endMinute': 0,
                              });
                            });
                          },
                          child: const Text('Bloquear Horas'),
                        ),
                      ),
                    ),
                    for (int i = 0; i < (day['bloqueos'] as List).length; i++)
                      _buildBloqueoRow(day, i, setStateDialog),
                  ],
                ],
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildBloqueoRow(
    Map<String, dynamic> dayData,
    int i,
    void Function(void Function()) setStateDialog,
  ) {
    final List<Map<String, dynamic>> bloqueos =
        List<Map<String, dynamic>>.from(dayData['bloqueos']);
    final bloq = bloqueos[i];
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: kBrandPurple.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('Bloqueo: ', style: TextStyle(fontWeight: FontWeight.bold, color: kBrandPurple)),
          _dropdownHoras(
            value: _toInt(bloq['startHour'], defaultValue: 12),
            onChanged: (val) {
              setStateDialog(() {
                bloq['startHour'] = val;
                bloqueos[i] = bloq;
                dayData['bloqueos'] = bloqueos;
              });
            },
          ),
          const SizedBox(width: 4),
          _dropdownMinutos(
            value: _toInt(bloq['startMinute'], defaultValue: 0),
            onChanged: (val) {
              setStateDialog(() {
                bloq['startMinute'] = val;
                bloqueos[i] = bloq;
                dayData['bloqueos'] = bloqueos;
              });
            },
          ),
          const SizedBox(width: 12),
          const Text(' a '),
          _dropdownHoras(
            value: _toInt(bloq['endHour'], defaultValue: 13),
            onChanged: (val) {
              setStateDialog(() {
                bloq['endHour'] = val;
                bloqueos[i] = bloq;
                dayData['bloqueos'] = bloqueos;
              });
            },
          ),
          const SizedBox(width: 4),
          _dropdownMinutos(
            value: _toInt(bloq['endMinute'], defaultValue: 0),
            onChanged: (val) {
              setStateDialog(() {
                bloq['endMinute'] = val;
                bloqueos[i] = bloq;
                dayData['bloqueos'] = bloqueos;
              });
            },
          ),
          const SizedBox(width: 12),
          IconButton(
            icon: const Icon(Icons.delete, color: Colors.red),
            onPressed: () {
              setStateDialog(() {
                bloqueos.removeAt(i);
                dayData['bloqueos'] = bloqueos;
              });
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filteredList = _profesionales.where((doc) {
      final data = doc.data() as Map<String, dynamic>;
      final nombre = (data['nombre'] ?? '').toString().toLowerCase();
      final apellidos = (data['apellidos'] ?? '').toString().toLowerCase();
      return nombre.contains(_searchQuery) || apellidos.contains(_searchQuery);
    }).toList();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: kBrandPurple,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(12),
            bottom: Radius.circular(12),
          ),
        ),
        title: const Text('Profesionales'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // Caja de búsqueda
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Buscar por nombre o apellidos',
                prefixIcon: const Icon(Icons.search, color: kBrandPurple),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: kBorderColor),
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredList.length,
              itemBuilder: (ctx, index) {
                final doc = filteredList[index];
                final data = doc.data() as Map<String, dynamic>;
                final nombreCompleto = '${data['nombre'] ?? ''} ${data['apellidos'] ?? ''}'.trim();
                final especialidades = (data['especialidades'] ?? []).join(', ');
                final bool activo = (data['activo'] == null) ? true : data['activo'];
                final estadoStr = activo ? 'ACTIVO' : 'INACTIVO';

                return Container(
                  margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: kBorderColor, width: 1),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: const [
                      BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(2, 4)),
                    ],
                  ),
                  child: ListTile(
                    title: Text(
                      nombreCompleto.isEmpty ? '(Sin nombre)' : nombreCompleto,
                      style: const TextStyle(fontWeight: FontWeight.bold, color: kBrandPurple),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Especialidades: $especialidades'),
                        Text('Estado: $estadoStr', style: const TextStyle(fontSize: 13)),
                      ],
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit, color: kBrandPurple),
                          onPressed: () => _editarProfesional(doc),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _eliminarProfesional(doc.id),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: kBrandPurple,
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: _showDialogAltaProfesional,
      ),
    );
  }
}
