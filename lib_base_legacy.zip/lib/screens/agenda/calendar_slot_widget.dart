// [calendar_slot_widget.dart] — CODE-CSW-006
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:agenda_fisio_spa_kym/models/appointment_model.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';

class CalendarSlotWidget extends StatelessWidget {
  final DateTime slotDateTime;
  final List<AppointmentModel> appointments;
  final String profesionalId;
  final Map<String, dynamic>? calendarData;
  final void Function(DateTime slotDate, bool isBlocked, String blockName)?
      onTap;
  final void Function(AppointmentModel)? onCitaTap;

  const CalendarSlotWidget({
    super.key,
    required this.slotDateTime,
    required this.appointments,
    required this.profesionalId,
    required this.calendarData,
    required this.onTap,
    required this.onCitaTap,
  });

  @override
  Widget build(BuildContext context) {
    final isBlocked = _isSlotBlocked();
    final isAvailable = _isAvailable();

    final coloresCitas = [
      const Color.fromARGB(255, 67, 141, 160),
      Colors.blue.shade600,
      Colors.orange.shade600,
      Colors.teal.shade600,
      Colors.pink.shade400,
    ];

    return GestureDetector(
      onTap: () {
        if (appointments.isEmpty) {
          onTap?.call(slotDateTime, isBlocked, _getBlockName());
        }
      },
      child: Container(
        margin: const EdgeInsets.all(1),
        decoration: BoxDecoration(
          color: appointments.isEmpty ? Colors.grey.shade100 : Colors.white,
          border: Border.all(color: Colors.grey.shade300),
          borderRadius: BorderRadius.circular(6),
        ),
        height: 60,
        child: Stack(
          children: [
            if (isBlocked && appointments.isEmpty)
              const Center(
                  child: Icon(Icons.block, size: 18, color: Colors.black45)),

            if (appointments.isNotEmpty)
              Padding(
                padding: const EdgeInsets.all(2),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    for (int i = 0; i < appointments.take(2).length; i++)
                      Expanded(
                        child: GestureDetector(
                          onTap: () => onCitaTap?.call(appointments[i]),
                          child: Tooltip(
                            message: '''
Cliente: ${appointments[i].nombreCliente ?? ''}
Servicio: ${appointments[i].servicio}
Profesional: ${appointments[i].nombreProfesional}
Hora: ${DateFormat.Hm().format(appointments[i].fechaInicio!)}
Estado: ${appointments[i].estado}
${appointments[i].comentariosTexto.isNotEmpty ? "Notas: ${appointments[i].comentariosTexto}" : ""}
''',
                            decoration: BoxDecoration(
                              color: Colors.grey.shade800,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            textStyle: const TextStyle(color: Colors.white),
                            child: Container(
                              width: double.infinity,
                              margin: const EdgeInsets.only(bottom: 2),
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 4),
                              decoration: BoxDecoration(
                                color: coloresCitas[i % coloresCitas.length],
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                appointments[i].nombreCliente ?? 'Cita',
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontSize: 10, color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      ),
                    if (appointments.length > 2)
                      Text(
                        '+${appointments.length - 2} más',
                        style:
                            const TextStyle(fontSize: 9, color: kBrandPurple),
                      ),
                  ],
                ),
              ),
            // Hora en esquina inferior derecha
            Positioned(
              bottom: 2,
              right: 4,
              child: Text(
                DateFormat.Hm().format(slotDateTime),
                style: const TextStyle(
                  fontSize: 12, // ✅ Tamaño más grande
                  fontWeight: FontWeight.bold, // ✅ Negritas
                  color: kBrandPurple,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  bool _isSlotBlocked() {
    if (calendarData == null ||
        !calendarData!.containsKey("availableDays") ||
        profesionalId.isEmpty) {
      return false;
    }

    final availableDays = calendarData!["availableDays"] as List<dynamic>;
    final dayName =
        DateFormat("EEEE", "es_MX").format(slotDateTime).toLowerCase();

    final dayData = availableDays.firstWhere(
      (d) => (d["day"] as String).toLowerCase() == dayName,
      orElse: () => null,
    );

    if (dayData == null || !dayData.containsKey("bloqueos")) return false;

    final bloqueos = dayData["bloqueos"] as List<dynamic>;
    for (var b in bloqueos) {
      final start = DateTime(
        slotDateTime.year,
        slotDateTime.month,
        slotDateTime.day,
        b["startHour"],
        b["startMinute"],
      );
      final end = DateTime(
        slotDateTime.year,
        slotDateTime.month,
        slotDateTime.day,
        b["endHour"],
        b["endMinute"],
      );
      if (!slotDateTime.isBefore(start) && slotDateTime.isBefore(end))
        return true;
    }

    return false;
  }

  bool _isAvailable() {
    if (calendarData == null || profesionalId.isEmpty) return false;
    if (!calendarData!.containsKey("availableDays")) return false;

    final availableDays = calendarData!["availableDays"] as List<dynamic>;
    final dayName =
        DateFormat("EEEE", "es_MX").format(slotDateTime).toLowerCase();

    final dayData = availableDays.firstWhere(
      (d) => (d["day"] as String).toLowerCase() == dayName,
      orElse: () => null,
    );

    if (dayData == null ||
        !dayData.containsKey("start") ||
        !dayData.containsKey("end")) return false;

    final start = _parseTime(dayData["start"]);
    final end = _parseTime(dayData["end"]);

    final startDT = DateTime(
      slotDateTime.year,
      slotDateTime.month,
      slotDateTime.day,
      start.hour,
      start.minute,
    );
    final endDT = DateTime(
      slotDateTime.year,
      slotDateTime.month,
      slotDateTime.day,
      end.hour,
      end.minute,
    );

    return slotDateTime.isAfter(startDT) && slotDateTime.isBefore(endDT);
  }

  TimeOfDay _parseTime(Map<String, dynamic> data) {
    return TimeOfDay(hour: data["hour"] ?? 0, minute: data["minute"] ?? 0);
  }

  String _getBlockName() {
    if (calendarData == null ||
        !calendarData!.containsKey("availableDays") ||
        profesionalId.isEmpty) return '';

    final availableDays = calendarData!["availableDays"] as List<dynamic>;
    final dayName =
        DateFormat("EEEE", "es_MX").format(slotDateTime).toLowerCase();

    final dayData = availableDays.firstWhere(
      (d) => (d["day"] as String).toLowerCase() == dayName,
      orElse: () => null,
    );

    if (dayData == null || !dayData.containsKey("bloqueos")) return '';

    final bloqueos = dayData["bloqueos"] as List<dynamic>;
    for (var b in bloqueos) {
      final start = DateTime(
        slotDateTime.year,
        slotDateTime.month,
        slotDateTime.day,
        b["startHour"],
        b["startMinute"],
      );
      final end = DateTime(
        slotDateTime.year,
        slotDateTime.month,
        slotDateTime.day,
        b["endHour"],
        b["endMinute"],
      );
      if (!slotDateTime.isBefore(start) && slotDateTime.isBefore(end)) {
        return b["nombre"] ?? '';
      }
    }

    return '';
  }
}
