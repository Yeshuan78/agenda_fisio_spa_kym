import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:agenda_fisio_spa_kym/models/appointment_model.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class AgendaSemanalColumnView extends StatelessWidget {
  final List<AppointmentModel> citas;
  final DateTime semanaInicio;
  final void Function(AppointmentModel cita)? onEditar;
  final void Function(AppointmentModel cita)? onCancelar;

  const AgendaSemanalColumnView({
    super.key,
    required this.citas,
    required this.semanaInicio,
    this.onEditar,
    this.onCancelar,
  });

  @override
  Widget build(BuildContext context) {
    final diasSemana =
        List.generate(7, (i) => semanaInicio.add(Duration(days: i)));
    final Map<String, List<AppointmentModel>> porDia = {
      for (var d in diasSemana) DateFormat('yyyy-MM-dd').format(d): [],
    };

    for (var cita in citas) {
      if (cita.fechaInicio == null) continue;
      final clave = DateFormat('yyyy-MM-dd').format(cita.fechaInicio!);
      if (porDia.containsKey(clave)) {
        porDia[clave]!.add(cita);
      }
    }

    return Row(
      children: diasSemana.map((dia) {
        final clave = DateFormat('yyyy-MM-dd').format(dia);
        final lista = porDia[clave]!;

        return Flexible(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 4),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: kBrandPurple.withOpacity(0.2)),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  DateFormat.EEEE('es_MX').format(dia),
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: kBrandPurple,
                  ),
                ),
                Text(
                  DateFormat('dd MMM').format(dia),
                  style: const TextStyle(fontSize: 13, color: Colors.black54),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: ListView(
                    shrinkWrap: true,
                    children: lista.map((cita) => _buildCard(cita)).toList(),
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildCard(AppointmentModel cita) {
    final hora = cita.fechaInicio != null
        ? DateFormat('HH:mm').format(cita.fechaInicio!)
        : 'Sin hora';
    final cliente = cita.clientName;
    final estado = cita.estadoCita;
    final servicio = cita.servicio;
    final profesional = cita.nombreProfesional;

    final color = _getEstadoColor(estado);

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(hora, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 2),
            Text(cliente, style: const TextStyle(fontSize: 13)),
            if (servicio.isNotEmpty)
              Text(servicio,
                  style: const TextStyle(fontSize: 12, color: Colors.black54)),
            if (profesional.isNotEmpty)
              Text(profesional,
                  style: const TextStyle(
                      fontSize: 12,
                      fontStyle: FontStyle.italic,
                      color: Colors.black45)),
            const SizedBox(height: 6),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(
                    estado.toUpperCase(),
                    style: const TextStyle(color: Colors.white, fontSize: 10),
                  ),
                ),
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(FontAwesomeIcons.penToSquare, size: 13),
                      color: Colors.blueGrey,
                      onPressed: () => onEditar?.call(cita),
                      tooltip: 'Editar',
                    ),
                    IconButton(
                      icon: const Icon(FontAwesomeIcons.trashCan, size: 13),
                      color: Colors.red,
                      onPressed: () => onCancelar?.call(cita),
                      tooltip: 'Cancelar',
                    ),
                  ],
                )
              ],
            ),
          ],
        ),
      ),
    );
  }

  Color _getEstadoColor(String estado) {
    switch (estado.toLowerCase()) {
      case 'confirmado':
        return Colors.green;
      case 'reservado':
        return Colors.orange;
      case 'cancelado':
        return Colors.red;
      case 'en camino':
        return Colors.blue;
      case 'asistida':
        return Colors.teal;
      case 'no asistida':
        return Colors.brown;
      default:
        return Colors.grey;
    }
  }
}
