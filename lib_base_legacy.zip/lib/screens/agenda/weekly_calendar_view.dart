// weekly_calendar_view.dart — Parte 1 de 3
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/models/appointment_model.dart';
import 'package:agenda_fisio_spa_kym/screens/agenda/calendar_slot_widget.dart';

class WeeklyCalendarView extends StatelessWidget {
  final DateTime focusedDay;
  final int timeSlotInterval;
  final Map<DateTime, List<AppointmentModel>> events;
  final Map<String, dynamic>? calendarData;
  final String? profesionalPhoto;
  final DateTime selectedDay;

  final void Function(AppointmentModel cita) onCitaTap;
  final void Function(DateTime slotDate, bool isBlocked, String blockName)?
      onSlotTap;

  final VoidCallback onTimerIconTap;
  final VoidCallback onPreviousWeek;
  final VoidCallback onNextWeek;
  final void Function(DateTime)? onHeaderDayTap;

  const WeeklyCalendarView({
    super.key,
    required this.focusedDay,
    required this.timeSlotInterval,
    required this.events,
    required this.calendarData,
    required this.profesionalPhoto,
    required this.selectedDay,
    required this.onCitaTap,
    required this.onSlotTap,
    required this.onTimerIconTap,
    required this.onPreviousWeek,
    required this.onNextWeek,
    this.onHeaderDayTap,
  });

  @override
  Widget build(BuildContext context) {
    final List<DateTime> weekDays = List.generate(
      7,
      (i) => focusedDay.subtract(Duration(days: focusedDay.weekday - 1 - i)),
    );

    final DateTime startWeek = weekDays.first;
    final DateTime endWeek = weekDays.last;
    final String weekRange =
        "Semana del ${DateFormat("d").format(startWeek)} al ${DateFormat("d").format(endWeek)} de ${_capitalize(DateFormat("MMMM", "es_MX").format(startWeek))}";

    String calendarName = "Calendario General";
    if (calendarData != null) {
      if ((calendarData!["fullName"] ?? '').toString().trim().isNotEmpty) {
        calendarName = (calendarData!["fullName"] as String).trim();
      } else if ((calendarData!["calendarName"] ?? '')
          .toString()
          .trim()
          .isNotEmpty) {
        calendarName = (calendarData!["calendarName"] as String).trim();
      }
    }

    final List<String> timeSlots = _generateTimeSlots();
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: kBrandPurple, width: 1),
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2)),
        ],
      ),
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          _buildCalendarInfoHeader(context, calendarName, weekRange),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 55),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Table(
                    columnWidths: {
                      for (int i = 0; i < 7; i++)
                        i: const FixedColumnWidth(120),
                    },
                    children: [
                      TableRow(
                        children: weekDays
                            .map((d) => _buildDayHeaderCell(d))
                            .toList(),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 20),
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: IconButton(
                  icon: const Icon(Icons.timer),
                  onPressed: onTimerIconTap,
                  tooltip: "Cambiar intervalo (actual: $timeSlotInterval min)",
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Table(
                  defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                  columnWidths: {
                    for (int i = 0; i < 7; i++) i: const FixedColumnWidth(120),
                  },
                  children: [
                    for (final time in timeSlots) _buildTimeRow(time, weekDays),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  TableRow _buildTimeRow(String time, List<DateTime> days) {
    return TableRow(
      children: days.map((day) {
        final parts = time.split(":");
        final hour = int.parse(parts[0]);
        final minute = int.parse(parts[1]);
        final slotDate = DateTime(day.year, day.month, day.day, hour, minute);
        final slotEnd = slotDate.add(Duration(minutes: timeSlotInterval));

        final key = DateTime(day.year, day.month, day.day);
        final citasModel = events[key]?.where((cita) {
              final inicio = cita.fechaInicio;
              return inicio != null &&
                  !inicio.isBefore(slotDate) &&
                  inicio.isBefore(slotEnd);
            }).toList() ??
            [];

        final isSelectedDay = day.year == selectedDay.year &&
            day.month == selectedDay.month &&
            day.day == selectedDay.day;

        return Container(
          decoration: BoxDecoration(
            color: isSelectedDay
                ? kAccentGreen.withAlpha((255 * 0.06).round())
                : null,
            borderRadius: BorderRadius.circular(6),
          ),
          child: CalendarSlotWidget(
            slotDateTime: slotDate,
            appointments: citasModel,
            profesionalId: calendarData?['profesionalId'] ?? '',
            calendarData: calendarData,
            onTap: onSlotTap,
            onCitaTap: onCitaTap,
          ),
        );
      }).toList(),
    );
  }

  Widget _buildCalendarInfoHeader(
      BuildContext context, String calendarName, String weekRange) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        IconButton(
          icon: const Icon(Icons.chevron_left),
          onPressed: onPreviousWeek,
        ),
        const SizedBox(width: 4),
        Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              calendarName,
              style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                    fontWeight: FontWeight.bold,
                    color: kBrandPurple,
                  ),
              textAlign: TextAlign.center,
            ),
            Text(
              weekRange,
              style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                    color: kBrandPurple,
                  ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        const SizedBox(width: 4),
        IconButton(
          icon: const Icon(Icons.chevron_right),
          onPressed: onNextWeek,
        ),
      ],
    );
  }

  Widget _buildDayHeaderCell(DateTime d) {
    final String dayName = DateFormat.EEEE('es_MX').format(d);
    final String dayDate = DateFormat('dd/MM').format(d);

    final bool isSelectedDay = d.year == selectedDay.year &&
        d.month == selectedDay.month &&
        d.day == selectedDay.day;

    return GestureDetector(
      onTap: () => onHeaderDayTap?.call(d),
      child: Container(
        width: 120,
        height: 50,
        margin: const EdgeInsets.symmetric(horizontal: 1, vertical: 2),
        decoration: BoxDecoration(
          color: isSelectedDay ? kAccentGreen : kBrandPurple,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              dayName,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
                fontSize: 12,
              ),
            ),
            Text(
              dayDate,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  List<String> _generateTimeSlots() {
    final start = DateTime(0, 0, 0, 7, 0);
    final end = DateTime(0, 0, 0, 22, 0);
    final slots = <String>[];
    var current = start;
    while (current.isBefore(end)) {
      slots.add(DateFormat.Hm().format(current));
      current = current.add(Duration(minutes: timeSlotInterval));
    }
    return slots;
  }

  String _capitalize(String input) {
    if (input.isEmpty) return input;
    return input[0].toUpperCase() + input.substring(1);
  }
}
