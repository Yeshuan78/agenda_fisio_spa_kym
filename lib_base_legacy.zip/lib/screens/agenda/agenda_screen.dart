// [agenda_screen.dart] – Sombra forzada con SizedBox(0.01) visible correctamente

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/services/firestore_agenda_service.dart';
import 'package:agenda_fisio_spa_kym/screens/agenda/monthly_calendar_compact.dart';
import 'package:agenda_fisio_spa_kym/screens/agenda/daily_events_list.dart';
import 'package:agenda_fisio_spa_kym/screens/agenda/weekly_grid_calendar.dart';
import 'package:agenda_fisio_spa_kym/screens/agenda/appointment_dialog.dart'
    as cita;
import 'package:agenda_fisio_spa_kym/widgets/edit_appointment_dialog.dart'
    as editar;
import 'package:agenda_fisio_spa_kym/models/appointment_model.dart';
import 'package:intl/intl.dart';

class AgendaScreen extends StatefulWidget {
  const AgendaScreen({super.key});

  @override
  State<AgendaScreen> createState() => _AgendaScreenState();
}

class _AgendaScreenState extends State<AgendaScreen> {
  final FirestoreAgendaService _agendaService = FirestoreAgendaService();
  DateTime _selectedDay = DateTime.now();
  DateTime _focusedDay = DateTime.now();
  Map<DateTime, List<AppointmentModel>> appointments = {};

  List<DocumentSnapshot> _listaClientes = [];
  List<DocumentSnapshot> _listaProfesionales = [];
  List<DocumentSnapshot> _listaServicios = [];

  @override
  void initState() {
    super.initState();
    _loadCitas();
    _loadClientes();
    _loadProfesionales();
    _loadServicios();
  }

  Future<void> _loadClientes() async {
    final docs = await _agendaService.loadClients();
    if (!mounted) return;
    setState(() => _listaClientes = docs);
  }

  Future<void> _loadCitas() async {
    final loaded = await _agendaService.loadCitas(null);
    final Map<DateTime, List<AppointmentModel>> result = {};
    for (final entry in loaded.entries) {
      for (final doc in entry.value) {
        final data = doc.data() as Map<String, dynamic>;
        final model = AppointmentModel.fromMap(data, doc.id);
        final f = model.fechaInicio;
        if (f != null) {
          final fechaKey = DateTime(f.year, f.month, f.day);
          result.putIfAbsent(fechaKey, () => []).add(model);
        }
      }
    }
    setState(() => appointments = result);
  }

  Future<void> _loadProfesionales() async {
    final docs = await _agendaService.loadProfesionalesFiltro();
    if (!mounted) return;
    setState(() => _listaProfesionales = docs);
  }

  Future<void> _loadServicios() async {
    final docs = await _agendaService.loadServicesFromCategories();
    if (!mounted) return;
    setState(() => _listaServicios = docs);
  }

  void _onDailyEventTap(AppointmentModel cita) async {
    await showDialog(
      context: context,
      builder: (_) => editar.EditAppointmentDialog(cita: cita),
    ).then((value) async {
      if (value == true) await _loadCitas();
    });
  }

  void _cambiarSemana(int offset) {
    setState(() {
      _selectedDay = _selectedDay.add(Duration(days: 7 * offset));
      _focusedDay = _selectedDay;
    });
  }

  String _formatearRangoSemana(DateTime inicio) {
    final fin = inicio.add(const Duration(days: 6));
    final f1 = DateFormat('d MMM', 'es_MX').format(inicio);
    final f2 = DateFormat('d MMM', 'es_MX').format(fin);
    return 'Semana del $f1 - $f2';
  }

  @override
  Widget build(BuildContext context) {
    final semanaInicio =
        _selectedDay.subtract(Duration(days: _selectedDay.weekday - 1));

    final semanaCitas = appointments.entries
        .where((entry) =>
            entry.key.isAfter(semanaInicio.subtract(const Duration(days: 1))) &&
            entry.key.isBefore(semanaInicio.add(const Duration(days: 7))))
        .expand((entry) => entry.value)
        .toList();

    return Container(
      color: kBackgroundColor,
      child: Column(
        children: [
          const SizedBox(height: 0.01), // ✅ fuerza render de sombra del AppBar
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 280,
                    child: Column(
                      children: [
                        MonthlyCalendarCompact(
                          selectedDay: _selectedDay,
                          focusedDay: _focusedDay,
                          onDaySelected: (d) => setState(() {
                            _selectedDay = d;
                            _focusedDay = d;
                          }),
                          events: appointments,
                        ),
                        const SizedBox(height: 12),
                        Expanded(
                          child: DailyEventsList(
                            citas: appointments[_selectedDay] ?? [],
                            onEditar: _onDailyEventTap,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            IconButton(
                              onPressed: () => _cambiarSemana(-1),
                              icon: const Icon(Icons.chevron_left),
                            ),
                            Text(
                              _formatearRangoSemana(semanaInicio),
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                            IconButton(
                              onPressed: () => _cambiarSemana(1),
                              icon: const Icon(Icons.chevron_right),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Expanded(
                          child: WeeklyGridCalendar(
                            semanaInicio: semanaInicio,
                            citas: semanaCitas,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomRight,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: FloatingActionButton(
                backgroundColor: kBrandPurple,
                onPressed: () async {
                  await showDialog(
                    context: context,
                    builder: (_) => cita.AppointmentDialog(
                      fechaSeleccionada: null,
                      listaClientes: _listaClientes,
                      listaProfesionales: _listaProfesionales,
                      listaServicios: _listaServicios,
                    ),
                  ).then((value) async {
                    if (value == true) await _loadCitas();
                  });
                },
                child: const Icon(Icons.add),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
