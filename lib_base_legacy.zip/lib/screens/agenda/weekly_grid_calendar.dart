import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/models/appointment_model.dart';
import 'package:agenda_fisio_spa_kym/widgets/edit_appointment_dialog.dart'
    as editar;

class WeeklyGridCalendar extends StatefulWidget {
  final DateTime semanaInicio;
  final List<AppointmentModel> citas;

  const WeeklyGridCalendar({
    super.key,
    required this.semanaInicio,
    required this.citas,
  });

  @override
  State<WeeklyGridCalendar> createState() => _WeeklyGridCalendarState();
}

class _WeeklyGridCalendarState extends State<WeeklyGridCalendar> {
  final ScrollController _scrollController = ScrollController();

  final TimeOfDay inicioLaboral = const TimeOfDay(hour: 9, minute: 0);
  final TimeOfDay finLaboral = const TimeOfDay(hour: 18, minute: 0);

  int intervaloMinutos = 30;
  List<String> horas = [];
  List<DateTime> dias = [];
  Map<String, List<AppointmentModel>> agendaMap = {};

  @override
  void initState() {
    super.initState();
    _recalcularGrid();
    WidgetsBinding.instance
        .addPostFrameCallback((_) => _scrollAlInicioLaboral());
  }

  @override
  void didUpdateWidget(covariant WeeklyGridCalendar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.semanaInicio != oldWidget.semanaInicio ||
        widget.citas != oldWidget.citas) {
      _recalcularGrid();
      setState(() {});
    }
  }

  void _recalcularGrid() {
    horas = _generarBloquesHorario(intervaloMinutos);
    dias = List.generate(7, (i) => widget.semanaInicio.add(Duration(days: i)));
    agendaMap = _mapearCitas();
  }

  List<String> _generarBloquesHorario(int intervalo) {
    final bloques = <String>[];
    for (int h = 0; h < 24; h++) {
      for (int m = 0; m < 60; m += intervalo) {
        bloques.add(
            '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}');
      }
    }
    return bloques;
  }

  double get alturaFila => 42.0;

  void _scrollAlInicioLaboral() {
    final index = _getIndexHora(inicioLaboral);
    _scrollController.jumpTo(index * alturaFila);
  }

  int _getIndexHora(TimeOfDay hora) {
    return (hora.hour * (60 ~/ intervaloMinutos)) +
        (hora.minute >= intervaloMinutos ? 1 : 0);
  }

  bool isDentroHorarioLaboral(String hora) {
    final tiempo = TimeOfDay(
      hour: int.parse(hora.split(':')[0]),
      minute: int.parse(hora.split(':')[1]),
    );
    return (tiempo.hour > inicioLaboral.hour ||
            (tiempo.hour == inicioLaboral.hour &&
                tiempo.minute >= inicioLaboral.minute)) &&
        (tiempo.hour < finLaboral.hour ||
            (tiempo.hour == finLaboral.hour && tiempo.minute == 0));
  }

  Map<String, List<AppointmentModel>> _mapearCitas() {
    final Map<String, List<AppointmentModel>> map = {};
    for (final cita in widget.citas) {
      if (cita.fechaInicio == null) continue;
      final f = cita.fechaInicio!;
      final key =
          '${DateFormat('yyyy-MM-dd').format(f)}|${DateFormat('HH:mm').format(f)}';
      map.putIfAbsent(key, () => []).add(cita);
    }
    return map;
  }

  Color _getEstadoColor(String estado) {
    switch (estado.toLowerCase()) {
      case 'confirmada':
        return Colors.green;
      case 'reservada':
        return Colors.orange;
      case 'cancelada':
        return Colors.red;
      case 'en camino':
        return Colors.blue;
      case 'asistida':
        return Colors.teal;
      case 'no asistida':
        return Colors.brown;
      default:
        return Colors.grey;
    }
  }

  void _editarCita(BuildContext context, AppointmentModel cita) async {
    await showDialog(
      context: context,
      builder: (_) => editar.EditAppointmentDialog(cita: cita),
    );
  }

  Widget _buildHoverChip(
      BuildContext context, AppointmentModel cita, int span) {
    final color = _getEstadoColor(cita.estadoCita);
    return Tooltip(
      message:
          '${cita.clientName} con ${cita.nombreProfesional}\n${DateFormat('HH:mm').format(cita.fechaInicio!)} — ${cita.estadoCita}',
      padding: const EdgeInsets.all(8),
      textStyle: const TextStyle(fontSize: 11, color: Colors.white),
      decoration: BoxDecoration(
        color: Colors.black87,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Container(
        width: double.infinity,
        height: alturaFila * span,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
        decoration: BoxDecoration(
          color: color.withAlpha((255 * 0.15).toInt()),
          border: Border.all(color: color),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                cita.clientName,
                overflow: TextOverflow.ellipsis,
                style:
                    const TextStyle(fontSize: 10, fontWeight: FontWeight.w600),
              ),
            ),
            GestureDetector(
              onTap: () => _editarCita(context, cita),
              child: const Icon(Icons.edit, size: 12, color: Colors.black87),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          // Encabezado de días y selector de intervalo
          Row(
            children: [
              const SizedBox(width: 80),
              DropdownButton<int>(
                value: intervaloMinutos,
                icon: const Icon(Icons.access_time),
                onChanged: (value) {
                  if (value != null) {
                    setState(() {
                      intervaloMinutos = value;
                      _recalcularGrid();
                    });
                  }
                },
                items: const [
                  DropdownMenuItem(value: 15, child: Text('15 min')),
                  DropdownMenuItem(value: 30, child: Text('30 min')),
                  DropdownMenuItem(value: 45, child: Text('45 min')),
                  DropdownMenuItem(value: 60, child: Text('60 min')),
                ],
              ),
            ],
          ),
          Table(
            border: TableBorder.symmetric(
              inside: BorderSide(color: kBrandPurple.withOpacity(0.3)),
            ),
            columnWidths: const {
              0: FixedColumnWidth(80),
            },
            children: [
              TableRow(
                children: [
                  const SizedBox(),
                  ...dias.map(
                    (dia) => Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      alignment: Alignment.center,
                      child: Column(
                        children: [
                          Text(
                            DateFormat.EEEE('es_MX').format(dia),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                              color: kBrandPurple,
                            ),
                          ),
                          Text(
                            DateFormat('dd MMM', 'es_MX').format(dia),
                            style: const TextStyle(fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ],
          ),
          const SizedBox(height: 6),
          Expanded(
            child: SingleChildScrollView(
              controller: _scrollController,
              child: Table(
                border: TableBorder.all(color: kBrandPurple.withOpacity(0.2)),
                columnWidths: const {
                  0: FixedColumnWidth(80),
                },
                children: horas.map((hora) {
                  return TableRow(
                    children: [
                      // Hora
                      Container(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        alignment: Alignment.centerRight,
                        child: Text(
                          hora,
                          style: TextStyle(
                            fontSize: 12,
                            color: isDentroHorarioLaboral(hora)
                                ? Colors.black87
                                : Colors.black38,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      // Celdas
                      ...dias.map((dia) {
                        final key =
                            '${DateFormat('yyyy-MM-dd').format(dia)}|$hora';
                        final citas = agendaMap[key] ?? [];
                        final activa = isDentroHorarioLaboral(hora);

                        return Container(
                          height: alturaFila,
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            color:
                                activa ? Colors.white : const Color(0xFFE0E0E0),
                          ),
                          child: Wrap(
                            spacing: 4,
                            runSpacing: 2,
                            children: [
                              ...citas.map((cita) {
                                final dur = cita.duracion ?? 30;
                                final span = (dur / intervaloMinutos).ceil();
                                return _buildHoverChip(context, cita, span);
                              }),
                            ],
                          ),
                        );
                      }),
                    ],
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
