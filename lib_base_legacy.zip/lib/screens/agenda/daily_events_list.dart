// daily_events_list.dart — Versión Trello-Style
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:agenda_fisio_spa_kym/models/appointment_model.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class DailyEventsList extends StatelessWidget {
  final List<AppointmentModel> citas;
  final void Function(AppointmentModel cita)? onEditar;
  final void Function(AppointmentModel cita)? onCancelar;

  const DailyEventsList({
    super.key,
    required this.citas,
    this.onEditar,
    this.onCancelar,
  });

  @override
  Widget build(BuildContext context) {
    if (citas.isEmpty) {
      return const Center(child: Text("No hay citas programadas."));
    }

    return ListView.separated(
      itemCount: citas.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      itemBuilder: (context, index) {
        final cita = citas[index];

        final nombreCliente = cita.clientName;
        final nombreProfesional = cita.nombreProfesional;
        final servicio = cita.servicio;
        final fecha = cita.fechaInicio != null
            ? DateFormat('HH:mm').format(cita.fechaInicio!)
            : 'Sin hora';
        final estado = cita.estadoCita;

        final resumenTooltip =
            "Cliente: $nombreCliente\nServicio: $servicio\nHorario: $fecha\nProfesional: $nombreProfesional\nEstado: $estado";

        return MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: resumenTooltip,
            decoration: BoxDecoration(
              color: Colors.black87,
              borderRadius: BorderRadius.circular(6),
            ),
            textStyle: const TextStyle(color: Colors.white),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: kBrandPurple.withOpacity(0.2)),
                borderRadius: BorderRadius.circular(14),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 3,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(FontAwesomeIcons.clock,
                      size: 16, color: kBrandPurple),
                  const SizedBox(width: 8),
                  Text(
                    fecha,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          nombreCliente,
                          style: const TextStyle(
                              fontWeight: FontWeight.w600, fontSize: 14),
                        ),
                        if (servicio.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 2),
                            child: Text(servicio,
                                style: const TextStyle(
                                    fontSize: 12, color: Colors.black54)),
                          ),
                        if (nombreProfesional.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 2),
                            child: Text(nombreProfesional,
                                style: const TextStyle(
                                    fontSize: 12,
                                    fontStyle: FontStyle.italic,
                                    color: Colors.black45)),
                          ),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: _getEstadoColor(cita.estadoCita),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Text(
                          estado.toUpperCase(),
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 10),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            tooltip: 'Editar cita',
                            icon: const Icon(FontAwesomeIcons.penToSquare,
                                size: 16),
                            color: Colors.blueGrey,
                            onPressed: () => onEditar?.call(cita),
                          ),
                          const SizedBox(width: 6),
                          IconButton(
                            tooltip: 'Cancelar cita',
                            icon:
                                const Icon(FontAwesomeIcons.trashCan, size: 16),
                            color: Colors.red[400],
                            onPressed: () => onCancelar?.call(cita),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Color _getEstadoColor(String estado) {
    switch (estado.toLowerCase()) {
      case 'confirmado':
        return Colors.green;
      case 'reservado':
        return Colors.orange;
      case 'cancelado':
        return Colors.red;
      case 'en camino':
        return Colors.blue;
      default:
        return Colors.grey;
    }
  }
}
