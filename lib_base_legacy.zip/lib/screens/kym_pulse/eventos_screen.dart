import 'package:flutter/material.dart';
import '../../models/evento_model.dart';
import '../../services/evento_service.dart';
import '../../widgets/eventos/evento_card.dart';

class EventosScreen extends StatefulWidget {
  const EventosScreen({super.key});

  @override
  State<EventosScreen> createState() => _EventosScreenState();
}

class _EventosScreenState extends State<EventosScreen> {
  List<EventoModel> _eventos = [];

  @override
  void initState() {
    super.initState();
    cargarEventos();
  }

  Future<void> cargarEventos() async {
    final eventos = await EventoService().getEventos();
    setState(() {
      _eventos = eventos;
    });
  }

  void _editarEvento(EventoModel evento) {
    // lógica de edición
    print('Editar: ${evento.nombre}');
  }

  void _eliminarEvento(EventoModel evento) {
    // lógica de eliminación
    print('Eliminar: ${evento.nombre}');
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: Text(
            'Eventos corporativos',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: _eventos.length,
            itemBuilder: (context, index) {
              final evento = _eventos[index];
              return EventoCard(
                evento: evento,
                onEdit: () => _editarEvento(evento), // ✅ CAMBIO
                onDelete: () => _eliminarEvento(evento), // ✅ CAMBIO
              );
            },
          ),
        ),
        const SizedBox(height: 16),
        Align(
          alignment: Alignment.centerRight,
          child: ElevatedButton.icon(
            onPressed: () {
              // TODO: abrir dialog o navegar a formulario nuevo
            },
            icon: const Icon(Icons.add),
            label: const Text('Nuevo evento'),
          ),
        ),
      ],
    );
  }
}
