import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/widgets/kym_pulse/pulse_dashboard_resumen.dart';
import 'package:agenda_fisio_spa_kym/widgets/kym_pulse/pulse_dashboard_resumen_alt.dart';
import 'package:agenda_fisio_spa_kym/widgets/kym_pulse/pulse_card.dart';
import 'package:agenda_fisio_spa_kym/models/evento_model.dart';

class KymPulseDashboard extends StatefulWidget {
  const KymPulseDashboard({super.key});

  @override
  State<KymPulseDashboard> createState() => _KymPulseDashboardState();
}

class _KymPulseDashboardState extends State<KymPulseDashboard> {
  bool mostrarResumenAlterno = false;

  int totalRegistros = 0;
  int totalEventos = 0;
  int totalProfesionales = 0;
  int totalServicios = 0;
  int totalCombinaciones = 0;
  int eventosSinRegistros = 0;

  List<EventoModel> eventos = [];
  Map<String, Map<String, int>> registrosPorEvento = {};
  Map<String, String> serviciosNombres = {};
  Map<String, String> profesionalesNombres = {};

  @override
  void initState() {
    super.initState();
    _cargarDatos();
  }

  Future<void> _cargarDatos() async {
    final registrosSnap =
        await FirebaseFirestore.instance.collectionGroup('registros').get();

    final servicios = <String>{};
    final profesionales = <String>{};
    final agrupado = <String, Map<String, int>>{};
    final combinaciones = <String>{};

    for (final doc in registrosSnap.docs) {
      final data = doc.data();
      final eventoId = data['eventoId'] ?? '';
      final servicioId = data['servicioId'] ?? 'sin_servicio';
      final profesionalId = data['profesionalId'] ?? 'sin_profesional';
      final key = '$servicioId|$profesionalId';

      servicios.add(servicioId);
      profesionales.add(profesionalId);
      combinaciones.add('$eventoId|$key');

      agrupado.putIfAbsent(eventoId, () => {});
      agrupado[eventoId]![key] = (agrupado[eventoId]![key] ?? 0) + 1;
    }

    final eventosSnap = await FirebaseFirestore.instance
        .collection('eventos')
        .orderBy('fecha', descending: true)
        .get();

    final snapServicios =
        await FirebaseFirestore.instance.collection('services').get();

    final snapProfes =
        await FirebaseFirestore.instance.collection('profesionales').get();

    final mapServicios = {
      for (var doc in snapServicios.docs)
        doc.id: doc.data()['name']?.toString() ?? doc.id
    };

    final mapProfes = {
      for (var doc in snapProfes.docs)
        doc.id: doc.data()['nombre']?.toString() ?? doc.id
    };

    final eventosList = eventosSnap.docs
        .map((e) => EventoModel.fromMap(e.data(), e.id))
        .toList();

    final sinRegistros =
        eventosList.where((e) => !(agrupado.containsKey(e.id))).length;

    setState(() {
      totalRegistros = registrosSnap.docs.length;
      totalServicios = servicios.length;
      totalProfesionales = profesionales.length;
      totalEventos = eventosList.length;
      eventos = eventosList;
      registrosPorEvento = agrupado;
      serviciosNombres = mapServicios;
      profesionalesNombres = mapProfes;
      totalCombinaciones = combinaciones.length;
      eventosSinRegistros = sinRegistros;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 24), // espacio para sombra institucional
        Expanded(
          child: Center(
            child: Container(
              width: 1000,
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Center(
                          child: Text(
                            'Resumen de registros KYM Pulse',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: kBrandPurple,
                            ),
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.sync_alt),
                        tooltip: 'Cambiar resumen',
                        onPressed: () {
                          setState(() {
                            mostrarResumenAlterno = !mostrarResumenAlterno;
                          });
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  if (!mostrarResumenAlterno)
                    PulseDashboardResumen(
                      totalRegistros: totalRegistros,
                      totalEventos: totalEventos,
                      totalProfesionales: totalProfesionales,
                      totalServicios: totalServicios,
                    )
                  else
                    PulseDashboardResumenAlt(
                      totalEventos: totalEventos,
                      totalRegistros: totalRegistros,
                      totalCombinaciones: totalCombinaciones,
                      eventosSinRegistros: eventosSinRegistros,
                    ),
                  const SizedBox(height: 32),
                  const Text(
                    'Eventos recientes',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Expanded(
                    child: ListView.separated(
                      itemCount: eventos.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 16),
                      itemBuilder: (context, index) {
                        final evento = eventos[index];
                        return PulseCard(evento: evento);
                      },
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
