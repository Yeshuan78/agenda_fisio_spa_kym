import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/widgets/dev_tools/encuesta_editor_widget.dart';
import 'package:http/http.dart' as http;

class AdminToolsScreen extends StatelessWidget {
  const AdminToolsScreen({super.key});

  void _ejecutarFuncion(
      BuildContext context, String url, String nombreProceso) async {
    final scaffold = ScaffoldMessenger.of(context);
    scaffold.showSnackBar(
      const SnackBar(content: Text('Ejecutando función...')),
    );

    try {
      final response = await http.get(Uri.parse(url));
      scaffold.showSnackBar(
        const SnackBar(content: Text('✅ Resultado ejecutada')),
      );
    } catch (e) {
      scaffold.showSnackBar(
        const SnackBar(content: Text('❌ Error ejecutando función')),
      );
    }
  }

  void _confirmarYReset(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('¿Estás seguro?'),
        content: const Text(
            'Esto eliminará los arrays de professionalIds en todos los servicios. ¿Deseas continuar?'),
        actions: [
          TextButton(
            child: const Text('Cancelar'),
            onPressed: () => Navigator.pop(context),
          ),
          ElevatedButton(
            child: const Text('Confirmar'),
            onPressed: () {
              Navigator.pop(context);
              _ejecutarFuncion(
                context,
                'https://us-central1-fisiospakym-afff6.cloudfunctions.net/resetProfessionalIds',
                'Reset de relaciones',
              );
            },
          ),
        ],
      ),
    );
  }

  void _abrirDialogoEncuesta(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        insetPadding: const EdgeInsets.all(32),
        child: SizedBox(
          width: 700,
          height: 600,
          child: Scaffold(
            appBar: AppBar(
              automaticallyImplyLeading: false,
              title: const Text('Editor de encuesta del micrositio'),
              actions: [
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                )
              ],
            ),
            body: const EncuestaEditorWidget(),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Herramientas administrativas')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: ListView(
          children: [
            const Text(
              'Tareas de mantenimiento del sistema',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              icon: const Icon(Icons.build),
              label: const Text(
                  'Migrar profesionales (servicios + especialidades)'),
              onPressed: () => _ejecutarFuncion(
                context,
                'https://us-central1-fisiospakym-afff6.cloudfunctions.net/migrarProfesionales',
                'Migración de profesionales',
              ),
              style:
                  ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              icon: const Icon(Icons.link),
              label: const Text('Vincular servicios con profesionales'),
              onPressed: () => _ejecutarFuncion(
                context,
                'https://us-central1-fisiospakym-afff6.cloudfunctions.net/vincularServiciosConProfesionales',
                'Vinculación de servicios',
              ),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              icon: const Icon(Icons.cleaning_services),
              label: const Text('Reset de relaciones (professionalIds)'),
              onPressed: () => _confirmarYReset(context),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
            ),
            const SizedBox(height: 40),
            const Divider(),
            const SizedBox(height: 12),
            const Text(
              'Micrositio – Encuestas',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              icon: const Icon(Icons.edit_note),
              label: const Text('Editar preguntas de encuesta'),
              onPressed: () => _abrirDialogoEncuesta(context),
            ),
          ],
        ),
      ),
    );
  }
}
