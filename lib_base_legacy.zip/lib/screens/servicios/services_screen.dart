import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ServicesScreen extends StatefulWidget {
  const ServicesScreen({Key? key}) : super(key: key);

  @override
  State<ServicesScreen> createState() => _ServicesScreenState();
}

class _ServicesScreenState extends State<ServicesScreen> {
  final List<String> _categorias = [
    'Faciales',
    'Masajes',
    'Fisioterapia',
    'Podología'
  ];
  String? _categoriaExpandida;

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).primaryColor;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: primaryColor,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(12)),
        ),
        title: const Text('Servicios'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: _categorias.map((categoria) {
          bool estaExpandida = _categoriaExpandida == categoria;
          return GestureDetector(
            onTap: () {
              setState(() {
                _categoriaExpandida = estaExpandida ? null : categoria;
              });
            },
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 10),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          categoria,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: primaryColor,
                          ),
                        ),
                      ),
                      Icon(
                        estaExpandida
                            ? Icons.keyboard_arrow_up
                            : Icons.keyboard_arrow_down,
                        color: Colors.grey,
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  if (estaExpandida)
                    StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance
                          .collection('categories')
                          .doc(categoria)
                          .collection('services')
                          .snapshots(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return const Center(
                              child: CircularProgressIndicator());
                        }
                        final docs = snapshot.data?.docs ?? [];
                        if (docs.isEmpty) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text(
                                  'No hay servicios registrados.',
                                  style: TextStyle(color: Colors.grey),
                                ),
                                TextButton.icon(
                                  onPressed: () => _crearServicio(categoria),
                                  icon: const Icon(Icons.add, size: 18),
                                  label: const Text('Agregar'),
                                  style: TextButton.styleFrom(
                                    foregroundColor: primaryColor,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }
                        return ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: docs.length,
                          itemBuilder: (context, index) {
                            final data =
                                docs[index].data() as Map<String, dynamic>;
                            final docId = docs[index].id;
                            return ListTile(
                              leading: data['image'] != null &&
                                      data['image'].toString().isNotEmpty
                                  ? ClipRRect(
                                      borderRadius: BorderRadius.circular(8),
                                      child: Image.network(
                                        data['image'],
                                        width: 60,
                                        height: 60,
                                        fit: BoxFit.cover,
                                        errorBuilder:
                                            (context, error, stackTrace) =>
                                                const Icon(Icons.broken_image),
                                      ),
                                    )
                                  : const Icon(Icons.image_not_supported,
                                      size: 40, color: Colors.grey),
                              title:
                                  Text(data['name'] ?? 'Servicio sin nombre'),
                              subtitle: Text(
                                  "Duración: ${data['duration']} min • \$${data['price']}"),
                              trailing: IconButton(
                                icon: const Icon(Icons.edit),
                                onPressed: () =>
                                    _editarServicio(categoria, docId, data),
                              ),
                            );
                          },
                        );
                      },
                    ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  void _crearServicio(String categoriaSeleccionada) {
    final nameCtrl = TextEditingController();
    final durationCtrl = TextEditingController();
    final priceCtrl = TextEditingController();
    final descriptionCtrl = TextEditingController();
    final imageCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Nuevo Servicio'),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                    controller: nameCtrl,
                    decoration: const InputDecoration(labelText: 'Nombre')),
                TextField(
                  controller: durationCtrl,
                  decoration:
                      const InputDecoration(labelText: 'Duración (min)'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: priceCtrl,
                  decoration: const InputDecoration(labelText: 'Precio'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                    controller: descriptionCtrl,
                    decoration: const InputDecoration(
                        labelText: 'Descripción (opcional)')),
                TextField(
                    controller: imageCtrl,
                    decoration: const InputDecoration(
                        labelText: 'Imagen (URL opcional)')),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancelar')),
            ElevatedButton(
              onPressed: () async {
                await FirebaseFirestore.instance
                    .collection('categories')
                    .doc(categoriaSeleccionada)
                    .collection('services')
                    .add({
                  'name': nameCtrl.text.trim(),
                  'duration': int.tryParse(durationCtrl.text.trim()) ?? 0,
                  'price': int.tryParse(priceCtrl.text.trim()) ?? 0,
                  'description': descriptionCtrl.text.trim(),
                  'image': imageCtrl.text.trim(),
                });
                Navigator.pop(ctx);
              },
              child: const Text('Guardar'),
            ),
          ],
        );
      },
    );
  }

  void _editarServicio(
      String categoria, String docId, Map<String, dynamic> data) {
    final nameCtrl = TextEditingController(text: data['name'] ?? '');
    final durationCtrl =
        TextEditingController(text: '${data['duration'] ?? ''}');
    final priceCtrl = TextEditingController(text: '${data['price'] ?? ''}');
    final descriptionCtrl =
        TextEditingController(text: data['description'] ?? '');
    final imageCtrl = TextEditingController(text: data['image'] ?? '');

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Editar Servicio'),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                    controller: nameCtrl,
                    decoration: const InputDecoration(labelText: 'Nombre')),
                TextField(
                  controller: durationCtrl,
                  decoration:
                      const InputDecoration(labelText: 'Duración (min)'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: priceCtrl,
                  decoration: const InputDecoration(labelText: 'Precio'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                    controller: descriptionCtrl,
                    decoration:
                        const InputDecoration(labelText: 'Descripción')),
                if (data['image'] != null &&
                    data['image'].toString().isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        data['image'],
                        width: 100,
                        height: 100,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) =>
                            const Icon(Icons.broken_image),
                      ),
                    ),
                  ),
                TextField(
                    controller: imageCtrl,
                    decoration: const InputDecoration(
                        labelText: 'Imagen (URL opcional)')),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cerrar')),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () async {
                await FirebaseFirestore.instance
                    .collection('categories')
                    .doc(categoria)
                    .collection('services')
                    .doc(docId)
                    .delete();
                Navigator.pop(ctx);
              },
            ),
            ElevatedButton(
              onPressed: () async {
                await FirebaseFirestore.instance
                    .collection('categories')
                    .doc(categoria)
                    .collection('services')
                    .doc(docId)
                    .update({
                  'name': nameCtrl.text.trim(),
                  'duration': int.tryParse(durationCtrl.text.trim()) ?? 0,
                  'price': int.tryParse(priceCtrl.text.trim()) ?? 0,
                  'description': descriptionCtrl.text.trim(),
                  'image': imageCtrl.text.trim(),
                });
                Navigator.pop(ctx);
              },
              child: const Text('Guardar'),
            )
          ],
        );
      },
    );
  }
}
