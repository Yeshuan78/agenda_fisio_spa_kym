import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

import 'package:agenda_fisio_spa_kym/theme/theme.dart';

import 'package:agenda_fisio_spa_kym/screens/reminders/widgets/reminder_card.dart';
import 'package:agenda_fisio_spa_kym/screens/reminders/widgets/reminder_filters_sidebar.dart';
import 'package:agenda_fisio_spa_kym/screens/reminders/widgets/message_templates_tab.dart';
import 'package:agenda_fisio_spa_kym/screens/reminders/widgets/resumen_envios_dashboard.dart';
import 'package:agenda_fisio_spa_kym/screens/reminders/widgets/citas_con_errores_dashboard.dart';
import 'package:agenda_fisio_spa_kym/screens/reminders/widgets/estado_citas_dashboard.dart';
import 'package:agenda_fisio_spa_kym/screens/reminders/widgets/automatic_reminder_settings_card.dart';
import 'package:agenda_fisio_spa_kym/screens/reminders/widgets/historial_envios_sidebar.dart';

import 'package:agenda_fisio_spa_kym/services/whatsapp_integration.dart';
import 'package:agenda_fisio_spa_kym/services/correo_service.dart';
import 'package:agenda_fisio_spa_kym/services/notificaciones_logger.dart';

class RemindersScreen extends StatefulWidget {
  const RemindersScreen({super.key});

  @override
  State<RemindersScreen> createState() => _RemindersScreenState();
}

class _RemindersScreenState extends State<RemindersScreen>
    with TickerProviderStateMixin {
  late final TabController _tabController;
  ReminderFilters _filtros = ReminderFilters();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      floatingActionButton: _tabController.index == 1
          ? FloatingActionButton.extended(
              icon: const Icon(Icons.send),
              label: const Text("Enviar a todos"),
              backgroundColor: kBrandPurple,
              onPressed: _confirmarEnvioMasivo,
            )
          : null,
      body: Column(
        children: [
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color: kBrandPurple,
              borderRadius: BorderRadius.circular(16),
            ),
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: const Center(
              child: Text(
                'Panel de Notificaciones',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            color: kBackgroundColor,
            child: TabBar(
              controller: _tabController,
              labelColor: kBrandPurple,
              unselectedLabelColor: Colors.black54,
              labelStyle: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
              unselectedLabelStyle: const TextStyle(
                fontWeight: FontWeight.normal,
                fontSize: 16,
              ),
              indicatorColor: Colors.white,
              indicatorWeight: 3,
              tabs: const [
                Tab(text: 'Dashboard'),
                Tab(text: 'Recordatorios'),
                Tab(text: 'Plantillas de mensajes'),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                // 📊 TAB 1: DASHBOARD
                SingleChildScrollView(
                  child: Column(
                    children: const [
                      ResumenEnviosDashboard(),
                      CitasConErroresDashboard(),
                      EstadoCitasDashboard(),
                    ],
                  ),
                ),

                // 📝 TAB 2: RECORDATORIOS
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Filtros
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: ReminderFiltersSidebar(
                        initialFilters: _filtros,
                        onFilterChanged: (f) {
                          setState(() {
                            _filtros = f;
                          });
                        },
                      ),
                    ),

                    // Lista de recordatorios
                    Expanded(child: _buildReminderList()),

                    // Columna derecha: Ajustes + Historial
                    const SizedBox(width: 16),
                    Container(
                      width: 300,
                      padding: const EdgeInsets.only(top: 16, right: 16),
                      child: Column(
                        children: const [
                          // Ajustes automáticos
                          Expanded(
                            child: AutomaticReminderSettingsCard(),
                          ),
                          SizedBox(height: 16),

                          // Historial de envíos
                          Expanded(
                            child: HistorialEnviosSidebar(),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                // 💬 TAB 3: PLANTILLAS
                const MessageTemplatesTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReminderList() {
    final query = FirebaseFirestore.instance.collection('bookings');
    Query base = query.orderBy('date', descending: true);

    if (_filtros.tipoUsuario?.isNotEmpty == true) {
      base = base.where('tipoUsuario', isEqualTo: _filtros.tipoUsuario);
    }
    if (_filtros.estado?.isNotEmpty == true) {
      base = base.where('status', isEqualTo: _filtros.estado);
    }
    if (_filtros.fechaDesde != null) {
      final iso = _filtros.fechaDesde!.toIso8601String();
      base = base.where('date', isGreaterThanOrEqualTo: iso);
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: StreamBuilder<QuerySnapshot>(
            stream: base.snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                return const Center(child: Text('No hay citas registradas.'));
              }

              final docs = snapshot.data!.docs;
              return ListView.builder(
                itemCount: docs.length,
                itemBuilder: (context, index) {
                  final doc = docs[index];
                  final data = doc.data() as Map<String, dynamic>;

                  final clientName = data['clientName'] ?? 'Sin nombre';
                  final status = data['status'] ?? 'Sin estado';
                  final telefono = data['clientPhone'] ?? '';
                  final correo = data['clientEmail'] ?? '';
                  final tipoUsuario = data['tipoUsuario'] ?? 'cliente';
                  final servicio =
                      data['serviceName'] ?? 'Servicio no definido';

                  final profesionalNombre = data['profesionalNombre'] ?? '';
                  final profesionalApellidos =
                      data['profesionalApellidos'] ?? '';
                  final nombreCompletoProfesional =
                      '$profesionalNombre $profesionalApellidos'.trim();

                  final dateString = data['date'] ?? '';
                  DateTime? dateTime;
                  try {
                    dateTime = DateTime.parse(dateString);
                  } catch (_) {
                    dateTime = null;
                  }

                  final fecha = dateTime != null
                      ? DateFormat.yMMMMd('es_MX').format(dateTime)
                      : 'Fecha inválida';
                  final hora = dateTime != null
                      ? DateFormat.Hm().format(dateTime)
                      : '--:--';

                  return ReminderCard(
                    nombreCliente: clientName,
                    estado: status,
                    fecha: fecha,
                    hora: hora,
                    whatsappEnviado: data['whatsappSent'] ?? false,
                    correoEnviado: data['emailSent'] ?? false,
                    telefonoCliente: telefono,
                    emailCliente: correo,
                    tipoUsuario: tipoUsuario,
                    nombreServicio: servicio,
                    nombreProfesional: nombreCompletoProfesional,
                    onMensajeReenviado: () {
                      debugPrint("Mensaje reenviado para $clientName");
                    },
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }

  Future<void> _confirmarEnvioMasivo() async {
    final confirmado = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("¿Enviar recordatorios masivos?"),
        content: const Text(
          "Se enviarán recordatorios por WhatsApp y correo a todas las citas con estado 'reservado' o 'confirmado'.",
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text("Cancelar")),
          ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text("Enviar")),
        ],
      ),
    );

    if (confirmado == true) {
      await _enviarRecordatoriosMasivos();
    }
  }

  Future<void> _enviarRecordatoriosMasivos() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('bookings')
        .where('status', whereIn: ['reservado', 'confirmado']).get();

    int enviadosWhatsApp = 0;
    int enviadosCorreo = 0;

    for (final doc in snapshot.docs) {
      final data = doc.data();
      final id = doc.id;

      final nombre = data['clientName'] ?? 'Cliente';
      final estado = (data['status'] ?? 'reservado').toLowerCase();
      final telefono = data['clientPhone'] ?? '';
      final correo = data['clientEmail'] ?? '';
      final tipoUsuario = (data['tipoUsuario'] ?? 'cliente').toLowerCase();
      final servicio = data['serviceName'] ?? 'Servicio no definido';

      final profesionalNombre = data['profesionalNombre'] ?? '';
      final profesionalApellidos = data['profesionalApellidos'] ?? '';
      final nombreProfesional =
          '$profesionalNombre $profesionalApellidos'.trim();

      final fechaRaw = data['date'] ?? '';
      DateTime? fechaCita;
      try {
        fechaCita = DateTime.parse(fechaRaw);
      } catch (_) {}

      final fecha = fechaCita != null
          ? DateFormat.yMMMMd('es_MX').format(fechaCita)
          : 'fecha';
      final hora =
          fechaCita != null ? DateFormat.Hm().format(fechaCita) : 'hora';

      final variables = {
        '{{nombre}}': nombre,
        '{{fecha}}': fecha,
        '{{hora}}': hora,
        '{{servicio}}': servicio,
        '{{profesional}}': nombreProfesional,
      };

      // WHATSAPP
      if (telefono.isNotEmpty && (data['whatsappSent'] != true)) {
        final snap = await FirebaseFirestore.instance
            .collection('notificaciones_config')
            .doc('templates')
            .collection('whatsapp_$tipoUsuario')
            .doc(estado)
            .get();

        if (snap.exists) {
          String mensaje = snap['mensaje'] ?? '';
          variables.forEach((k, v) => mensaje = mensaje.replaceAll(k, v));

          await WhatsAppIntegration.enviarMensajeTexto(
            telefono: telefono,
            mensaje: mensaje,
          );

          await doc.reference.update({'whatsappSent': true});
          await NotificacionesLogger.logEnvioMensaje(
            bookingId: id,
            canal: 'whatsapp',
            clienteNombre: nombre,
            estado: estado,
            mensaje: mensaje,
            tipoUsuario: tipoUsuario,
          );
          enviadosWhatsApp++;
        } else {
          debugPrint(
              '❌ No se encontró plantilla WhatsApp: $estado / $tipoUsuario');
        }
      }

      // CORREO
      if (correo.isNotEmpty && (data['emailSent'] != true)) {
        final snap = await FirebaseFirestore.instance
            .collection('notificaciones_config')
            .doc('templates')
            .collection('email_$tipoUsuario')
            .doc(estado)
            .get();

        if (snap.exists) {
          String mensaje = snap['mensaje'] ?? '';
          variables.forEach((k, v) => mensaje = mensaje.replaceAll(k, v));

          final enviado = await CorreoService.enviarCorreo(
            destinatario: correo,
            asunto: "Detalles de tu cita - Fisio Spa KYM",
            contenidoHtml: mensaje,
          );

          if (enviado) {
            await doc.reference.update({'emailSent': true});
            await NotificacionesLogger.logEnvioMensaje(
              bookingId: id,
              canal: 'email',
              clienteNombre: nombre,
              estado: estado,
              mensaje: mensaje,
              tipoUsuario: tipoUsuario,
            );
            enviadosCorreo++;
          }
        } else {
          debugPrint(
              '❌ No se encontró plantilla Correo: $estado / $tipoUsuario');
        }
      }
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          "📨 $enviadosWhatsApp WhatsApp enviados\n📧 $enviadosCorreo correos enviados",
        ),
        duration: const Duration(seconds: 4),
      ),
    );
  }
}
