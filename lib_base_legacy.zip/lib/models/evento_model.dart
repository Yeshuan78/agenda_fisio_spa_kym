// [Archivo: evento_model.dart]
import 'package:cloud_firestore/cloud_firestore.dart';

class EventoModel {
  final String id;
  final String? eventoId; // ✅ NUEVO
  final String nombre;
  final String empresa;
  final String? empresaId; // existente
  final String ubicacion;
  final DateTime fecha;
  final String estado;
  final String observaciones;
  final dynamic fechaCreacion; // existente
  final List<Map<String, String>> serviciosAsignados;

  EventoModel({
    required this.id,
    this.eventoId, // ✅ NUEVO
    required this.nombre,
    required this.empresa,
    this.empresaId,
    required this.ubicacion,
    required this.fecha,
    required this.estado,
    required this.observaciones,
    required this.serviciosAsignados,
    this.fechaCreacion,
  });

  // [Sección 1.1] – Convertir desde Firestore (ahora blindado)
  factory EventoModel.fromMap(Map<String, dynamic> map, String id) {
    final List<Map<String, String>> servicios = [];

    if (map['serviciosAsignados'] != null) {
      for (var item in (map['serviciosAsignados'] as List)) {
        servicios.add({
          'servicioId': item['servicioId']?.toString() ?? '',
          'profesionalId': item['profesionalId']?.toString() ?? '',
        });
      }
    }

    return EventoModel(
      id: id,
      eventoId: map['eventoId']?.toString(), // ✅ Blindado
      nombre: map['nombre'] ?? '',
      empresa: map['empresa'] ?? '',
      empresaId: map['empresaId']?.toString(),
      ubicacion: map['ubicacion'] ?? '',
      fecha: (map['fecha'] as Timestamp).toDate(),
      estado: map['estado'] ?? 'activo',
      observaciones: map['observaciones'] ?? '',
      serviciosAsignados: servicios,
      fechaCreacion: map['fechaCreacion'],
    );
  }

  // [Sección 1.2] – Convertir a Firestore (blindado)
  Map<String, dynamic> toMap() {
    return {
      'eventoId': eventoId,
      'nombre': nombre,
      'empresa': empresa,
      'empresaId': empresaId,
      'ubicacion': ubicacion,
      'fecha': Timestamp.fromDate(fecha),
      'estado': estado,
      'observaciones': observaciones,
      'fechaCreacion': fechaCreacion,
      'serviciosAsignados': serviciosAsignados
          .map((e) => {
                'servicioId': e['servicioId'] ?? '',
                'profesionalId': e['profesionalId'] ?? '',
              })
          .toList(),
    };
  }
}
