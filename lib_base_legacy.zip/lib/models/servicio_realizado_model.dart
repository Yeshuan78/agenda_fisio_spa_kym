// [Sección 1.1] – Modelo para servicios registrados vía QR

import 'package:cloud_firestore/cloud_firestore.dart';

class ServicioRealizadoModel {
  final String id;
  final String profesionalId;
  final String servicioId;
  final String eventoId;
  final DateTime timestamp;
  final Map<String, dynamic>? encuesta;
  final String? userAgent;
  final String? plataforma;

  ServicioRealizadoModel({
    required this.id,
    required this.profesionalId,
    required this.servicioId,
    required this.eventoId,
    required this.timestamp,
    this.encuesta,
    this.userAgent,
    this.plataforma,
  });

  // [Sección 1.2] – Convertir desde Firestore (con protección de timestamp)
  factory ServicioRealizadoModel.fromMap(Map<String, dynamic> map, String id) {
    final rawTimestamp = map['timestamp'];
    DateTime fecha = DateTime.now(); // Valor por defecto si no viene nada

    if (rawTimestamp is Timestamp) {
      fecha = rawTimestamp.toDate();
    }

    return ServicioRealizadoModel(
      id: id,
      profesionalId: map['profesionalId'] ?? '',
      servicioId: map['servicioId'] ?? '',
      eventoId: map['eventoId'] ?? '',
      timestamp: fecha,
      encuesta: map['encuesta'],
      userAgent: map['userAgent'],
      plataforma: map['plataforma'],
    );
  }

  // [Sección 1.3] – Convertir a Firestore
  Map<String, dynamic> toMap() {
    return {
      'profesionalId': profesionalId,
      'servicioId': servicioId,
      'eventoId': eventoId,
      'timestamp': Timestamp.fromDate(timestamp),
      'encuesta': encuesta,
      'userAgent': userAgent,
      'plataforma': plataforma,
    };
  }
}
