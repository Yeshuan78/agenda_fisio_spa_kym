import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class AppointmentModel {
  final String id;

  final String? nombreCliente;
  final String? clientEmail;
  final String? clientPhone;
  final String? profesionalId;
  final String? profesionalNombre;
  final String? servicioId;
  final String? servicioNombre;
  final String? estado;
  final String? comentarios;

  final DateTime? fechaInicio;
  final DateTime? fechaFin;
  final int? duracion; // ✅ NUEVO: duración del servicio

  AppointmentModel({
    required this.id,
    this.nombreCliente,
    this.clientEmail,
    this.clientPhone,
    this.profesionalId,
    this.profesionalNombre,
    this.servicioId,
    this.servicioNombre,
    this.estado,
    this.comentarios,
    this.fechaInicio,
    this.fechaFin,
    this.duracion, // ✅ NUEVO
  });

  factory AppointmentModel.fromDoc(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return AppointmentModel.fromMap(data, doc.id);
  }

  static AppointmentModel fromMap(Map<String, dynamic> data, String id) {
    return AppointmentModel(
      id: id,
      nombreCliente: data['clientName'] ?? data['clienteNombre'],
      clientEmail: data['clientEmail'],
      clientPhone: data['clientPhone'],
      profesionalId: data['profesionalId'],
      profesionalNombre: data['profesionalNombre'],
      servicioId: data['servicioId'],
      servicioNombre: data['servicioNombre'],
      estado: data['status'] ?? data['estado'],
      comentarios: data['comentarios'],
      fechaInicio: _parseDate(data['fecha'] ?? data['date']),
      fechaFin: _parseDate(data['endDate']),
      duracion: data['duracion'], // ✅ NUEVO
    );
  }

  static DateTime? _parseDate(dynamic value) {
    if (value == null) return null;
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) return DateTime.tryParse(value);
    return null;
  }

  Map<String, dynamic> toMap() {
    return {
      'clientName': nombreCliente,
      'clientEmail': clientEmail,
      'clientPhone': clientPhone,
      'profesionalId': profesionalId,
      'profesionalNombre': profesionalNombre,
      'servicioId': servicioId,
      'servicioNombre': servicioNombre,
      'status': estado,
      'comentarios': comentarios,
      'date': fechaInicio?.toIso8601String(),
      'endDate': fechaFin?.toIso8601String(),
      'duracion': duracion, // ✅ NUEVO
    };
  }

  // ========= Getters para mostrar datos formateados =========
  String get clientName => nombreCliente ?? '';
  String get servicio => servicioNombre ?? '';
  String get profesional => profesionalNombre ?? '';
  String get estadoCita => estado ?? 'Desconocido';

  String get horaCita {
    if (fechaInicio == null) return '';
    return DateFormat.Hm().format(fechaInicio!);
  }

  String get comentariosTexto => comentarios ?? '';
  String get nombreProfesional => profesionalNombre ?? '';
  String get hora => horaCita;
  String get date => fechaInicio?.toIso8601String() ?? '';

  String get fechaFormateada =>
      fechaInicio != null ? DateFormat('dd/MM/yyyy').format(fechaInicio!) : '';

  String get resumen => '''
Cliente: $clientName
Profesional: $profesional
Servicio: $servicio
Hora: $horaCita
Estado: $estadoCita
''';

  String get bookingId => id;
}
