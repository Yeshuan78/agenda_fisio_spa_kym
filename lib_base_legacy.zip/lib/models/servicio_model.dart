class ServicioModel {
  final String serviceId;
  final String name;
  final String? description;
  final String? category;
  final int? duration;
  final double? price;
  final String? image;
  final List<String>? professionalIds;

  ServicioModel({
    required this.serviceId,
    required this.name,
    this.description,
    this.category,
    this.duration,
    this.price,
    this.image,
    this.professionalIds,
  });

  factory ServicioModel.fromMap(Map<String, dynamic> data) {
    return ServicioModel(
      serviceId: data['serviceId'] ?? '',
      name: data['name'] ?? '',
      description: data['description'],
      category: data['category'],
      duration: data['duration'],
      price: (data['price'] != null)
          ? double.tryParse(data['price'].toString())
          : null,
      image: data['image'],
      professionalIds: List<String>.from(data['professionalIds'] ?? []),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'serviceId': serviceId,
      'name': name,
      'description': description,
      'category': category,
      'duration': duration,
      'price': price,
      'image': image,
      'professionalIds': professionalIds,
    };
  }
}
