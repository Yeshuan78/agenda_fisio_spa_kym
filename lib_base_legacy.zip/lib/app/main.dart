import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/widgets/layout/layout_shell.dart';

import 'package:agenda_fisio_spa_kym/screens/agenda/agenda_screen.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/clients_screen.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/client_crud_screen.dart';
import 'package:agenda_fisio_spa_kym/screens/profesionales/professionals_screen.dart';
import 'package:agenda_fisio_spa_kym/screens/reminders/reminders_screen.dart';
import 'package:agenda_fisio_spa_kym/screens/admin/admin_tools_screen.dart';
import 'package:agenda_fisio_spa_kym/screens/empresas/empresas_screen.dart';
import 'package:agenda_fisio_spa_kym/screens/contratos/contratos_screen.dart';
import 'package:agenda_fisio_spa_kym/screens/ventas/ventas_screen.dart';
import 'package:agenda_fisio_spa_kym/screens/campanas/campanas_screen.dart';
import 'package:agenda_fisio_spa_kym/screens/facturas/facturas_screen.dart';
import 'package:agenda_fisio_spa_kym/screens/cotizaciones/cotizaciones_screen.dart';
import 'package:agenda_fisio_spa_kym/screens/micrositio/micrositio_screen.dart';
import 'package:agenda_fisio_spa_kym/screens/kym_pulse/kym_pulse_dashboard.dart';
import 'package:agenda_fisio_spa_kym/screens/kym_pulse/eventos_screen.dart';

import 'package:agenda_fisio_spa_kym/app/firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await initializeDateFormatting('es_MX', null);

  runApp(const FisioSpaKYMApp());
}

class FisioSpaKYMApp extends StatelessWidget {
  const FisioSpaKYMApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fisio Spa KYM',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      locale: const Locale('es', 'MX'),
      supportedLocales: const [
        Locale('es', 'MX'),
        Locale('en', 'US'),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],

      // ✅ Previene que Flutter intente abrir rutas externas como iniciales
      initialRoute: '/',

      // ✅ Siempre renderiza desde el layout institucional
      home: const MainLayout(),
    );
  }
}

class MainLayout extends StatefulWidget {
  const MainLayout({super.key});

  @override
  State<MainLayout> createState() => _MainLayoutState();
}

class _MainLayoutState extends State<MainLayout> {
  late String _currentRoute;

  @override
  void initState() {
    super.initState();

    // ✅ Solo reconoce rutas explícitas, no intenta navegar erróneamente
    final path = Uri.base.path;
    _currentRoute = (path == '/' || path.isEmpty) ? '/agenda/semanal' : path;
  }

  void _navigateTo(String route) {
    setState(() => _currentRoute = route);
  }

  Widget _getPageByRoute(String route) {
    switch (route) {
      case '/clientes':
        return const ClientsScreen();
      case '/clientes/nuevo':
        return const ClientCrudScreen();
      case '/agenda/semanal':
        return const AgendaScreen();
      case '/agenda/diaria':
        return const Center(child: Text('Agenda Diaria'));
      case '/profesionales':
        return const ProfessionalsScreen();
      case '/profesionales/nuevo':
        return const ProfessionalsScreen(key: ValueKey('crear_nuevo'));
      case '/recordatorios':
        return const RemindersScreen();
      case '/admin':
        return const AdminToolsScreen();
      case '/empresas':
        return const EmpresasScreen();
      case '/contratos':
        return const ContratosScreen();
      case '/ventas':
        return const VentasScreen();
      case '/facturacion':
        return const FacturasScreen();
      case '/campanas':
        return const CampanasScreen();
      case '/cotizaciones':
        return const CotizacionesScreen();
      case '/micrositio/demo':
        return const MicrositioScreen(empresaId: 'demo123');
      case '/kympulse':
        return const KymPulseDashboard();
      case '/eventos':
        final empresaId = Uri.base.queryParameters['empresaId'];
        return const EventosScreen();
      default:
        return const Center(child: Text('Ruta no encontrada'));
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutShell(
      currentRoute: _currentRoute,
      onNavigate: _navigateTo,
      child: _getPageByRoute(_currentRoute),
    );
  }
}
