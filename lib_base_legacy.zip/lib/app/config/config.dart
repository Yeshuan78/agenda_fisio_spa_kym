// lib/config/config.dart

class AppConfig {
  // Datos SMTP (NO subir este archivo a control de versiones público)
  static const String smtpHost = 'smtp.hostinger.com';
  static const int smtpPort = 465;
  static const String smtpUsuario = 'citas@fisiospakym.com';
  static const String smtpContrasena = 'Elma\$ajerel@janteRules#citas2023';

  // Nombre del remitente que verán los clientes
  static const String nombreRemitente = 'Fisio Spa KYM';
}
