import 'package:flutter/material.dart';

/// 🎨 Colores base
const Color kBrandPurple = Color(0xFF9920A7);
const Color kBackgroundColor = Color(0xFFF5F5F9);
const Color kWhite = Color(0xFFFFFFFF);
const Color kAccentBlue = Color(0xFF4DB1E0);
const Color kAccentGreen = Color(0xFF8ABF54);
const Color kBorderColor = Color(0xFFCCAEE0);

/// 🌒 Sombras estándar del layout flotante (AppBar y Sidebar)
final List<BoxShadow> kSombraLateral = [
  BoxShadow(
    color: Colors.black12,
    offset: Offset(2, 0), // sombra derecha para Sidebar
    blurRadius: 6,
  ),
];

final List<BoxShadow> kSombraSuperior = [
  BoxShadow(
    color: Colors.black12,
    offset: Offset(0, 2), // sombra inferior para AppBar
    blurRadius: 6,
  ),
];

/// Fuente principal
const String kFontFamily = 'Poppins';

ThemeData buildAppTheme() {
  return ThemeData(
    primaryColor: kBrandPurple,
    scaffoldBackgroundColor: kBackgroundColor,
    fontFamily: kFontFamily,

    /// ✅ AppBar blanco con línea morada y sombra flotante
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.white,
      elevation: 3,
      shadowColor: Colors.black12,
      surfaceTintColor: Colors.transparent,
      iconTheme: IconThemeData(color: Colors.black87),
      titleTextStyle: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w600,
        color: Colors.black87,
        fontFamily: kFontFamily,
      ),
      shape: Border(
        bottom: BorderSide(color: kBrandPurple, width: 2), // 💜 Línea morada
      ),
    ),

    inputDecorationTheme: InputDecorationTheme(
      isDense: true,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      labelStyle: const TextStyle(fontSize: 13, color: Colors.black87),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: kBorderColor.withOpacity(0.5)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: kBrandPurple, width: 1.5),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: kBorderColor.withOpacity(0.3)),
      ),
    ),

    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: kBrandPurple,
        foregroundColor: Colors.white,
        elevation: 2,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    ),

    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: kBrandPurple,
        textStyle: const TextStyle(fontWeight: FontWeight.w500),
      ),
    ),

    cardTheme: CardTheme(
      color: Colors.white,
      shadowColor: Colors.black12,
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: kBorderColor.withOpacity(0.3)),
      ),
    ),

    dialogTheme: DialogTheme(
      backgroundColor: Colors.white,
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      titleTextStyle: const TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.bold,
        color: Colors.black87,
        fontFamily: kFontFamily,
      ),
    ),

    dividerColor: const Color(0xFFDDDDDD),
    iconTheme: const IconThemeData(color: Colors.black54),
    colorScheme: ColorScheme.fromSwatch().copyWith(
      primary: kBrandPurple,
      secondary: kBrandPurple, // 💜 fuerza kBrandPurple como principal
    ),
  );
}
