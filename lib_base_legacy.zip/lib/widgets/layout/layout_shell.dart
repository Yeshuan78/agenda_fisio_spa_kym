import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/widgets/custom_app_bar.dart';
import 'package:agenda_fisio_spa_kym/widgets/navigation/custom_sidebar_pro.dart';

class LayoutShell extends StatelessWidget {
  final Widget child;
  final String currentRoute;
  final void Function(String route) onNavigate;

  const LayoutShell({
    super.key,
    required this.child,
    required this.currentRoute,
    required this.onNavigate,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const CustomAppBar(),
          Expanded(
            child: Row(
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: kSombraLateral,
                  ),
                  child: CustomSidebarPro(
                    currentRoute: currentRoute,
                    onNavigate: onNavigate,
                  ),
                ),
                Expanded(
                  child: child,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
