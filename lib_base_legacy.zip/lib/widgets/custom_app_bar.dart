import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String? title;
  final List<Widget>? actions;

  const CustomAppBar({super.key, this.title, this.actions});

  @override
  Size get preferredSize => const Size.fromHeight(150); // altura visual deseada

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 24),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(
            color: kBrandPurple, // 💜 línea morada inferior
            width: 2,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Color(0x44000000), // 🟣 sombra suave debajo
            blurRadius: 10,
            offset: Offset(0, 6), // desplaza hacia abajo
          ),
        ],
      ),
      child: SafeArea(
        bottom: false,
        child: Stack(
          children: [
            Center(
              child: Image.asset(
                'assets/images/logo.png',
                height: 70, // ✅ tamaño visual del logo
                fit: BoxFit.contain,
              ),
            ),
            if (title != null)
              Positioned(
                left: 16,
                top: 18,
                child: Text(
                  title!,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    color: Colors.black87,
                  ),
                ),
              ),
            if (actions != null)
              Positioned(
                right: 16,
                top: 20,
                child: Row(children: actions!),
              ),
          ],
        ),
      ),
    );
  }
}
