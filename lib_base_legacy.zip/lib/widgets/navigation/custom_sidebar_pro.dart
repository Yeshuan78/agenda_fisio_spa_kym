// [Parte 1/3] – custom_sidebar_pro.dart

import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';

class CustomSidebarPro extends StatefulWidget {
  final Function(String ruta) onNavigate;
  final String currentRoute;

  const CustomSidebarPro({
    super.key,
    required this.onNavigate,
    required this.currentRoute,
  });

  @override
  State<CustomSidebarPro> createState() => _CustomSidebarProState();
}

class _CustomSidebarProState extends State<CustomSidebarPro> {
  final Map<String, bool> _expanded = {
    'admin': false,
    'agenda': false,
    'clientes': true,
    'corporativo': true,
    'profesionales': false,
    'recordatorios': false,
    'reportes': false,
    'servicios': false,
    'ventas': false,
  };

  Widget _buildGroup({
    required String keyId,
    required IconData icon,
    required String title,
    required List<Map<String, dynamic>> children,
  }) {
    final isExpanded = _expanded[keyId] ?? false;

    return ExpansionTile(
      initiallyExpanded: isExpanded,
      onExpansionChanged: (val) => setState(() => _expanded[keyId] = val),
      leading: Icon(icon, color: kBrandPurple),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      children: children.map((item) {
        final selected = widget.currentRoute == item['route'];

        return ListTile(
          leading: Icon(
            item['icon'],
            color: selected ? kBrandPurple : Colors.grey,
          ),
          title: Text(
            item['label'],
            style: TextStyle(
              color: selected ? kBrandPurple : Colors.black,
              fontWeight: selected ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          onTap: () {
            if (item['label'] == 'Nuevo profesional') {
              widget.onNavigate('/profesionales/nuevo');
            } else if (item['route'] != null) {
              widget.onNavigate(item['route']);
            }
          },
        );
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 260,
      color: kBackgroundColor,
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      child: ListView(
        children: [
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Text(
              'Fisio Spa KYM',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          _buildGroup(
            keyId: 'admin',
            icon: Icons.settings,
            title: 'Admin',
            children: [
              {
                'label': 'Usuarios',
                'icon': Icons.admin_panel_settings,
                'route': null
              },
              {'label': 'Permisos', 'icon': Icons.lock, 'route': null},
              {
                'label': 'Configuración',
                'icon': Icons.settings_applications,
                'route': '/admin'
              },
            ],
          ),
          _buildGroup(
            keyId: 'agenda',
            icon: Icons.calendar_today,
            title: 'Agenda',
            children: [
              {
                'label': 'Vista semanal',
                'icon': Icons.view_week,
                'route': '/agenda/semanal'
              },
              {
                'label': 'Vista diaria',
                'icon': Icons.view_day,
                'route': '/agenda/diaria'
              },
            ],
          ),
          _buildGroup(
            keyId: 'clientes',
            icon: Icons.people_alt,
            title: 'Clientes',
            children: [
              {
                'label': 'Todos los clientes',
                'icon': Icons.list,
                'route': '/clientes'
              },
              {
                'label': 'Nuevo cliente',
                'icon': Icons.person_add,
                'route': '/clientes/nuevo'
              },
            ],
          ),
          _buildGroup(
            keyId: 'corporativo',
            icon: Icons.business_center,
            title: 'Corporativo',
            children: [
              {
                'label': 'Empresas',
                'icon': Icons.apartment,
                'route': '/empresas'
              },
              {
                'label': 'Cuentas por cobrar',
                'icon': Icons.receipt_long,
                'route': '/facturacion'
              },
              {
                'label': 'Contratos',
                'icon': Icons.article,
                'route': '/contratos'
              },
              {
                'label': 'Micrositio demo',
                'icon': Icons.link,
                'route': '/micrositio/demo'
              },
              {
                'label': 'KYM Pulse',
                'icon': Icons.favorite,
                'route': '/kympulse'
              },
              {
                'label': 'Eventos',
                'icon': Icons.event_available,
                'route': '/eventos'
              },
            ],
          ),
          _buildGroup(
            keyId: 'profesionales',
            icon: Icons.badge,
            title: 'Profesionales',
            children: [
              {
                'label': 'Listado',
                'icon': Icons.people,
                'route': '/profesionales'
              },
              {
                'label': 'Nuevo profesional',
                'icon': Icons.person_add_alt,
                'route': '/profesionales/nuevo'
              },
            ],
          ),
          _buildGroup(
            keyId: 'recordatorios',
            icon: Icons.notifications_active,
            title: 'Recordatorios',
            children: [
              {
                'label': 'WhatsApp',
                'icon': Icons.message,
                'route': '/recordatorios'
              },
              {'label': 'Email', 'icon': Icons.email, 'route': null},
            ],
          ),
          _buildGroup(
            keyId: 'reportes',
            icon: Icons.bar_chart,
            title: 'Reportes',
            children: [
              {'label': 'PDFs', 'icon': Icons.picture_as_pdf, 'route': null},
              {'label': 'CSV', 'icon': Icons.table_chart, 'route': null},
            ],
          ),
          _buildGroup(
            keyId: 'servicios',
            icon: Icons.design_services,
            title: 'Servicios',
            children: [
              {
                'label': 'Todos los servicios',
                'icon': Icons.list_alt,
                'route': '/servicios'
              },
            ],
          ),
          _buildGroup(
            keyId: 'ventas',
            icon: Icons.attach_money,
            title: 'Ventas',
            children: [
              {
                'label': 'Ingresos',
                'icon': Icons.trending_up,
                'route': '/ventas'
              },
              {
                'label': 'Campañas',
                'icon': Icons.campaign,
                'route': '/campanas'
              },
              {
                'label': 'Cotizaciones',
                'icon': Icons.assignment,
                'route': '/cotizaciones'
              },
            ],
          ),
        ],
      ),
    );
  }
}
