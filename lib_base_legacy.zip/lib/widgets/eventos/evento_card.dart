import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/evento_model.dart';
import '../../theme/theme.dart';
import '../../utils/qr_pdf_utils.dart'; // ✅ PDF real
// Reemplaza import de qr_generator_button.dart si ya no se usa

class EventoCard extends StatelessWidget {
  final EventoModel evento;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  const EventoCard({
    super.key,
    required this.evento,
    this.onEdit,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 800),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: kBorderColor.withAlpha(76)),
            boxShadow: const [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 4,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// Título del evento y estado
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Flexible(
                      child: Text(
                        evento.nombre,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Chip(
                      label: Text(evento.estado),
                      backgroundColor: kBrandPurple.withAlpha(25),
                      labelStyle: const TextStyle(color: kBrandPurple),
                    ),
                  ],
                ),

                const SizedBox(height: 8),

                /// Empresa
                if (evento.empresa.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Row(
                      children: [
                        const Text('🏢', style: TextStyle(fontSize: 16)),
                        const SizedBox(width: 6),
                        Text(
                          evento.empresa,
                          style: const TextStyle(fontSize: 14),
                        ),
                      ],
                    ),
                  ),

                /// Ubicación
                if (evento.ubicacion.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Row(
                      children: [
                        const Text('📍', style: TextStyle(fontSize: 16)),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            evento.ubicacion,
                            style: const TextStyle(fontSize: 14),
                          ),
                        ),
                      ],
                    ),
                  ),

                /// Fecha
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      const Text('📅', style: TextStyle(fontSize: 16)),
                      const SizedBox(width: 6),
                      Text(
                        DateFormat('dd MMM yyyy, hh:mm a', 'es_MX')
                            .format(evento.fecha),
                        style: const TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                ),

                /// Servicios asignados con QR
                if (evento.serviciosAsignados.isNotEmpty)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: evento.serviciosAsignados.map((asignacion) {
                      final servicioNombre =
                          asignacion['servicioNombre'] ?? 'Servicio';
                      final profesionalNombre =
                          asignacion['profesionalNombre'] ?? 'Profesional';
                      final servicioId = asignacion['servicioId'] ?? '';
                      final profesionalId = asignacion['profesionalId'] ?? '';
                      final eventoId = evento.eventoId ?? '';

                      final qrUrl =
                          'https://fisiospakym.com/kym-pulse/?e=$eventoId&p=$profesionalId&s=$servicioId';

                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          children: [
                            const Icon(Icons.check_circle_outline, size: 16),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                '$servicioNombre con $profesionalNombre',
                                style: const TextStyle(fontSize: 14),
                              ),
                            ),
                            Tooltip(
                              message: 'Generar QR PDF',
                              child: IconButton(
                                icon: const Icon(Icons.qr_code),
                                onPressed: () async {
                                  await QRPdfGenerator.generarQRComoPDF(
                                    context: context,
                                    url: qrUrl,
                                    servicio: servicioNombre,
                                    profesional: profesionalNombre,
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ),

                /// Acciones
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    if (onEdit != null)
                      IconButton(
                        tooltip: 'Editar',
                        icon: const Icon(Icons.edit),
                        onPressed: onEdit,
                      ),
                    if (onDelete != null)
                      IconButton(
                        tooltip: 'Eliminar',
                        icon: const Icon(Icons.delete),
                        onPressed: onDelete,
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
