import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../models/evento_model.dart';
import '../../../models/servicio_realizado_model.dart';
import '../../../theme/theme.dart';
import '../../../utils/export_evento_excel.dart';
import '../../../utils/export_evento_pdf.dart';

class PulseCard extends StatefulWidget {
  final EventoModel evento;

  const PulseCard({super.key, required this.evento});

  @override
  State<PulseCard> createState() => _PulseCardState();
}

class _PulseCardState extends State<PulseCard> {
  Map<String, String> _servicios = {};
  Map<String, String> _profesionales = {};

  @override
  void initState() {
    super.initState();
    _cargarNombres();
  }

  Future<void> _cargarNombres() async {
    final serviciosIds = widget.evento.serviciosAsignados
        .map((e) => e['servicioId'] ?? '')
        .where((id) => id.isNotEmpty)
        .toSet()
        .toList();

    final profesionalesIds = widget.evento.serviciosAsignados
        .map((e) => e['profesionalId'] ?? '')
        .where((id) => id.isNotEmpty)
        .toSet()
        .toList();

    final snapServicios = await FirebaseFirestore.instance
        .collection('services')
        .where(FieldPath.documentId, whereIn: serviciosIds)
        .get();

    final snapProfesionales = await FirebaseFirestore.instance
        .collection('profesionales')
        .where(FieldPath.documentId, whereIn: profesionalesIds)
        .get();

    setState(() {
      _servicios = {
        for (var doc in snapServicios.docs)
          doc.id: doc.data()['name']?.toString() ?? doc.id
      };
      _profesionales = {
        for (var doc in snapProfesionales.docs)
          doc.id: doc.data()['nombre']?.toString() ?? doc.id
      };
    });
  }

  @override
  Widget build(BuildContext context) {
    final registrosRef = FirebaseFirestore.instance
        .collection('eventos')
        .doc(widget.evento.id)
        .collection('registros');

    return StreamBuilder<QuerySnapshot>(
      stream: registrosRef.snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const CircularProgressIndicator();

        final registros = snapshot.data!.docs
            .map((doc) => ServicioRealizadoModel.fromMap(
                doc.data() as Map<String, dynamic>, doc.id))
            .toList();

        final Map<String, int> serviciosCount = {};
        final List<String> comentariosPlanos = [];
        final Map<String, List<double>> preguntas = {
          'preg0': [],
          'preg1': [],
          'preg2': [],
          'preg3': [],
          'preg4': [],
        };

        for (var r in registros) {
          serviciosCount[r.servicioId] =
              (serviciosCount[r.servicioId] ?? 0) + 1;

          if (r.encuesta != null) {
            for (var key in preguntas.keys) {
              final valor = r.encuesta?[key];
              if (valor != null && valor is String) {
                preguntas[key]!.add(_parseEstrellas(valor));
              }
            }

            final comentario = r.encuesta?['comentario'];
            if (comentario != null && comentario.toString().trim().isNotEmpty) {
              comentariosPlanos.add(comentario.toString().trim());
            }
          }
        }

        final totalRegistros = registros.length;
        final totalEncuestas = preguntas['preg0']!.length;
        final promedioGlobal = preguntas.entries.fold<double>(
                0,
                (acum, entry) =>
                    acum +
                    (entry.value.isEmpty
                        ? 0
                        : entry.value.reduce((a, b) => a + b) /
                            entry.value.length)) /
            5;

        final mostrarComentarios = comentariosPlanos.take(5).toList();
        final restantes = comentariosPlanos.length - mostrarComentarios.length;

        final evento = widget.evento;

        return Card(
          margin: const EdgeInsets.only(bottom: 20),
          elevation: 3,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // IZQUIERDA — Profesionales y combinaciones
                Expanded(
                  flex: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(evento.nombre,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Row(children: [
                        const Icon(Icons.calendar_month_outlined, size: 16),
                        const SizedBox(width: 4),
                        Text(
                            '${evento.fecha.day.toString().padLeft(2, '0')}/${evento.fecha.month.toString().padLeft(2, '0')}/${evento.fecha.year}'),
                      ]),
                      const SizedBox(height: 4),
                      Row(children: [
                        const Icon(Icons.apartment_outlined, size: 16),
                        const SizedBox(width: 4),
                        Text(evento.empresa),
                      ]),
                      if (evento.ubicacion.isNotEmpty)
                        Row(children: [
                          const Icon(Icons.location_on_outlined, size: 16),
                          const SizedBox(width: 4),
                          Text(evento.ubicacion),
                        ]),
                      const SizedBox(height: 16),
                      const Text('👥 Profesionales y servicios realizados:',
                          style: TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 6),
                      ...evento.serviciosAsignados.map((e) {
                        final pid = e['profesionalId'] ?? '';
                        final sid = e['servicioId'] ?? '';
                        final nombreProf = _profesionales[pid] ?? pid;
                        final nombreServ = _servicios[sid] ?? sid;
                        final conteo = registros
                            .where((r) =>
                                r.profesionalId == pid && r.servicioId == sid)
                            .length;

                        return Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Row(
                            children: [
                              const Icon(Icons.person_outline,
                                  size: 16, color: kBrandPurple),
                              const SizedBox(width: 6),
                              Expanded(
                                  child: Text('$nombreProf – $nombreServ',
                                      style: const TextStyle(fontSize: 13))),
                              Chip(
                                label: Text('×$conteo'),
                                backgroundColor: Colors.grey.shade200,
                              )
                            ],
                          ),
                        );
                      }),
                    ],
                  ),
                ),
                // CENTRO – Totales de servicio + Encuestas (subidas)
                Expanded(
                  flex: 4,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Text('Totales por servicio:',
                          style: TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 6),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: serviciosCount.entries
                            .map((e) => Chip(
                                  avatar: const Icon(
                                      Icons.medical_services_outlined,
                                      size: 16),
                                  label: Text('×${e.value}'),
                                  backgroundColor: kAccentBlue
                                      .withAlpha((255 * 0.1).toInt()),
                                  labelStyle:
                                      const TextStyle(color: Colors.black87),
                                ))
                            .toList(),
                      ),
                      const SizedBox(height: 8),
                      if (comentariosPlanos.isNotEmpty)
                        Column(
                          children: [
                            const SizedBox(height: 8),
                            const Text('Encuestas:',
                                style: TextStyle(fontWeight: FontWeight.w600)),
                            const SizedBox(height: 6),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.star,
                                    color: Colors.amber, size: 18),
                                const SizedBox(width: 4),
                                Text(
                                  promedioGlobal.toStringAsFixed(1),
                                  style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                                const SizedBox(width: 6),
                                Text('($totalEncuestas)',
                                    style: const TextStyle(fontSize: 12)),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 8,
                              runSpacing: 6,
                              children: mostrarComentarios
                                  .map((coment) => Chip(
                                        avatar: const Icon(Icons.comment,
                                            size: 14, color: Colors.grey),
                                        label: Text(coment,
                                            style:
                                                const TextStyle(fontSize: 12)),
                                        backgroundColor: Colors.grey.shade100,
                                      ))
                                  .toList(),
                            ),
                            if (restantes > 0)
                              TextButton.icon(
                                onPressed: () {
                                  showDialog(
                                    context: context,
                                    builder: (_) => AlertDialog(
                                      title:
                                          const Text('Todos los comentarios'),
                                      content: SizedBox(
                                        width: 400,
                                        child: ListView(
                                          shrinkWrap: true,
                                          children: comentariosPlanos
                                              .map((e) => ListTile(
                                                    leading: const Icon(
                                                        Icons.comment),
                                                    title: Text(e),
                                                  ))
                                              .toList(),
                                        ),
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(context),
                                          child: const Text('Cerrar'),
                                        )
                                      ],
                                    ),
                                  );
                                },
                                icon: const Icon(Icons.more_horiz),
                                label: Text('Ver $restantes más'),
                              ),
                          ],
                        ),
                    ],
                  ),
                ),

                // DERECHA – Estado + Exportar
                Expanded(
                  flex: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.green.shade50,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Text(
                          'ACTIVO',
                          style: TextStyle(
                            color: Colors.green,
                            fontWeight: FontWeight.w600,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Icon(Icons.analytics,
                              size: 16, color: Colors.black54),
                          const SizedBox(width: 6),
                          Text('Total registros: $totalRegistros',
                              style:
                                  const TextStyle(fontWeight: FontWeight.w600)),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          TextButton.icon(
                            onPressed: () => exportarResumenEvento(evento),
                            icon: const Icon(Icons.table_chart),
                            label: const Text('Exportar Excel'),
                          ),
                          const SizedBox(width: 8),
                          TextButton.icon(
                            onPressed: () => exportarEventoComoPDF(evento),
                            icon: const Icon(Icons.picture_as_pdf),
                            label: const Text('PDF'),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  double _parseEstrellas(String estrella) {
    switch (estrella.trim()) {
      case '⭐':
        return 1.0;
      case '⭐⭐':
        return 2.0;
      case '⭐⭐⭐':
        return 3.0;
      case '⭐⭐⭐⭐':
        return 4.0;
      case '⭐⭐⭐⭐⭐':
        return 5.0;
      default:
        return 0.0;
    }
  }
}
