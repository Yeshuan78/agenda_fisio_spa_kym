// [util 1.1] constants.dart

import 'package:flutter/material.dart';

const Color kPrimaryColor = Color(0xFF9920A7);
const Color kSecondaryColor = Color(0xFFE1BEE7);
const Color kAccentColor = Color(0xFFF8BBD0);

const double kDefaultPadding = 16.0;
