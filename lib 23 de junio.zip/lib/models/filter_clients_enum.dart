// [Parte 1.1]: Enumeración de filtros para clients_screen y clients_sidebar

// 📂 Ubicación sugerida: lib/models/filter_clients_enum.dart

enum FiltroClientes {
  todos,
  nuevos,
  activos,
  inactivos,
}
