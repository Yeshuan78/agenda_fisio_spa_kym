// [client_form_model.dart] - MODELO ENTERPRISE PARA FORMULARIO DE CLIENTE
// 📁 Ubicación: /lib/models/clients/client_form_model.dart
// 🎯 OBJETIVO: Modelo robusto para el formulario con validaciones enterprise

import 'package:flutter/foundation.dart';
import 'package:agenda_fisio_spa_kym/models/clients/client_model.dart';

/// 📋 MODELO PRINCIPAL DEL FORMULARIO
class ClientFormModel {
  final PersonalFormInfo personalInfo;
  final AddressFormInfo addressInfo;
  final TagsFormInfo tagsInfo;
  final ClientFormValidation validation;
  final bool isEditing;
  final String? clientId;

  const ClientFormModel({
    required this.personalInfo,
    required this.addressInfo,
    required this.tagsInfo,
    required this.validation,
    this.isEditing = false,
    this.clientId,
  });

  /// 🏗️ FACTORY CONSTRUCTOR VACÍO
  factory ClientFormModel.empty() {
    return ClientFormModel(
      personalInfo: PersonalFormInfo.empty(),
      addressInfo: AddressFormInfo.empty(),
      tagsInfo: TagsFormInfo.empty(),
      validation: ClientFormValidation.empty(),
    );
  }

  /// 🏗️ FACTORY DESDE CLIENTE EXISTENTE
  factory ClientFormModel.fromClient(ClientModel client) {
    return ClientFormModel(
      personalInfo: PersonalFormInfo(
        nombre: client.personalInfo.nombre,
        apellidos: client.personalInfo.apellidos,
        email: client.contactInfo.email,
        telefono: client.contactInfo.telefono,
        empresa: client.personalInfo.empresa,
      ),
      addressInfo: AddressFormInfo(
        calle: client.addressInfo.calle,
        numeroExterior: client.addressInfo.numeroExterior,
        numeroInterior: client.addressInfo.numeroInterior,
        colonia: client.addressInfo.colonia,
        codigoPostal: client.addressInfo.codigoPostal,
        alcaldia: client.addressInfo.alcaldia,
      ),
      tagsInfo: TagsFormInfo.fromClientTags(client.tags),
      validation: ClientFormValidation.empty(),
      isEditing: true,
      clientId: client.clientId,
    );
  }

  /// 🔄 COPYWITH PARA IMMUTABILIDAD
  ClientFormModel copyWith({
    PersonalFormInfo? personalInfo,
    AddressFormInfo? addressInfo,
    TagsFormInfo? tagsInfo,
    ClientFormValidation? validation,
    bool? isEditing,
    String? clientId,
  }) {
    return ClientFormModel(
      personalInfo: personalInfo ?? this.personalInfo,
      addressInfo: addressInfo ?? this.addressInfo,
      tagsInfo: tagsInfo ?? this.tagsInfo,
      validation: validation ?? this.validation,
      isEditing: isEditing ?? this.isEditing,
      clientId: clientId ?? this.clientId,
    );
  }

  /// ✅ VALIDACIÓN COMPLETA DEL FORMULARIO
  bool get isValid {
    return validation.isValid &&
           personalInfo.isValid &&
           addressInfo.isValid;
  }

  /// 📊 CONVERSIÓN A CLIENT MODEL
  ClientModel toClientModel() {
    return ClientModel(
      clientId: clientId ?? '',
      personalInfo: PersonalInfo(
        nombre: personalInfo.nombre,
        apellidos: personalInfo.apellidos,
        empresa: personalInfo.empresa?.isNotEmpty == true ? personalInfo.empresa : null,
      ),
      contactInfo: ContactInfo(
        email: personalInfo.email,
        telefono: personalInfo.telefono,
      ),
      addressInfo: AddressInfo(
        calle: addressInfo.calle,
        numeroExterior: addressInfo.numeroExterior,
        numeroInterior: addressInfo.numeroInterior?.isNotEmpty == true ? addressInfo.numeroInterior : null,
        colonia: addressInfo.colonia,
        codigoPostal: addressInfo.codigoPostal,
        alcaldia: addressInfo.alcaldia,
      ),
      tags: tagsInfo.getAllTags(),
      metrics: ClientMetrics.fromMap({}),
      auditInfo: AuditInfo(createdBy: 'system'),
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  }

  /// 📋 DATOS PARA FIRESTORE
  Map<String, dynamic> toFirestoreMap() {
    final client = toClientModel();
    return client.toMap();
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ClientFormModel &&
          runtimeType == other.runtimeType &&
          personalInfo == other.personalInfo &&
          addressInfo == other.addressInfo &&
          tagsInfo == other.tagsInfo;

  @override
  int get hashCode =>
      personalInfo.hashCode ^
      addressInfo.hashCode ^
      tagsInfo.hashCode;

  @override
  String toString() {
    return 'ClientFormModel{nombre: ${personalInfo.nombre}, isValid: $isValid, isEditing: $isEditing}';
  }
}

/// 👤 INFORMACIÓN PERSONAL DEL FORMULARIO
class PersonalFormInfo {
  final String nombre;
  final String apellidos;
  final String email;
  final String telefono;
  final String? empresa;

  const PersonalFormInfo({
    required this.nombre,
    required this.apellidos,
    required this.email,
    required this.telefono,
    this.empresa,
  });

  factory PersonalFormInfo.empty() {
    return const PersonalFormInfo(
      nombre: '',
      apellidos: '',
      email: '',
      telefono: '',
      empresa: '',
    );
  }

  PersonalFormInfo copyWith({
    String? nombre,
    String? apellidos,
    String? email,
    String? telefono,
    String? empresa,
  }) {
    return PersonalFormInfo(
      nombre: nombre ?? this.nombre,
      apellidos: apellidos ?? this.apellidos,
      email: email ?? this.email,
      telefono: telefono ?? this.telefono,
      empresa: empresa ?? this.empresa,
    );
  }

  bool get isValid {
    return nombre.trim().isNotEmpty &&
           apellidos.trim().isNotEmpty &&
           email.trim().isNotEmpty &&
           telefono.trim().isNotEmpty &&
           _isValidEmail(email) &&
           _isValidPhoneMX(telefono);
  }

  String get fullName => '$nombre $apellidos'.trim();

  bool _isValidEmail(String email) {
    return RegExp(r'^[^@]+@[^@]+\.[^@]+$').hasMatch(email.trim());
  }

  bool _isValidPhoneMX(String phone) {
    final cleaned = phone.replaceAll(RegExp(r'[^\d]'), '');
    return cleaned.length == 10;
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PersonalFormInfo &&
          runtimeType == other.runtimeType &&
          nombre == other.nombre &&
          apellidos == other.apellidos &&
          email == other.email &&
          telefono == other.telefono &&
          empresa == other.empresa;

  @override
  int get hashCode =>
      nombre.hashCode ^
      apellidos.hashCode ^
      email.hashCode ^
      telefono.hashCode ^
      empresa.hashCode;
}

/// 🏠 INFORMACIÓN DE DIRECCIÓN DEL FORMULARIO
class AddressFormInfo {
  final String calle;
  final String numeroExterior;
  final String? numeroInterior;
  final String colonia;
  final String codigoPostal;
  final String alcaldia;

  const AddressFormInfo({
    required this.calle,
    required this.numeroExterior,
    this.numeroInterior,
    required this.colonia,
    required this.codigoPostal,
    required this.alcaldia,
  });

  factory AddressFormInfo.empty() {
    return const AddressFormInfo(
      calle: '',
      numeroExterior: '',
      numeroInterior: '',
      colonia: '',
      codigoPostal: '',
      alcaldia: '',
    );
  }

  AddressFormInfo copyWith({
    String? calle,
    String? numeroExterior,
    String? numeroInterior,
    String? colonia,
    String? codigoPostal,
    String? alcaldia,
  }) {
    return AddressFormInfo(
      calle: calle ?? this.calle,
      numeroExterior: numeroExterior ?? this.numeroExterior,
      numeroInterior: numeroInterior ?? this.numeroInterior,
      colonia: colonia ?? this.colonia,
      codigoPostal: codigoPostal ?? this.codigoPostal,
      alcaldia: alcaldia ?? this.alcaldia,
    );
  }

  bool get isValid {
    return calle.trim().isNotEmpty &&
           numeroExterior.trim().isNotEmpty &&
           colonia.trim().isNotEmpty &&
           codigoPostal.trim().isNotEmpty &&
           alcaldia.trim().isNotEmpty &&
           _isValidCP(codigoPostal);
  }

  String get fullAddress {
    final parts = <String>[];
    if (calle.isNotEmpty) parts.add(calle);
    if (numeroExterior.isNotEmpty) parts.add('No. $numeroExterior');
    if (numeroInterior != null && numeroInterior!.isNotEmpty) {
      parts.add('Int. $numeroInterior');
    }
    if (colonia.isNotEmpty) parts.add(colonia);
    if (alcaldia.isNotEmpty) parts.add(alcaldia);
    if (codigoPostal.isNotEmpty) parts.add('CP $codigoPostal');
    return parts.join(', ');
  }

  bool _isValidCP(String cp) {
    final cleaned = cp.replaceAll(RegExp(r'[^\d]'), '');
    return cleaned.length == 5;
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AddressFormInfo &&
          runtimeType == other.runtimeType &&
          calle == other.calle &&
          numeroExterior == other.numeroExterior &&
          numeroInterior == other.numeroInterior &&
          colonia == other.colonia &&
          codigoPostal == other.codigoPostal &&
          alcaldia == other.alcaldia;

  @override
  int get hashCode =>
      calle.hashCode ^
      numeroExterior.hashCode ^
      numeroInterior.hashCode ^
      colonia.hashCode ^
      codigoPostal.hashCode ^
      alcaldia.hashCode;
}

/// 🏷️ INFORMACIÓN DE ETIQUETAS DEL FORMULARIO
class TagsFormInfo {
  final Set<String> baseTags;
  final List<String> customTags;

  const TagsFormInfo({
    required this.baseTags,
    required this.customTags,
  });

  factory TagsFormInfo.empty() {
    return const TagsFormInfo(
      baseTags: <String>{},
      customTags: <String>[],
    );
  }

  factory TagsFormInfo.fromClientTags(List<ClientTag> clientTags) {
    final Set<String> baseTags = {};
    final List<String> customTags = [];

    const baseTagLabels = ['VIP', 'Corporativo', 'Nuevo', 'Recurrente', 'Promoción', 'Consentido', 'Especial'];

    for (final tag in clientTags) {
      if (baseTagLabels.contains(tag.label)) {
        baseTags.add(tag.label);
      } else {
        customTags.add(tag.label);
      }
    }

    return TagsFormInfo(
      baseTags: baseTags,
      customTags: customTags,
    );
  }

  TagsFormInfo copyWith({
    Set<String>? baseTags,
    List<String>? customTags,
  }) {
    return TagsFormInfo(
      baseTags: baseTags ?? this.baseTags,
      customTags: customTags ?? this.customTags,
    );
  }

  TagsFormInfo addBaseTag(String tag) {
    final newBaseTags = Set<String>.from(baseTags)..add(tag);
    return copyWith(baseTags: newBaseTags);
  }

  TagsFormInfo removeBaseTag(String tag) {
    final newBaseTags = Set<String>.from(baseTags)..remove(tag);
    return copyWith(baseTags: newBaseTags);
  }

  TagsFormInfo addCustomTag(String tag) {
    if (tag.trim().isEmpty || customTags.contains(tag) || baseTags.contains(tag)) {
      return this;
    }
    final newCustomTags = List<String>.from(customTags)..add(tag.trim());
    return copyWith(customTags: newCustomTags);
  }

  TagsFormInfo removeCustomTag(String tag) {
    final newCustomTags = List<String>.from(customTags)..remove(tag);
    return copyWith(customTags: newCustomTags);
  }

  List<ClientTag> getAllTags() {
    final List<ClientTag> allTags = [];
    final now = DateTime.now();

    // Etiquetas base
    for (final tag in baseTags) {
      allTags.add(ClientTag(
        label: tag,
        type: TagType.base,
        createdAt: now,
      ));
    }

    // Etiquetas personalizadas
    for (int i = 0; i < customTags.length; i++) {
      final tag = customTags[i];
      final colors = ['#7c4dff', '#009688', '#795548', '#3f51b5', '#00bcd4', '#ff5722', '#cddc39', '#607d8b', '#e91e63', '#ffc107'];
      final color = colors[i % colors.length];

      allTags.add(ClientTag(
        label: tag,
        color: color,
        type: TagType.custom,
        createdAt: now,
      ));
    }

    return allTags;
  }

  int get totalTags => baseTags.length + customTags.length;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is TagsFormInfo &&
          runtimeType == other.runtimeType &&
          setEquals(baseTags, other.baseTags) &&
          listEquals(customTags, other.customTags);

  @override
  int get hashCode => baseTags.hashCode ^ customTags.hashCode;
}

/// ✅ VALIDACIÓN DEL FORMULARIO
class ClientFormValidation {
  final Map<String, String?> fieldErrors;
  final List<String> globalErrors;
  final bool isValidating;

  const ClientFormValidation({
    required this.fieldErrors,
    required this.globalErrors,
    this.isValidating = false,
  });

  factory ClientFormValidation.empty() {
    return const ClientFormValidation(
      fieldErrors: {},
      globalErrors: [],
    );
  }

  ClientFormValidation copyWith({
    Map<String, String?>? fieldErrors,
    List<String>? globalErrors,
    bool? isValidating,
  }) {
    return ClientFormValidation(
      fieldErrors: fieldErrors ?? this.fieldErrors,
      globalErrors: globalErrors ?? this.globalErrors,
      isValidating: isValidating ?? this.isValidating,
    );
  }

  ClientFormValidation setFieldError(String field, String? error) {
    final newErrors = Map<String, String?>.from(fieldErrors);
    if (error == null) {
      newErrors.remove(field);
    } else {
      newErrors[field] = error;
    }
    return copyWith(fieldErrors: newErrors);
  }

  ClientFormValidation addGlobalError(String error) {
    final newGlobalErrors = List<String>.from(globalErrors)..add(error);
    return copyWith(globalErrors: newGlobalErrors);
  }

  ClientFormValidation clearErrors() {
    return ClientFormValidation.empty();
  }

  bool get isValid => fieldErrors.isEmpty && globalErrors.isEmpty;
  bool get hasErrors => fieldErrors.isNotEmpty || globalErrors.isNotEmpty;

  String? getFieldError(String field) => fieldErrors[field];
  bool hasFieldError(String field) => fieldErrors.containsKey(field);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ClientFormValidation &&
          runtimeType == other.runtimeType &&
          mapEquals(fieldErrors, other.fieldErrors) &&
          listEquals(globalErrors, other.globalErrors) &&
          isValidating == other.isValidating;

  @override
  int get hashCode =>
      fieldErrors.hashCode ^
      globalErrors.hashCode ^
      isValidating.hashCode;
}