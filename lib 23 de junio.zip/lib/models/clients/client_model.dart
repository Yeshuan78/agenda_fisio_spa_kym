// [client_model.dart] - MODELO ENTERPRISE PRINCIPAL
// 📁 Ubicación: /lib/models/clients/client_model.dart
// 🎯 OBJETIVO: Modelo robusto compatible con estructura existente + funcionalidades enterprise

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

/// 👥 MODELO PRINCIPAL DE CLIENTE ENTERPRISE
/// Compatible con estructura Firestore existente + funcionalidades premium
class ClientModel {
  // ✅ IDENTIFICADORES PRINCIPALES
  final String clientId;
  final PersonalInfo personalInfo;
  final ContactInfo contactInfo;
  final AddressInfo addressInfo;
  final List<ClientTag> tags;
  final ClientMetrics metrics;
  final AuditInfo auditInfo;

  // ✅ TIMESTAMPS PARA AUDITORÍA
  final DateTime createdAt;
  final DateTime updatedAt;

  // ✅ CAMPOS CALCULADOS (NO PERSISTIDOS)
  final ClientStatus status;
  final int appointmentsCount;
  final double totalRevenue;
  final DateTime? lastAppointment;

  const ClientModel({
    required this.clientId,
    required this.personalInfo,
    required this.contactInfo,
    required this.addressInfo,
    required this.tags,
    required this.metrics,
    required this.auditInfo,
    required this.createdAt,
    required this.updatedAt,
    this.status = ClientStatus.active,
    this.appointmentsCount = 0,
    this.totalRevenue = 0.0,
    this.lastAppointment,
  });

  /// 🏗️ FACTORY CONSTRUCTOR DESDE FIRESTORE
  factory ClientModel.fromDoc(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ClientModel.fromMap(data, doc.id);
  }

  /// 🏗️ FACTORY CONSTRUCTOR DESDE MAP (COMPATIBILIDAD TOTAL)
  factory ClientModel.fromMap(Map<String, dynamic> data, String id) {
    return ClientModel(
      clientId: id,
      personalInfo: PersonalInfo.fromMap(data),
      contactInfo: ContactInfo.fromMap(data),
      addressInfo: AddressInfo.fromMap(data),
      tags: _parseClientTags(data['tiposCliente']),
      metrics: ClientMetrics.fromMap(data),
      auditInfo: AuditInfo.fromMap(data),
      createdAt: _parseDateTime(data['createdAt']) ?? DateTime.now(),
      updatedAt: _parseDateTime(data['updatedAt']) ?? DateTime.now(),
      status: _parseClientStatus(data['status']),
    );
  }

  /// 💾 CONVERSIÓN A MAP PARA FIRESTORE (MANTIENE COMPATIBILIDAD)
  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{
      // ✅ CAMPOS COMPATIBLES CON ESTRUCTURA EXISTENTE
      'nombre': personalInfo.nombre,
      'apellidos': personalInfo.apellidos,
      'correo': contactInfo.email,
      'telefono': contactInfo.telefono,
      'empresa': personalInfo.empresa,
      'calle': addressInfo.calle,
      'numeroExterior': addressInfo.numeroExterior,
      'numeroInterior': addressInfo.numeroInterior,
      'colonia': addressInfo.colonia,
      'codigoPostal': addressInfo.codigoPostal,
      'alcaldia': addressInfo.alcaldia,
      
      // ✅ TAGS EN FORMATO COMPATIBLE
      'tiposCliente': tags.map((tag) => tag.toMap()).toList(),
      
      // ✅ NUEVOS CAMPOS ENTERPRISE
      'metrics': metrics.toMap(),
      'auditInfo': auditInfo.toMap(),
      'status': status.name,
      
      // ✅ TIMESTAMPS
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': FieldValue.serverTimestamp(),
    };

    // Agregar campos específicos de PersonalInfo
    map.addAll(personalInfo.toMap());
    map.addAll(contactInfo.toMap());
    map.addAll(addressInfo.toMap());

    // Remover campos null
    map.removeWhere((key, value) => value == null);
    return map;
  }

  /// 📋 GETTERS DE COMPATIBILIDAD (Para widgets existentes)
  String get fullName => '${personalInfo.nombre} ${personalInfo.apellidos}'.trim();
  String get displayName => fullName;
  String get email => contactInfo.email;
  String get phone => contactInfo.telefono;
  String get empresa => personalInfo.empresa ?? '';
  String get direccionCompleta => addressInfo.fullAddress;

  /// 🎯 GETTERS ENTERPRISE
  bool get isVIP => hasTag('VIP');
  bool get isCorporate => hasTag('Corporativo');
  bool get isNew => hasTag('Nuevo');
  bool get isActive => status == ClientStatus.active;
  bool get hasAppointments => appointmentsCount > 0;
  
  double get avgSatisfaction => metrics.satisfactionScore;
  String get statusDisplayName => status.displayName;
  Color get statusColor => status.color;

  /// 🏷️ MÉTODOS DE TAGS
  bool hasTag(String tagLabel) {
    return tags.any((tag) => tag.label.toLowerCase() == tagLabel.toLowerCase());
  }

  List<ClientTag> get baseTags => tags.where((tag) => tag.type == TagType.base).toList();
  List<ClientTag> get customTags => tags.where((tag) => tag.type == TagType.custom).toList();
  List<ClientTag> get systemTags => tags.where((tag) => tag.type == TagType.system).toList();

  /// 🔍 MÉTODOS DE BÚSQUEDA Y FILTROS
  bool matchesSearchQuery(String query) {
    if (query.isEmpty) return true;

    final searchTerms = query.toLowerCase().split(' ');
    final searchableText = '''
      ${personalInfo.nombre} 
      ${personalInfo.apellidos} 
      ${contactInfo.email} 
      ${contactInfo.telefono} 
      ${personalInfo.empresa ?? ''} 
      ${addressInfo.fullAddress}
      ${tags.map((t) => t.label).join(' ')}
    '''.toLowerCase();

    return searchTerms.every((term) => searchableText.contains(term));
  }

  bool matchesFilter(ClientFilterCriteria criteria) {
    // Status filter
    if (criteria.statuses.isNotEmpty && !criteria.statuses.contains(status)) {
      return false;
    }

    // Tag filter
    if (criteria.tags.isNotEmpty) {
      final hasRequiredTag = criteria.tags.any((tag) => hasTag(tag));
      if (!hasRequiredTag) return false;
    }

    // Date range filter
    if (criteria.dateRange != null) {
      if (createdAt.isBefore(criteria.dateRange!.start) || 
          createdAt.isAfter(criteria.dateRange!.end)) {
        return false;
      }
    }

    // Location filter
    if (criteria.alcaldias.isNotEmpty && 
        !criteria.alcaldias.contains(addressInfo.alcaldia)) {
      return false;
    }

    // Metrics filter
    if (criteria.minAppointments != null && 
        appointmentsCount < criteria.minAppointments!) {
      return false;
    }

    return true;
  }

  /// 📊 MÉTODOS DE ANALYTICS
  Map<String, dynamic> getAnalyticsSummary() {
    return {
      'clientId': clientId,
      'fullName': fullName,
      'email': email,
      'phone': phone,
      'status': status.name,
      'appointmentsCount': appointmentsCount,
      'totalRevenue': totalRevenue,
      'avgSatisfaction': avgSatisfaction,
      'tags': tags.map((t) => t.label).toList(),
      'lastAppointment': lastAppointment?.toIso8601String(),
      'memberSince': createdAt.toIso8601String(),
      'lastUpdated': updatedAt.toIso8601String(),
    };
  }

  /// 🔄 COPYWITH PARA IMMUTABILIDAD
  ClientModel copyWith({
    String? clientId,
    PersonalInfo? personalInfo,
    ContactInfo? contactInfo,
    AddressInfo? addressInfo,
    List<ClientTag>? tags,
    ClientMetrics? metrics,
    AuditInfo? auditInfo,
    DateTime? createdAt,
    DateTime? updatedAt,
    ClientStatus? status,
    int? appointmentsCount,
    double? totalRevenue,
    DateTime? lastAppointment,
  }) {
    return ClientModel(
      clientId: clientId ?? this.clientId,
      personalInfo: personalInfo ?? this.personalInfo,
      contactInfo: contactInfo ?? this.contactInfo,
      addressInfo: addressInfo ?? this.addressInfo,
      tags: tags ?? this.tags,
      metrics: metrics ?? this.metrics,
      auditInfo: auditInfo ?? this.auditInfo,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      status: status ?? this.status,
      appointmentsCount: appointmentsCount ?? this.appointmentsCount,
      totalRevenue: totalRevenue ?? this.totalRevenue,
      lastAppointment: lastAppointment ?? this.lastAppointment,
    );
  }

  /// 🔄 MÉTODOS DE MODIFICACIÓN
  ClientModel addTag(ClientTag tag) {
    if (hasTag(tag.label)) return this;
    final newTags = List<ClientTag>.from(tags)..add(tag);
    return copyWith(tags: newTags);
  }

  ClientModel removeTag(String tagLabel) {
    final newTags = tags.where((tag) => tag.label != tagLabel).toList();
    return copyWith(tags: newTags);
  }

  ClientModel updateStatus(ClientStatus newStatus) {
    return copyWith(status: newStatus);
  }

  ClientModel updateMetrics({
    int? appointmentsCount,
    double? totalRevenue,
    double? satisfactionScore,
    DateTime? lastAppointment,
  }) {
    final newMetrics = metrics.copyWith(
      appointmentsCount: appointmentsCount,
      totalRevenue: totalRevenue,
      satisfactionScore: satisfactionScore,
      lastAppointment: lastAppointment,
    );
    return copyWith(
      metrics: newMetrics,
      appointmentsCount: appointmentsCount ?? this.appointmentsCount,
      totalRevenue: totalRevenue ?? this.totalRevenue,
      lastAppointment: lastAppointment ?? this.lastAppointment,
    );
  }

  /// 🔧 MÉTODOS HELPER ESTÁTICOS
  static List<ClientTag> _parseClientTags(dynamic tagsData) {
    if (tagsData is! List) return [];
    
    return tagsData.map((tagData) {
      if (tagData is String) {
        return ClientTag(
          label: tagData,
          type: _isBaseTag(tagData) ? TagType.base : TagType.custom,
          createdAt: DateTime.now(),
        );
      } else if (tagData is Map<String, dynamic>) {
        return ClientTag.fromMap(tagData);
      }
      return null;
    }).where((tag) => tag != null).cast<ClientTag>().toList();
  }

  static bool _isBaseTag(String label) {
    const baseTags = ['VIP', 'Corporativo', 'Nuevo', 'Recurrente', 'Promoción', 'Consentido', 'Especial'];
    return baseTags.any((base) => base.toLowerCase() == label.toLowerCase());
  }

  static ClientStatus _parseClientStatus(dynamic status) {
    if (status == null) return ClientStatus.active;
    return ClientStatus.values.firstWhere(
      (s) => s.name == status.toString(),
      orElse: () => ClientStatus.active,
    );
  }

  static DateTime? _parseDateTime(dynamic value) {
    if (value == null) return null;
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) return DateTime.tryParse(value);
    return null;
  }

  /// ⚖️ COMPARACIÓN PARA ORDENAMIENTO
  int compareTo(ClientModel other) {
    return fullName.toLowerCase().compareTo(other.fullName.toLowerCase());
  }

  /// 🎯 EQUALITY Y HASHCODE
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ClientModel &&
          runtimeType == other.runtimeType &&
          clientId == other.clientId;

  @override
  int get hashCode => clientId.hashCode;

  /// 🖨️ TO STRING PARA DEBUG
  @override
  String toString() {
    return 'ClientModel{id: $clientId, name: $fullName, status: ${status.name}, tags: ${tags.length}}';
  }
}

/// 👤 INFORMACIÓN PERSONAL
class PersonalInfo {
  final String nombre;
  final String apellidos;
  final String? empresa;
  final DateTime? fechaNacimiento;
  final String? genero;
  final String? notas;

  const PersonalInfo({
    required this.nombre,
    required this.apellidos,
    this.empresa,
    this.fechaNacimiento,
    this.genero,
    this.notas,
  });

  factory PersonalInfo.fromMap(Map<String, dynamic> data) {
    return PersonalInfo(
      nombre: data['nombre'] ?? '',
      apellidos: data['apellidos'] ?? '',
      empresa: data['empresa'],
      fechaNacimiento: _parseDateTime(data['fechaNacimiento']),
      genero: data['genero'],
      notas: data['notas'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'nombre': nombre,
      'apellidos': apellidos,
      'empresa': empresa,
      'fechaNacimiento': fechaNacimiento != null ? Timestamp.fromDate(fechaNacimiento!) : null,
      'genero': genero,
      'notas': notas,
    };
  }

  String get fullName => '$nombre $apellidos'.trim();
  
  int? get age {
    if (fechaNacimiento == null) return null;
    final now = DateTime.now();
    int age = now.year - fechaNacimiento!.year;
    if (now.month < fechaNacimiento!.month || 
        (now.month == fechaNacimiento!.month && now.day < fechaNacimiento!.day)) {
      age--;
    }
    return age;
  }

  PersonalInfo copyWith({
    String? nombre,
    String? apellidos,
    String? empresa,
    DateTime? fechaNacimiento,
    String? genero,
    String? notas,
  }) {
    return PersonalInfo(
      nombre: nombre ?? this.nombre,
      apellidos: apellidos ?? this.apellidos,
      empresa: empresa ?? this.empresa,
      fechaNacimiento: fechaNacimiento ?? this.fechaNacimiento,
      genero: genero ?? this.genero,
      notas: notas ?? this.notas,
    );
  }

  static DateTime? _parseDateTime(dynamic value) {
    if (value == null) return null;
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) return DateTime.tryParse(value);
    return null;
  }
}

/// 📞 INFORMACIÓN DE CONTACTO
class ContactInfo {
  final String email;
  final String telefono;
  final String? telefonoSecundario;
  final List<SocialMedia> redesSociales;
  final String? sitioWeb;
  final ContactPreferences preferences;

  const ContactInfo({
    required this.email,
    required this.telefono,
    this.telefonoSecundario,
    this.redesSociales = const [],
    this.sitioWeb,
    this.preferences = const ContactPreferences(),
  });

  factory ContactInfo.fromMap(Map<String, dynamic> data) {
    return ContactInfo(
      email: data['correo'] ?? '',
      telefono: data['telefono'] ?? '',
      telefonoSecundario: data['telefonoSecundario'],
      redesSociales: _parseSocialMedia(data['redesSociales']),
      sitioWeb: data['sitioWeb'],
      preferences: ContactPreferences.fromMap(data['preferences'] ?? {}),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'correo': email,
      'telefono': telefono,
      'telefonoSecundario': telefonoSecundario,
      'redesSociales': redesSociales.map((sm) => sm.toMap()).toList(),
      'sitioWeb': sitioWeb,
      'preferences': preferences.toMap(),
    };
  }

  bool get hasValidEmail => email.contains('@') && email.contains('.');
  bool get hasValidPhone => telefono.length >= 8;
  
  ContactInfo copyWith({
    String? email,
    String? telefono,
    String? telefonoSecundario,
    List<SocialMedia>? redesSociales,
    String? sitioWeb,
    ContactPreferences? preferences,
  }) {
    return ContactInfo(
      email: email ?? this.email,
      telefono: telefono ?? this.telefono,
      telefonoSecundario: telefonoSecundario ?? this.telefonoSecundario,
      redesSociales: redesSociales ?? this.redesSociales,
      sitioWeb: sitioWeb ?? this.sitioWeb,
      preferences: preferences ?? this.preferences,
    );
  }

  static List<SocialMedia> _parseSocialMedia(dynamic data) {
    if (data is! List) return [];
    return data.map((item) => SocialMedia.fromMap(item)).toList();
  }
}

/// 🏠 INFORMACIÓN DE DIRECCIÓN
class AddressInfo {
  final String calle;
  final String numeroExterior;
  final String? numeroInterior;
  final String colonia;
  final String codigoPostal;
  final String alcaldia;
  final String? referencias;

  const AddressInfo({
    required this.calle,
    required this.numeroExterior,
    this.numeroInterior,
    required this.colonia,
    required this.codigoPostal,
    required this.alcaldia,
    this.referencias,
  });

  factory AddressInfo.fromMap(Map<String, dynamic> data) {
    return AddressInfo(
      calle: data['calle'] ?? '',
      numeroExterior: data['numeroExterior'] ?? '',
      numeroInterior: data['numeroInterior'],
      colonia: data['colonia'] ?? '',
      codigoPostal: data['codigoPostal'] ?? '',
      alcaldia: data['alcaldia'] ?? '',
      referencias: data['referencias'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'calle': calle,
      'numeroExterior': numeroExterior,
      'numeroInterior': numeroInterior,
      'colonia': colonia,
      'codigoPostal': codigoPostal,
      'alcaldia': alcaldia,
      'referencias': referencias,
    };
  }

  String get fullAddress {
    final parts = <String>[];
    if (calle.isNotEmpty) parts.add(calle);
    if (numeroExterior.isNotEmpty) parts.add('No. $numeroExterior');
    if (numeroInterior != null && numeroInterior!.isNotEmpty) parts.add('Int. $numeroInterior');
    if (colonia.isNotEmpty) parts.add(colonia);
    if (alcaldia.isNotEmpty) parts.add(alcaldia);
    if (codigoPostal.isNotEmpty) parts.add('CP $codigoPostal');
    return parts.join(', ');
  }

  bool get isComplete {
    return calle.isNotEmpty && 
           numeroExterior.isNotEmpty && 
           colonia.isNotEmpty && 
           codigoPostal.isNotEmpty && 
           alcaldia.isNotEmpty;
  }

  AddressInfo copyWith({
    String? calle,
    String? numeroExterior,
    String? numeroInterior,
    String? colonia,
    String? codigoPostal,
    String? alcaldia,
    String? referencias,
  }) {
    return AddressInfo(
      calle: calle ?? this.calle,
      numeroExterior: numeroExterior ?? this.numeroExterior,
      numeroInterior: numeroInterior ?? this.numeroInterior,
      colonia: colonia ?? this.colonia,
      codigoPostal: codigoPostal ?? this.codigoPostal,
      alcaldia: alcaldia ?? this.alcaldia,
      referencias: referencias ?? this.referencias,
    );
  }
}

/// 🏷️ ETIQUETA DE CLIENTE
class ClientTag {
  final String label;
  final String? color;
  final TagType type;
  final DateTime createdAt;
  final String? createdBy;

  const ClientTag({
    required this.label,
    this.color,
    required this.type,
    required this.createdAt,
    this.createdBy,
  });

  factory ClientTag.fromMap(Map<String, dynamic> data) {
    return ClientTag(
      label: data['label'] ?? '',
      color: data['color'],
      type: TagType.values.firstWhere(
        (t) => t.name == data['type'],
        orElse: () => TagType.custom,
      ),
      createdAt: _parseDateTime(data['createdAt']) ?? DateTime.now(),
      createdBy: data['createdBy'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'label': label,
      'color': color,
      'type': type.name,
      'createdAt': Timestamp.fromDate(createdAt),
      'createdBy': createdBy,
    };
  }

  Color get displayColor {
    if (color != null) {
      return Color(int.parse(color!.replaceFirst('#', '0xFF')));
    }
    return _getDefaultColorForType();
  }

  Color _getDefaultColorForType() {
    switch (type) {
      case TagType.base:
        return _getBaseTagColor(label);
      case TagType.custom:
        return Colors.purple.shade300;
      case TagType.system:
        return Colors.blue.shade300;
    }
  }

  Color _getBaseTagColor(String label) {
    switch (label.toLowerCase()) {
      case 'vip': return Colors.purple.shade600;
      case 'corporativo': return Colors.blue.shade600;
      case 'nuevo': return Colors.green.shade600;
      case 'recurrente': return Colors.amber.shade600;
      case 'promoción': return Colors.orange.shade600;
      case 'consentido': return Colors.pink.shade600;
      case 'especial': return Colors.red.shade600;
      default: return Colors.grey.shade600;
    }
  }

  ClientTag copyWith({
    String? label,
    String? color,
    TagType? type,
    DateTime? createdAt,
    String? createdBy,
  }) {
    return ClientTag(
      label: label ?? this.label,
      color: color ?? this.color,
      type: type ?? this.type,
      createdAt: createdAt ?? this.createdAt,
      createdBy: createdBy ?? this.createdBy,
    );
  }

  static DateTime? _parseDateTime(dynamic value) {
    if (value == null) return null;
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) return DateTime.tryParse(value);
    return null;
  }
}

/// 📊 MÉTRICAS DEL CLIENTE
class ClientMetrics {
  final int appointmentsCount;
  final int attendedAppointments;
  final int cancelledAppointments;
  final int noShowAppointments;
  final double totalRevenue;
  final double averageTicket;
  final double satisfactionScore;
  final DateTime? lastAppointment;
  final DateTime? nextAppointment;
  final int loyaltyPoints;

  const ClientMetrics({
    this.appointmentsCount = 0,
    this.attendedAppointments = 0,
    this.cancelledAppointments = 0,
    this.noShowAppointments = 0,
    this.totalRevenue = 0.0,
    this.averageTicket = 0.0,
    this.satisfactionScore = 0.0,
    this.lastAppointment,
    this.nextAppointment,
    this.loyaltyPoints = 0,
  });

  factory ClientMetrics.fromMap(Map<String, dynamic> data) {
    return ClientMetrics(
      appointmentsCount: data['appointmentsCount'] ?? 0,
      attendedAppointments: data['attendedAppointments'] ?? 0,
      cancelledAppointments: data['cancelledAppointments'] ?? 0,
      noShowAppointments: data['noShowAppointments'] ?? 0,
      totalRevenue: (data['totalRevenue'] ?? 0.0).toDouble(),
      averageTicket: (data['averageTicket'] ?? 0.0).toDouble(),
      satisfactionScore: (data['satisfactionScore'] ?? 0.0).toDouble(),
      lastAppointment: _parseDateTime(data['lastAppointment']),
      nextAppointment: _parseDateTime(data['nextAppointment']),
      loyaltyPoints: data['loyaltyPoints'] ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'appointmentsCount': appointmentsCount,
      'attendedAppointments': attendedAppointments,
      'cancelledAppointments': cancelledAppointments,
      'noShowAppointments': noShowAppointments,
      'totalRevenue': totalRevenue,
      'averageTicket': averageTicket,
      'satisfactionScore': satisfactionScore,
      'lastAppointment': lastAppointment != null ? Timestamp.fromDate(lastAppointment!) : null,
      'nextAppointment': nextAppointment != null ? Timestamp.fromDate(nextAppointment!) : null,
      'loyaltyPoints': loyaltyPoints,
    };
  }

  double get attendanceRate {
    if (appointmentsCount == 0) return 0.0;
    return (attendedAppointments / appointmentsCount) * 100;
  }

  double get cancellationRate {
    if (appointmentsCount == 0) return 0.0;
    return (cancelledAppointments / appointmentsCount) * 100;
  }

  double get noShowRate {
    if (appointmentsCount == 0) return 0.0;
    return (noShowAppointments / appointmentsCount) * 100;
  }

  ClientMetrics copyWith({
    int? appointmentsCount,
    int? attendedAppointments,
    int? cancelledAppointments,
    int? noShowAppointments,
    double? totalRevenue,
    double? averageTicket,
    double? satisfactionScore,
    DateTime? lastAppointment,
    DateTime? nextAppointment,
    int? loyaltyPoints,
  }) {
    return ClientMetrics(
      appointmentsCount: appointmentsCount ?? this.appointmentsCount,
      attendedAppointments: attendedAppointments ?? this.attendedAppointments,
      cancelledAppointments: cancelledAppointments ?? this.cancelledAppointments,
      noShowAppointments: noShowAppointments ?? this.noShowAppointments,
      totalRevenue: totalRevenue ?? this.totalRevenue,
      averageTicket: averageTicket ?? this.averageTicket,
      satisfactionScore: satisfactionScore ?? this.satisfactionScore,
      lastAppointment: lastAppointment ?? this.lastAppointment,
      nextAppointment: nextAppointment ?? this.nextAppointment,
      loyaltyPoints: loyaltyPoints ?? this.loyaltyPoints,
    );
  }

  static DateTime? _parseDateTime(dynamic value) {
    if (value == null) return null;
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) return DateTime.tryParse(value);
    return null;
  }
}

/// 🔍 INFORMACIÓN DE AUDITORÍA
class AuditInfo {
  final String createdBy;
  final String? lastModifiedBy;
  final List<AuditLog> logs;
  final Map<String, dynamic>? metadata;

  const AuditInfo({
    required this.createdBy,
    this.lastModifiedBy,
    this.logs = const [],
    this.metadata,
  });

  factory AuditInfo.fromMap(Map<String, dynamic> data) {
    return AuditInfo(
      createdBy: data['createdBy'] ?? 'system',
      lastModifiedBy: data['lastModifiedBy'],
      logs: _parseAuditLogs(data['logs']),
      metadata: data['metadata'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'createdBy': createdBy,
      'lastModifiedBy': lastModifiedBy,
      'logs': logs.map((log) => log.toMap()).toList(),
      'metadata': metadata,
    };
  }

  AuditInfo copyWith({
    String? createdBy,
    String? lastModifiedBy,
    List<AuditLog>? logs,
    Map<String, dynamic>? metadata,
  }) {
    return AuditInfo(
      createdBy: createdBy ?? this.createdBy,
      lastModifiedBy: lastModifiedBy ?? this.lastModifiedBy,
      logs: logs ?? this.logs,
      metadata: metadata ?? this.metadata,
    );
  }

  static List<AuditLog> _parseAuditLogs(dynamic data) {
    if (data is! List) return [];
    return data.map((item) => AuditLog.fromMap(item)).toList();
  }
}

/// 📝 LOG DE AUDITORÍA
class AuditLog {
  final String action;
  final String userId;
  final DateTime timestamp;
  final Map<String, dynamic>? details;

  const AuditLog({
    required this.action,
    required this.userId,
    required this.timestamp,
    this.details,
  });

  factory AuditLog.fromMap(Map<String, dynamic> data) {
    return AuditLog(
      action: data['action'] ?? '',
      userId: data['userId'] ?? '',
      timestamp: _parseDateTime(data['timestamp']) ?? DateTime.now(),
      details: data['details'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'action': action,
      'userId': userId,
      'timestamp': Timestamp.fromDate(timestamp),
      'details': details,
    };
  }

  static DateTime? _parseDateTime(dynamic value) {
    if (value == null) return null;
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) return DateTime.tryParse(value);
    return null;
  }
}

/// 📱 REDES SOCIALES
class SocialMedia {
  final String platform;
  final String username;
  final String? url;

  const SocialMedia({
    required this.platform,
    required this.username,
    this.url,
  });

  factory SocialMedia.fromMap(Map<String, dynamic> data) {
    return SocialMedia(
      platform: data['platform'] ?? '',
      username: data['username'] ?? '',
      url: data['url'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'platform': platform,
      'username': username,
      'url': url,
    };
  }
}

/// 📞 PREFERENCIAS DE CONTACTO
class ContactPreferences {
  final bool allowEmail;
  final bool allowSMS;
  final bool allowWhatsApp;
  final bool allowCalls;
  final List<String> preferredDays;
  final String? preferredTimeSlot;

  const ContactPreferences({
    this.allowEmail = true,
    this.allowSMS = true,
    this.allowWhatsApp = true,
    this.allowCalls = true,
    this.preferredDays = const [],
    this.preferredTimeSlot,
  });

  factory ContactPreferences.fromMap(Map<String, dynamic> data) {
    return ContactPreferences(
      allowEmail: data['allowEmail'] ?? true,
      allowSMS: data['allowSMS'] ?? true,
      allowWhatsApp: data['allowWhatsApp'] ?? true,
      allowCalls: data['allowCalls'] ?? true,
      preferredDays: List<String>.from(data['preferredDays'] ?? []),
      preferredTimeSlot: data['preferredTimeSlot'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'allowEmail': allowEmail,
      'allowSMS': allowSMS,
      'allowWhatsApp': allowWhatsApp,
      'allowCalls': allowCalls,
      'preferredDays': preferredDays,
      'preferredTimeSlot': preferredTimeSlot,
    };
  }
}

/// 📋 CRITERIOS DE FILTRO
class ClientFilterCriteria {
  final List<ClientStatus> statuses;
  final List<String> tags;
  final DateTimeRange? dateRange;
  final List<String> alcaldias;
  final int? minAppointments;
  final double? minRevenue;
  final double? minSatisfaction;

  const ClientFilterCriteria({
    this.statuses = const [],
    this.tags = const [],
    this.dateRange,
    this.alcaldias = const [],
    this.minAppointments,
    this.minRevenue,
    this.minSatisfaction,
  });

  bool get isEmpty {
    return statuses.isEmpty &&
           tags.isEmpty &&
           dateRange == null &&
           alcaldias.isEmpty &&
           minAppointments == null &&
           minRevenue == null &&
           minSatisfaction == null;
  }

  ClientFilterCriteria copyWith({
    List<ClientStatus>? statuses,
    List<String>? tags,
    DateTimeRange? dateRange,
    List<String>? alcaldias,
    int? minAppointments,
    double? minRevenue,
    double? minSatisfaction,
  }) {
    return ClientFilterCriteria(
      statuses: statuses ?? this.statuses,
      tags: tags ?? this.tags,
      dateRange: dateRange ?? this.dateRange,
      alcaldias: alcaldias ?? this.alcaldias,
      minAppointments: minAppointments ?? this.minAppointments,
      minRevenue: minRevenue ?? this.minRevenue,
      minSatisfaction: minSatisfaction ?? this.minSatisfaction,
    );
  }
}

/// 📋 ENUMS
enum ClientStatus {
  active('Activo', Colors.green),
  inactive('Inactivo', Colors.orange),
  suspended('Suspendido', Colors.red),
  prospect('Prospecto', Colors.blue),
  vip('VIP', Colors.purple);

  const ClientStatus(this.displayName, this.color);
  final String displayName;
  final Color color;

  bool get isActive => this == ClientStatus.active || this == ClientStatus.vip;
}

enum TagType {
  base('Base'),
  custom('Personalizado'),
  system('Sistema');

  const TagType(this.displayName);
  final String displayName;
}

/// 📊 EXTENSIONES PARA LISTAS DE CLIENTES
extension ClientModelListExtensions on List<ClientModel> {
  List<ClientModel> get activeClients => where((c) => c.isActive).toList();
  
  List<ClientModel> get vipClients => where((c) => c.isVIP).toList();
  
  List<ClientModel> get corporateClients => where((c) => c.isCorporate).toList();
  
  List<ClientModel> get newClients => where((c) => c.isNew).toList();

  List<ClientModel> filterByStatus(ClientStatus status) =>
      where((c) => c.status == status).toList();

  List<ClientModel> filterByTag(String tag) =>
      where((c) => c.hasTag(tag)).toList();

  List<ClientModel> filterByAlcaldia(String alcaldia) =>
      where((c) => c.addressInfo.alcaldia == alcaldia).toList();

  List<ClientModel> search(String query) =>
      where((c) => c.matchesSearchQuery(query)).toList();

  List<ClientModel> filterByCriteria(ClientFilterCriteria criteria) =>
      where((c) => c.matchesFilter(criteria)).toList();

  Map<ClientStatus, int> get countByStatus {
    final counts = <ClientStatus, int>{};
    for (final client in this) {
      counts[client.status] = (counts[client.status] ?? 0) + 1;
    }
    return counts;
  }

  Map<String, int> get countByTag {
    final counts = <String, int>{};
    for (final client in this) {
      for (final tag in client.tags) {
        counts[tag.label] = (counts[tag.label] ?? 0) + 1;
      }
    }
    return counts;
  }

  Map<String, int> get countByAlcaldia {
    final counts = <String, int>{};
    for (final client in this) {
      final alcaldia = client.addressInfo.alcaldia;
      if (alcaldia.isNotEmpty) {
        counts[alcaldia] = (counts[alcaldia] ?? 0) + 1;
      }
    }
    return counts;
  }

  double get averageSatisfaction {
    if (isEmpty) return 0.0;
    final total = fold(0.0, (sum, c) => sum + c.metrics.satisfactionScore);
    return total / length;
  }

  double get totalRevenue {
    return fold(0.0, (sum, c) => sum + c.metrics.totalRevenue);
  }

  int get totalAppointments {
    return fold(0, (sum, c) => sum + c.metrics.appointmentsCount);
  }

  List<String> get allTags {
    final tags = <String>{};
    for (final client in this) {
      tags.addAll(client.tags.map((t) => t.label));
    }
    return tags.toList();
  }

  List<String> get allAlcaldias {
    final alcaldias = <String>{};
    for (final client in this) {
      if (client.addressInfo.alcaldia.isNotEmpty) {
        alcaldias.add(client.addressInfo.alcaldia);
      }
    }
    return alcaldias.toList();
  }

  // Ordenamiento
  List<ClientModel> sortByName() {
    final sorted = List<ClientModel>.from(this);
    sorted.sort((a, b) => a.fullName.compareTo(b.fullName));
    return sorted;
  }

  List<ClientModel> sortByCreatedDate() {
    final sorted = List<ClientModel>.from(this);
    sorted.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return sorted;
  }

  List<ClientModel> sortByRevenue() {
    final sorted = List<ClientModel>.from(this);
    sorted.sort((a, b) => b.totalRevenue.compareTo(a.totalRevenue));
    return sorted;
  }

  List<ClientModel> sortByAppointments() {
    final sorted = List<ClientModel>.from(this);
    sorted.sort((a, b) => b.appointmentsCount.compareTo(a.appointmentsCount));
    return sorted;
  }

  List<ClientModel> sortBySatisfaction() {
    final sorted = List<ClientModel>.from(this);
    sorted.sort((a, b) => b.avgSatisfaction.compareTo(a.avgSatisfaction));
    return sorted;
  }
}