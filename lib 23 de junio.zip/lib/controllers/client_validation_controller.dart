// [client_validation_controller.dart] - VALIDACIONES ENTERPRISE EN TIEMPO REAL - CORREGIDO
// 📁 Ubicación: /lib/controllers/client_validation_controller.dart
// 🎯 OBJETIVO: Sistema de validaciones dinámicas y robustas para formularios de cliente

import 'dart:async'; // ✅ AGREGADO: Import para Timer
import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:agenda_fisio_spa_kym/models/clients/client_model.dart';
import 'package:agenda_fisio_spa_kym/services/cost_control/background_cost_monitor.dart';
import 'package:agenda_fisio_spa_kym/services/cost_control/cost_data_models.dart';

/// 🛡️ CONTROLADOR DE VALIDACIONES ENTERPRISE
/// Maneja validaciones en tiempo real, unicidad y reglas de negocio
class ClientValidationController extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final BackgroundCostMonitor _costMonitor =
      BackgroundCostMonitor(); // ✅ CORREGIDO: sin .instance

  // ✅ ESTADO DE VALIDACIONES
  final Map<String, ValidationResult> _validationResults = {};
  final Map<String, bool> _fieldValidationInProgress = {};

  // ✅ CONFIGURACIÓN
  static const Duration _debounceDelay =
      Duration(milliseconds: 500); // ✅ CORREGIDO: const
  final Map<String, Timer?> _debounceTimers = {};

  // ✅ GETTERS PÚBLICOS
  Map<String, ValidationResult> get validationResults =>
      Map.unmodifiable(_validationResults);
  bool get isValidating =>
      _fieldValidationInProgress.values.any((inProgress) => inProgress);
  bool get hasErrors =>
      _validationResults.values.any((result) => !result.isValid);
  bool get isFormValid =>
      _validationResults.isNotEmpty && !hasErrors && !isValidating;

  /// 📧 VALIDAR EMAIL CON UNICIDAD
  Future<void> validateEmail(String email, {String? currentClientId}) async {
    const field = 'email'; // ✅ CORREGIDO: const

    // Limpiar timer anterior
    _debounceTimers[field]?.cancel();

    // Validación inmediata de formato
    final formatResult = _validateEmailFormat(email);
    _setValidationResult(field, formatResult);

    if (!formatResult.isValid || email.trim().isEmpty) {
      return;
    }

    // ✅ CORREGIDO: Timer constructor con new
    _debounceTimers[field] = Timer(_debounceDelay, () async {
      await _validateEmailUniqueness(email, currentClientId);
    });
  }

  /// 📱 VALIDAR TELÉFONO MEXICANO
  void validatePhone(String phone) {
    const field = 'phone'; // ✅ CORREGIDO: const

    _debounceTimers[field]?.cancel();
    _debounceTimers[field] = Timer(_debounceDelay, () {
      final result = _validatePhoneFormat(phone);
      _setValidationResult(field, result);
    });
  }

  /// 🏠 VALIDAR CÓDIGO POSTAL
  Future<void> validatePostalCode(String postalCode) async {
    const field = 'postalCode'; // ✅ CORREGIDO: const

    _debounceTimers[field]?.cancel();

    // Validación inmediata de formato
    final formatResult = _validatePostalCodeFormat(postalCode);
    _setValidationResult(field, formatResult);

    if (!formatResult.isValid || postalCode.trim().isEmpty) {
      return;
    }

    // Debounce para validación con API
    _debounceTimers[field] = Timer(_debounceDelay, () async {
      await _validatePostalCodeWithAPI(postalCode);
    });
  }

  /// 👤 VALIDAR NOMBRE COMPLETO
  void validateFullName(String firstName, String lastName) {
    final nameResult =
        _validateRequiredField(firstName, 'El nombre es requerido');
    final lastNameResult =
        _validateRequiredField(lastName, 'Los apellidos son requeridos');

    _setValidationResult('firstName', nameResult);
    _setValidationResult('lastName', lastNameResult);

    // Validación adicional: longitud mínima
    if (nameResult.isValid && firstName.trim().length < 2) {
      _setValidationResult(
          'firstName',
          const ValidationResult(
            // ✅ CORREGIDO: const
            isValid: false,
            errorMessage: 'El nombre debe tener al menos 2 caracteres',
            warningMessage: null,
          ));
    }

    if (lastNameResult.isValid && lastName.trim().length < 2) {
      _setValidationResult(
          'lastName',
          const ValidationResult(
            // ✅ CORREGIDO: const
            isValid: false,
            errorMessage: 'Los apellidos deben tener al menos 2 caracteres',
            warningMessage: null,
          ));
    }
  }

  /// 🏢 VALIDAR EMPRESA (OPCIONAL)
  void validateCompany(String company) {
    if (company.trim().isEmpty) {
      _removeValidationResult('company');
      return;
    }

    if (company.trim().length < 2) {
      _setValidationResult(
          'company',
          const ValidationResult(
            // ✅ CORREGIDO: const
            isValid: false,
            errorMessage:
                'El nombre de la empresa debe tener al menos 2 caracteres',
            warningMessage: null,
          ));
    } else {
      _setValidationResult(
          'company',
          const ValidationResult(
            // ✅ CORREGIDO: const
            isValid: true,
            errorMessage: null,
            warningMessage: null,
          ));
    }
  }

  /// 🗺️ VALIDAR DIRECCIÓN COMPLETA
  void validateAddress({
    required String street,
    required String exteriorNumber,
    String? interiorNumber,
    required String neighborhood,
    required String postalCode,
    required String municipality,
  }) {
    // Validar campos requeridos
    _setValidationResult(
        'street', _validateRequiredField(street, 'La calle es requerida'));
    _setValidationResult(
        'exteriorNumber',
        _validateRequiredField(
            exteriorNumber, 'El número exterior es requerido'));
    _setValidationResult('neighborhood',
        _validateRequiredField(neighborhood, 'La colonia es requerida'));
    _setValidationResult('municipality',
        _validateRequiredField(municipality, 'La alcaldía es requerida'));

    // Validar formato de números
    if (exteriorNumber.trim().isNotEmpty &&
        !RegExp(r'^[0-9A-Za-z\-]+$').hasMatch(exteriorNumber)) {
      _setValidationResult(
          'exteriorNumber',
          const ValidationResult(
            // ✅ CORREGIDO: const
            isValid: false,
            errorMessage: 'Formato de número exterior inválido',
            warningMessage: null,
          ));
    }

    if (interiorNumber != null &&
        interiorNumber.trim().isNotEmpty &&
        !RegExp(r'^[0-9A-Za-z\-]+$').hasMatch(interiorNumber)) {
      _setValidationResult(
          'interiorNumber',
          const ValidationResult(
            // ✅ CORREGIDO: const
            isValid: false,
            errorMessage: 'Formato de número interior inválido',
            warningMessage: null,
          ));
    }
  }

  /// 🏷️ VALIDAR ETIQUETAS
  void validateTags(List<ClientTag> tags) {
    if (tags.isEmpty) {
      _setValidationResult(
          'tags',
          const ValidationResult(
            // ✅ CORREGIDO: const
            isValid: true,
            errorMessage: null,
            warningMessage: 'Se recomienda agregar al menos una etiqueta',
          ));
      return;
    }

    // Validar longitud de etiquetas personalizadas
    for (final tag in tags.where((t) => t.type == TagType.custom)) {
      if (tag.label.length > 20) {
        _setValidationResult(
            'tags',
            const ValidationResult(
              // ✅ CORREGIDO: const
              isValid: false,
              errorMessage: 'Las etiquetas no pueden exceder 20 caracteres',
              warningMessage: null,
            ));
        return;
      }
    }

    // Validar número máximo de etiquetas
    if (tags.length > 10) {
      _setValidationResult(
          'tags',
          const ValidationResult(
            // ✅ CORREGIDO: const
            isValid: false,
            errorMessage: 'Máximo 10 etiquetas por cliente',
            warningMessage: null,
          ));
      return;
    }

    _setValidationResult(
        'tags',
        const ValidationResult(
          // ✅ CORREGIDO: const
          isValid: true,
          errorMessage: null,
          warningMessage: null,
        ));
  }

  /// 🔍 VALIDAR FORMULARIO COMPLETO
  bool validateCompleteForm({
    required String firstName,
    required String lastName,
    required String email,
    required String phone,
    String? company,
    required String street,
    required String exteriorNumber,
    String? interiorNumber,
    required String neighborhood,
    required String postalCode,
    required String municipality,
    required List<ClientTag> tags,
    String? currentClientId,
  }) {
    // Ejecutar todas las validaciones
    validateFullName(firstName, lastName);
    validatePhone(phone);
    validateCompany(company ?? '');
    validateAddress(
      street: street,
      exteriorNumber: exteriorNumber,
      interiorNumber: interiorNumber,
      neighborhood: neighborhood,
      postalCode: postalCode,
      municipality: municipality,
    );
    validateTags(tags);

    // Las validaciones asíncronas (email, CP) deben haberse ejecutado previamente
    return isFormValid && !isValidating;
  }

  /// 🧹 LIMPIAR VALIDACIONES
  void clearValidations() {
    _validationResults.clear();
    _fieldValidationInProgress.clear();

    // Cancelar timers
    for (final timer in _debounceTimers.values) {
      timer?.cancel();
    }
    _debounceTimers.clear();

    notifyListeners();
  }

  /// 🔧 LIMPIAR VALIDACIÓN ESPECÍFICA
  void clearFieldValidation(String field) {
    _validationResults.remove(field);
    _fieldValidationInProgress.remove(field);
    _debounceTimers[field]?.cancel();
    _debounceTimers.remove(field);
    notifyListeners();
  }

  // ========================================================================
  // 🔒 MÉTODOS PRIVADOS DE VALIDACIÓN
  // ========================================================================

  ValidationResult _validateRequiredField(String value, String errorMessage) {
    if (value.trim().isEmpty) {
      return ValidationResult(
        isValid: false,
        errorMessage: errorMessage,
        warningMessage: null,
      );
    }

    return const ValidationResult(
      // ✅ CORREGIDO: const
      isValid: true,
      errorMessage: null,
      warningMessage: null,
    );
  }

  ValidationResult _validateEmailFormat(String email) {
    if (email.trim().isEmpty) {
      return const ValidationResult(
        // ✅ CORREGIDO: const
        isValid: false,
        errorMessage: 'El correo electrónico es requerido',
        warningMessage: null,
      );
    }

    // Patrón de email robusto
    final emailRegex =
        RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');

    if (!emailRegex.hasMatch(email.trim())) {
      return const ValidationResult(
        // ✅ CORREGIDO: const
        isValid: false,
        errorMessage: 'Formato de correo electrónico inválido',
        warningMessage: null,
      );
    }

    return const ValidationResult(
      // ✅ CORREGIDO: const
      isValid: true,
      errorMessage: null,
      warningMessage: null,
    );
  }

  Future<void> _validateEmailUniqueness(
      String email, String? currentClientId) async {
    const field = 'email';

    try {
      // ✅ CORREGIDO: Verificar límites de costo con API correcta
      if (_costMonitor.currentStats.dailyReadCount >=
          CostControlConfig.dailyReadLimit) {
        _setValidationResult(
            field,
            const ValidationResult(
              // ✅ CORREGIDO: const
              isValid: true,
              errorMessage: null,
              warningMessage:
                  'No se pudo verificar unicidad (límite de costos)',
            ));
        return;
      }

      _setFieldValidationInProgress(field, true);

      final query = await _firestore
          .collection('clients')
          .where('correo', isEqualTo: email.trim().toLowerCase())
          .limit(1)
          .get();

      // ✅ CORREGIDO: Registrar consulta con API correcta
      _costMonitor.incrementReadCount(1, description: 'Email validation');

      // Si hay resultados y no es el cliente actual
      if (query.docs.isNotEmpty) {
        final existingClientId = query.docs.first.id;
        if (currentClientId == null || existingClientId != currentClientId) {
          _setValidationResult(
              field,
              const ValidationResult(
                // ✅ CORREGIDO: const
                isValid: false,
                errorMessage: 'Este correo ya está registrado por otro cliente',
                warningMessage: null,
              ));
          return;
        }
      }

      _setValidationResult(
          field,
          const ValidationResult(
            // ✅ CORREGIDO: const
            isValid: true,
            errorMessage: null,
            warningMessage: null,
          ));
    } catch (e) {
      debugPrint('❌ Error validando unicidad de email: $e');
      _setValidationResult(
          field,
          const ValidationResult(
            // ✅ CORREGIDO: const
            isValid: true,
            errorMessage: null,
            warningMessage: 'No se pudo verificar unicidad del correo',
          ));
    } finally {
      _setFieldValidationInProgress(field, false);
    }
  }

  ValidationResult _validatePhoneFormat(String phone) {
    if (phone.trim().isEmpty) {
      return const ValidationResult(
        // ✅ CORREGIDO: const
        isValid: false,
        errorMessage: 'El teléfono es requerido',
        warningMessage: null,
      );
    }

    // Remover caracteres no numéricos para validación
    final numbersOnly = phone.replaceAll(RegExp(r'[^0-9]'), '');

    // Validar longitud (10 dígitos para México)
    if (numbersOnly.length != 10) {
      return const ValidationResult(
        // ✅ CORREGIDO: const
        isValid: false,
        errorMessage: 'El teléfono debe tener 10 dígitos',
        warningMessage: null,
      );
    }

    // Validar que no todos sean el mismo dígito
    if (RegExp(r'^(\d)\1{9}$').hasMatch(numbersOnly)) {
      return const ValidationResult(
        // ✅ CORREGIDO: const
        isValid: false,
        errorMessage: 'Número de teléfono inválido',
        warningMessage: null,
      );
    }

    return const ValidationResult(
      // ✅ CORREGIDO: const
      isValid: true,
      errorMessage: null,
      warningMessage: null,
    );
  }

  ValidationResult _validatePostalCodeFormat(String postalCode) {
    if (postalCode.trim().isEmpty) {
      return const ValidationResult(
        // ✅ CORREGIDO: const
        isValid: false,
        errorMessage: 'El código postal es requerido',
        warningMessage: null,
      );
    }

    // Validar formato mexicano (5 dígitos)
    if (!RegExp(r'^\d{5}$').hasMatch(postalCode.trim())) {
      return const ValidationResult(
        // ✅ CORREGIDO: const
        isValid: false,
        errorMessage: 'El código postal debe tener 5 dígitos',
        warningMessage: null,
      );
    }

    return const ValidationResult(
      // ✅ CORREGIDO: const
      isValid: true,
      errorMessage: null,
      warningMessage: null,
    );
  }

  Future<void> _validatePostalCodeWithAPI(String postalCode) async {
    const field = 'postalCode';

    try {
      _setFieldValidationInProgress(field, true);

      // ✅ MANTENIDO: Implementar validación con API de SEPOMEX
      // Por ahora, validación básica de rangos conocidos
      final code = int.tryParse(postalCode);
      if (code == null || code < 1000 || code > 99999) {
        _setValidationResult(
            field,
            const ValidationResult(
              // ✅ CORREGIDO: const
              isValid: false,
              errorMessage: 'Código postal fuera del rango válido',
              warningMessage: null,
            ));
        return;
      }

      // Simulación de validación exitosa
      await Future.delayed(const Duration(milliseconds: 300));

      _setValidationResult(
          field,
          const ValidationResult(
            // ✅ CORREGIDO: const
            isValid: true,
            errorMessage: null,
            warningMessage: null,
          ));
    } catch (e) {
      debugPrint('❌ Error validando código postal: $e');
      _setValidationResult(
          field,
          const ValidationResult(
            // ✅ CORREGIDO: const
            isValid: true,
            errorMessage: null,
            warningMessage: 'No se pudo verificar el código postal',
          ));
    } finally {
      _setFieldValidationInProgress(field, false);
    }
  }

  // ========================================================================
  // 🔧 MÉTODOS HELPER
  // ========================================================================

  void _setValidationResult(String field, ValidationResult result) {
    _validationResults[field] = result;
    notifyListeners();
  }

  void _removeValidationResult(String field) {
    _validationResults.remove(field);
    notifyListeners();
  }

  void _setFieldValidationInProgress(String field, bool inProgress) {
    if (inProgress) {
      _fieldValidationInProgress[field] = true;
    } else {
      _fieldValidationInProgress.remove(field);
    }
    notifyListeners();
  }

  /// 📊 OBTENER RESULTADO DE VALIDACIÓN ESPECÍFICO
  ValidationResult? getValidationResult(String field) {
    return _validationResults[field];
  }

  /// 🔍 VERIFICAR SI CAMPO ESTÁ SIENDO VALIDADO
  bool isFieldValidating(String field) {
    return _fieldValidationInProgress[field] ?? false;
  }

  /// 📋 OBTENER RESUMEN DE VALIDACIÓN
  ValidationSummary getValidationSummary() {
    final totalFields = _validationResults.length;
    final validFields =
        _validationResults.values.where((r) => r.isValid).length;
    final fieldsWithErrors =
        _validationResults.values.where((r) => !r.isValid).length;
    final fieldsWithWarnings =
        _validationResults.values.where((r) => r.warningMessage != null).length;

    return ValidationSummary(
      totalFields: totalFields,
      validFields: validFields,
      fieldsWithErrors: fieldsWithErrors,
      fieldsWithWarnings: fieldsWithWarnings,
      isFormValid: isFormValid,
      isValidating: isValidating,
    );
  }

  @override
  void dispose() {
    // Cancelar todos los timers
    for (final timer in _debounceTimers.values) {
      timer?.cancel();
    }
    _debounceTimers.clear();

    super.dispose();
  }
}

// ========================================================================
// 📊 MODELOS DE DATOS
// ========================================================================

/// 🎯 RESULTADO DE VALIDACIÓN
class ValidationResult {
  final bool isValid;
  final String? errorMessage;
  final String? warningMessage;

  const ValidationResult({
    required this.isValid,
    this.errorMessage,
    this.warningMessage,
  });

  bool get hasError => errorMessage != null;
  bool get hasWarning => warningMessage != null;

  @override
  String toString() {
    return 'ValidationResult(isValid: $isValid, error: $errorMessage, warning: $warningMessage)';
  }
}

/// 📈 RESUMEN DE VALIDACIÓN
class ValidationSummary {
  final int totalFields;
  final int validFields;
  final int fieldsWithErrors;
  final int fieldsWithWarnings;
  final bool isFormValid;
  final bool isValidating;

  const ValidationSummary({
    required this.totalFields,
    required this.validFields,
    required this.fieldsWithErrors,
    required this.fieldsWithWarnings,
    required this.isFormValid,
    required this.isValidating,
  });

  double get validationProgress {
    if (totalFields == 0) return 0.0;
    return validFields / totalFields;
  }

  @override
  String toString() {
    return 'ValidationSummary(total: $totalFields, valid: $validFields, errors: $fieldsWithErrors, warnings: $fieldsWithWarnings)';
  }
}
