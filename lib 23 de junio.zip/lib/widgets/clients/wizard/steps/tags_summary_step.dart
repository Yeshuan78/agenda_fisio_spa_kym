// [tags_summary_step.dart] - PASO 3: ETIQUETAS Y CONFIRMACIÓN FINAL
// 📁 Ubicación: /lib/widgets/clients/wizard/steps/tags_summary_step.dart
// 🎯 OBJETIVO: Paso final con tags + resumen completo del cliente

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/controllers/client_form_controller.dart';
import 'package:agenda_fisio_spa_kym/models/clients/client_form_model.dart';
import 'package:agenda_fisio_spa_kym/models/clients/client_model.dart';

/// 🏷️ PASO 3: ETIQUETAS Y CONFIRMACIÓN PARA WIZARD
/// Paso final con gestión de etiquetas + resumen visual completo
class TagsSummaryStep extends StatefulWidget {
  final ClientFormController formController;
  final bool isEditMode;

  const TagsSummaryStep({
    super.key,
    required this.formController,
    this.isEditMode = false,
  });

  @override
  State<TagsSummaryStep> createState() => _TagsSummaryStepState();
}

class _TagsSummaryStepState extends State<TagsSummaryStep>
    with AutomaticKeepAliveClientMixin {
  // ✅ CONTROLADOR PARA NUEVAS ETIQUETAS
  final TextEditingController _newTagController = TextEditingController();
  final FocusNode _newTagFocus = FocusNode();

  // ✅ ETIQUETAS BASE DISPONIBLES
  static const List<Map<String, dynamic>> _baseTags = [
    {'label': 'VIP', 'icon': Icons.star, 'color': Colors.purple},
    {'label': 'Corporativo', 'icon': Icons.business, 'color': Colors.blue},
    {'label': 'Nuevo', 'icon': Icons.fiber_new, 'color': Colors.green},
    {'label': 'Recurrente', 'icon': Icons.repeat, 'color': Colors.orange},
    {'label': 'Promoción', 'icon': Icons.local_offer, 'color': Colors.red},
    {'label': 'Consentido', 'icon': Icons.favorite, 'color': Colors.pink},
    {'label': 'Especial', 'icon': Icons.star_border, 'color': Colors.amber},
  ];

  @override
  bool get wantKeepAlive => true;

  @override
  void dispose() {
    _newTagController.dispose();
    _newTagFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    return ValueListenableBuilder<TagsFormInfo>(
      valueListenable: widget.formController.tagsInfoNotifier,
      builder: (context, tagsInfo, child) {
        return ValueListenableBuilder<PersonalFormInfo>(
          valueListenable: widget.formController.personalInfoNotifier,
          builder: (context, personalInfo, child) {
            return ValueListenableBuilder<AddressFormInfo>(
              valueListenable: widget.formController.addressInfoNotifier,
              builder: (context, addressInfo, child) {
                return SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildStepIntro(),
                      const SizedBox(height: 24),
                      _buildClientSummaryCard(personalInfo, addressInfo),
                      const SizedBox(height: 24),
                      _buildTagsManagement(tagsInfo),
                      const SizedBox(height: 24),
                      _buildFinalValidation(),
                    ],
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  Widget _buildStepIntro() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            kAccentGreen.withValues(alpha: 0.08),
            kAccentGreen.withValues(alpha: 0.03),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: kAccentGreen.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  kAccentGreen.withValues(alpha: 0.2),
                  kAccentGreen.withValues(alpha: 0.1),
                ],
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: kAccentGreen.withValues(alpha: 0.3),
                width: 1.5,
              ),
            ),
            child: const Icon(
              Icons.label_outline,
              color: kAccentGreen,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.isEditMode
                      ? 'Actualizar Cliente'
                      : 'Confirmar Nuevo Cliente',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: kAccentGreen,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Etiquetas y confirmación final de la información',
                  style: TextStyle(
                    fontSize: 14,
                    color: kTextSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildClientSummaryCard(
      PersonalFormInfo personalInfo, AddressFormInfo addressInfo) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withValues(alpha: 0.9),
            Colors.white.withValues(alpha: 0.7),
            kBrandPurple.withValues(alpha: 0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: kBrandPurple.withValues(alpha: 0.2),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: kBrandPurple.withValues(alpha: 0.1),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.preview_outlined,
                color: kBrandPurple,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Resumen del Cliente',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: kBrandPurple,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Header del cliente
          Row(
            children: [
              _buildClientAvatar(personalInfo),
              const SizedBox(width: 16),
              Expanded(
                child: _buildClientBasicInfo(personalInfo),
              ),
              _buildValidationBadge(),
            ],
          ),

          const SizedBox(height: 20),
          Divider(color: kBorderSoft),
          const SizedBox(height: 16),

          // Información detallada
          _buildDetailedInfo(personalInfo, addressInfo),
        ],
      ),
    );
  }

  Widget _buildClientAvatar(PersonalFormInfo personalInfo) {
    return Container(
      width: 70,
      height: 70,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            kBrandPurple.withValues(alpha: 0.2),
            kBrandPurple.withValues(alpha: 0.1),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: kBrandPurple.withValues(alpha: 0.3),
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: kBrandPurple.withValues(alpha: 0.2),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Center(
        child: Text(
          _getInitials(personalInfo.fullName),
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: kBrandPurple,
          ),
        ),
      ),
    );
  }

  Widget _buildClientBasicInfo(PersonalFormInfo personalInfo) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          personalInfo.fullName.isNotEmpty
              ? personalInfo.fullName
              : 'Nombre del Cliente',
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 4),
        if (personalInfo.email.isNotEmpty)
          Row(
            children: [
              Icon(Icons.email_outlined, size: 16, color: kTextSecondary),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  personalInfo.email,
                  style: TextStyle(
                    fontSize: 14,
                    color: kTextSecondary,
                  ),
                ),
              ),
            ],
          ),
        if (personalInfo.telefono.isNotEmpty) ...[
          const SizedBox(height: 2),
          Row(
            children: [
              Icon(Icons.phone_outlined, size: 16, color: kTextSecondary),
              const SizedBox(width: 6),
              Text(
                personalInfo.telefono,
                style: TextStyle(
                  fontSize: 14,
                  color: kTextSecondary,
                ),
              ),
            ],
          ),
        ],
        if (personalInfo.empresa?.isNotEmpty == true) ...[
          const SizedBox(height: 2),
          Row(
            children: [
              Icon(Icons.business_outlined, size: 16, color: kTextSecondary),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  personalInfo.empresa!,
                  style: TextStyle(
                    fontSize: 14,
                    color: kTextSecondary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildValidationBadge() {
    final isValid = widget.formController.formData.isValid;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: isValid
            ? Colors.green.withValues(alpha: 0.1)
            : Colors.orange.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isValid
              ? Colors.green.withValues(alpha: 0.3)
              : Colors.orange.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isValid ? Icons.check_circle : Icons.warning_amber,
            color: isValid ? Colors.green.shade600 : Colors.orange.shade600,
            size: 16,
          ),
          const SizedBox(width: 6),
          Text(
            isValid ? 'VÁLIDO' : 'INCOMPLETO',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: isValid ? Colors.green.shade700 : Colors.orange.shade700,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailedInfo(
      PersonalFormInfo personalInfo, AddressFormInfo addressInfo) {
    return Column(
      children: [
        // Información de contacto
        _buildInfoSection(
          'Información de Contacto',
          Icons.contact_mail_outlined,
          [
            _buildInfoRow('Email', personalInfo.email, Icons.email_outlined),
            _buildInfoRow(
                'Teléfono', personalInfo.telefono, Icons.phone_outlined),
            if (personalInfo.empresa?.isNotEmpty == true)
              _buildInfoRow(
                  'Empresa', personalInfo.empresa!, Icons.business_outlined),
          ],
        ),

        const SizedBox(height: 16),

        // Información de dirección
        _buildInfoSection(
          'Dirección',
          Icons.location_on_outlined,
          [
            _buildInfoRow('Dirección Completa', addressInfo.fullAddress,
                Icons.home_outlined),
            _buildInfoRow('Alcaldía', addressInfo.alcaldia,
                Icons.account_balance_outlined),
            _buildInfoRow('Código Postal', addressInfo.codigoPostal,
                Icons.markunread_mailbox_outlined),
          ],
        ),
      ],
    );
  }

  Widget _buildInfoSection(String title, IconData icon, List<Widget> children) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.6),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: kBorderSoft,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: kBrandPurple, size: 18),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: kBrandPurple,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value, IconData icon) {
    if (value.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: kTextMuted),
          const SizedBox(width: 8),
          Text(
            '$label: ',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: kTextSecondary,
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 13,
                color: Colors.black87,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTagsManagement(TagsFormInfo tagsInfo) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            kAccentGreen.withValues(alpha: 0.05),
            kAccentGreen.withValues(alpha: 0.02),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: kAccentGreen.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.label_outline,
                color: kAccentGreen,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Etiquetas del Cliente',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: kAccentGreen,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Etiquetas base
          _buildBaseTagsSection(tagsInfo),

          const SizedBox(height: 20),

          // Etiquetas personalizadas
          _buildCustomTagsSection(tagsInfo),

          const SizedBox(height: 16),

          // Agregar nueva etiqueta
          _buildAddTagSection(),
        ],
      ),
    );
  }

  Widget _buildBaseTagsSection(TagsFormInfo tagsInfo) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Etiquetas Base',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: kTextSecondary,
          ),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: _baseTags.map((tag) {
            final isSelected = tagsInfo.baseTags.contains(tag['label']);
            return _buildSelectableTag(
              label: tag['label'],
              icon: tag['icon'],
              color: tag['color'],
              isSelected: isSelected,
              onTap: () => _toggleBaseTag(tag['label']),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildCustomTagsSection(TagsFormInfo tagsInfo) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Etiquetas Personalizadas',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: kTextSecondary,
          ),
        ),
        const SizedBox(height: 12),
        if (tagsInfo.customTags.isEmpty)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: Colors.grey.withValues(alpha: 0.2),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline, color: kTextMuted, size: 18),
                const SizedBox(width: 8),
                Text(
                  'No hay etiquetas personalizadas',
                  style: TextStyle(
                    fontSize: 13,
                    color: kTextMuted,
                  ),
                ),
              ],
            ),
          )
        else
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: tagsInfo.customTags.map((tag) {
              return _buildCustomTag(
                tag,
                onRemove: () => _removeCustomTag(tag),
              );
            }).toList(),
          ),
      ],
    );
  }

  Widget _buildSelectableTag({
    required String label,
    required IconData icon,
    required Color color,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? color.withValues(alpha: 0.15)
              : Colors.white.withValues(alpha: 0.8),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected
                ? color.withValues(alpha: 0.4)
                : color.withValues(alpha: 0.2),
            width: isSelected ? 2 : 1,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: color.withValues(alpha: 0.2),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 16,
              color: isSelected ? color : color.withValues(alpha: 0.7),
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.w600,
                color: isSelected ? color : color.withValues(alpha: 0.8),
              ),
            ),
            if (isSelected) ...[
              const SizedBox(width: 4),
              Icon(
                Icons.check_circle,
                size: 14,
                color: color,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildCustomTag(String tag, {required VoidCallback onRemove}) {
    final color = _getCustomTagColor(tag);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: color.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.label,
            size: 14,
            color: color,
          ),
          const SizedBox(width: 6),
          Text(
            tag,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
          const SizedBox(width: 6),
          GestureDetector(
            onTap: onRemove,
            child: Icon(
              Icons.close,
              size: 14,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddTagSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.6),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: kBorderSoft,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Agregar Etiqueta Personalizada',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: kTextSecondary,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: _newTagController,
                  focusNode: _newTagFocus,
                  decoration: InputDecoration(
                    hintText: 'Nombre de la etiqueta',
                    hintStyle: TextStyle(color: kTextMuted),
                    prefixIcon: Icon(Icons.add, color: kAccentGreen, size: 20),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: kBorderSoft),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: kBorderSoft),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide:
                          const BorderSide(color: kAccentGreen, width: 2),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 12),
                  ),
                  onFieldSubmitted: (_) => _addCustomTag(),
                ),
              ),
              const SizedBox(width: 12),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: kAccentGreen.withValues(alpha: 0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: ElevatedButton.icon(
                  onPressed: _addCustomTag,
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('Agregar'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kAccentGreen,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFinalValidation() {
    final isValid = widget.formController.formData.isValid;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isValid
              ? [
                  Colors.green.withValues(alpha: 0.08),
                  Colors.green.withValues(alpha: 0.03),
                ]
              : [
                  Colors.orange.withValues(alpha: 0.08),
                  Colors.orange.withValues(alpha: 0.03),
                ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isValid
              ? Colors.green.withValues(alpha: 0.2)
              : Colors.orange.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(
                isValid
                    ? Icons.check_circle_outline
                    : Icons.warning_amber_outlined,
                color: isValid ? Colors.green.shade600 : Colors.orange.shade600,
                size: 24,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  isValid
                      ? '¡Todo listo! El cliente está completamente configurado'
                      : 'Hay información pendiente que debe completarse',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: isValid
                        ? Colors.green.shade700
                        : Colors.orange.shade700,
                  ),
                ),
              ),
            ],
          ),
          if (!isValid) ...[
            const SizedBox(height: 12),
            _buildValidationChecklist(),
          ],
        ],
      ),
    );
  }

  Widget _buildValidationChecklist() {
    final personalInfo = widget.formController.formData.personalInfo;
    final addressInfo = widget.formController.formData.addressInfo;

    final checks = [
      {
        'label': 'Nombre completo',
        'valid':
            personalInfo.nombre.isNotEmpty && personalInfo.apellidos.isNotEmpty
      },
      {
        'label': 'Email válido',
        'valid': personalInfo.email.isNotEmpty && personalInfo.isValid
      },
      {'label': 'Teléfono válido', 'valid': personalInfo.telefono.isNotEmpty},
      {'label': 'Dirección completa', 'valid': addressInfo.isValid},
    ];

    return Column(
      children: checks.map((check) {
        final isValid = check['valid'] as bool;
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(
            children: [
              Icon(
                isValid ? Icons.check_circle : Icons.radio_button_unchecked,
                color: isValid ? Colors.green.shade600 : Colors.orange.shade600,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                check['label'] as String,
                style: TextStyle(
                  fontSize: 14,
                  color:
                      isValid ? Colors.green.shade700 : Colors.orange.shade700,
                  fontWeight: isValid ? FontWeight.w600 : FontWeight.w500,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  // ========================================================================
  // 🎯 MÉTODOS DE LÓGICA DE NEGOCIO
  // ========================================================================

  void _toggleBaseTag(String tag) {
    HapticFeedback.lightImpact();
    widget.formController.toggleBaseTag(tag);
  }

  void _addCustomTag() {
    final tagText = _newTagController.text.trim();
    if (tagText.isEmpty) return;

    HapticFeedback.lightImpact();

    widget.formController.addCustomTag(tagText);
    _newTagController.clear();
    _newTagFocus.unfocus();
  }

  void _removeCustomTag(String tag) {
    HapticFeedback.lightImpact();
    widget.formController.removeCustomTag(tag);
  }

  // ========================================================================
  // 🔧 MÉTODOS HELPER
  // ========================================================================

  String _getInitials(String fullName) {
    if (fullName.isEmpty) return '?';

    final parts = fullName.trim().split(' ');
    if (parts.length == 1) {
      return parts[0].substring(0, 1).toUpperCase();
    }

    return '${parts[0].substring(0, 1)}${parts[1].substring(0, 1)}'
        .toUpperCase();
  }

  Color _getCustomTagColor(String tag) {
    const colors = [
      Colors.purple,
      Colors.blue,
      Colors.green,
      Colors.orange,
      Colors.red,
      Colors.pink,
      Colors.teal,
      Colors.indigo,
    ];

    final index = tag.hashCode % colors.length;
    return colors[index.abs()];
  }
}
