// [personal_info_step.dart] - PASO 1: INFORMACIÓN PERSONAL OPTIMIZADO PARA WIZARD
// 📁 Ubicación: /lib/widgets/clients/wizard/steps/personal_info_step.dart
// 🎯 OBJETIVO: Adaptar PersonalInfoSection para el wizard modal (sin scroll)

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/controllers/client_form_controller.dart';
import 'package:agenda_fisio_spa_kym/models/clients/client_form_model.dart';
import 'package:agenda_fisio_spa_kym/services/clients/client_form_service.dart';

/// 👤 PASO 1: INFORMACIÓN PERSONAL PARA WIZARD
/// Versión optimizada sin scroll, diseñada para modal 800px
class PersonalInfoStep extends StatefulWidget {
  final ClientFormController formController;

  const PersonalInfoStep({
    super.key,
    required this.formController,
  });

  @override
  State<PersonalInfoStep> createState() => _PersonalInfoStepState();
}

class _PersonalInfoStepState extends State<PersonalInfoStep>
    with AutomaticKeepAliveClientMixin {
  // ✅ CONTROLADORES DE TEXTO
  late final TextEditingController _nombreController;
  late final TextEditingController _apellidosController;
  late final TextEditingController _emailController;
  late final TextEditingController _telefonoController;
  late final TextEditingController _empresaController;

  // ✅ FOCUS NODES PARA NAVEGACIÓN
  final FocusNode _focusNombre = FocusNode();
  final FocusNode _focusApellidos = FocusNode();
  final FocusNode _focusEmail = FocusNode();
  final FocusNode _focusTelefono = FocusNode();
  final FocusNode _focusEmpresa = FocusNode();

  // ✅ ESTADO DE VALIDACIÓN LOCAL
  bool _emailValidating = false;
  bool _emailValid = false;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _initializeControllers();
    _setupListeners();
  }

  void _initializeControllers() {
    final personalInfo = widget.formController.formData.personalInfo;

    _nombreController = TextEditingController(text: personalInfo.nombre);
    _apellidosController = TextEditingController(text: personalInfo.apellidos);
    _emailController = TextEditingController(text: personalInfo.email);
    _telefonoController = TextEditingController(text: personalInfo.telefono);
    _empresaController =
        TextEditingController(text: personalInfo.empresa ?? '');
  }

  void _setupListeners() {
    // Listeners para actualizar el controlador cuando cambian los campos
    _nombreController.addListener(() {
      widget.formController.updateNombre(_nombreController.text);
    });

    _apellidosController.addListener(() {
      widget.formController.updateApellidos(_apellidosController.text);
    });

    _emailController.addListener(() {
      widget.formController.updateEmail(_emailController.text);
      _validateEmailAsync();
    });

    _telefonoController.addListener(() {
      widget.formController.updateTelefono(_telefonoController.text);
    });

    _empresaController.addListener(() {
      widget.formController.updateEmpresa(_empresaController.text);
    });
  }

  Future<void> _validateEmailAsync() async {
    final email = _emailController.text.trim();

    if (email.isEmpty || !_isValidEmailFormat(email)) {
      setState(() {
        _emailValidating = false;
        _emailValid = false;
      });
      return;
    }

    setState(() {
      _emailValidating = true;
    });

    // Debounce de 800ms
    await Future.delayed(const Duration(milliseconds: 800));

    if (_emailController.text.trim() != email)
      return; // El usuario siguió escribiendo

    try {
      final formService = ClientFormService();
      final isUnique = await formService.isEmailUnique(email);
      if (mounted && _emailController.text.trim() == email) {
        setState(() {
          _emailValidating = false;
          _emailValid = isUnique;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _emailValidating = false;
          _emailValid = true; // Asumir válido si no se puede verificar
        });
      }
    }
  }

  @override
  void dispose() {
    _nombreController.dispose();
    _apellidosController.dispose();
    _emailController.dispose();
    _telefonoController.dispose();
    _empresaController.dispose();

    _focusNombre.dispose();
    _focusApellidos.dispose();
    _focusEmail.dispose();
    _focusTelefono.dispose();
    _focusEmpresa.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    return ValueListenableBuilder<PersonalFormInfo>(
      valueListenable: widget.formController.personalInfoNotifier,
      builder: (context, personalInfo, child) {
        return ValueListenableBuilder(
          valueListenable: widget.formController.validationNotifier,
          builder: (context, validation, child) {
            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildStepIntro(),
                  const SizedBox(height: 24),
                  _buildFormFields(personalInfo, validation),
                  const SizedBox(height: 24),
                  _buildPreviewCard(personalInfo),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildStepIntro() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            kBrandPurple.withValues(alpha: 0.08),
            kBrandPurple.withValues(alpha: 0.03),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: kBrandPurple.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  kAccentBlue.withValues(alpha: 0.2),
                  kBrandPurple.withValues(alpha: 0.1),
                ],
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: kBrandPurple.withValues(alpha: 0.3),
                width: 1.5,
              ),
            ),
            child: const Icon(
              Icons.person_outline,
              color: kBrandPurple,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Información Personal',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: kBrandPurple,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Datos básicos de identificación del cliente',
                  style: TextStyle(
                    fontSize: 14,
                    color: kTextSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFormFields(
      PersonalFormInfo personalInfo, ClientFormValidation validation) {
    return Column(
      children: [
        // Row para Nombre y Apellidos
        Row(
          children: [
            Expanded(
              child: _buildWizardInputField(
                controller: _nombreController,
                label: 'Nombre',
                hintText: 'Ingrese el nombre',
                isRequired: true,
                errorText: validation.getFieldError('nombre'),
                focusNode: _focusNombre,
                nextFocusNode: _focusApellidos,
                prefixIcon: Icons.person,
                keyboardType: TextInputType.name,
                inputFormatters: [
                  FilteringTextInputFormatter.allow(
                      RegExp(r'[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]')),
                  LengthLimitingTextInputFormatter(50),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildWizardInputField(
                controller: _apellidosController,
                label: 'Apellidos',
                hintText: 'Ingrese los apellidos',
                isRequired: true,
                errorText: validation.getFieldError('apellidos'),
                focusNode: _focusApellidos,
                nextFocusNode: _focusEmail,
                prefixIcon: Icons.person_outline,
                keyboardType: TextInputType.name,
                inputFormatters: [
                  FilteringTextInputFormatter.allow(
                      RegExp(r'[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]')),
                  LengthLimitingTextInputFormatter(50),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),

        // Email con validación avanzada
        _buildWizardInputField(
          controller: _emailController,
          label: 'Correo Electrónico',
          hintText: 'ejemplo@correo.com',
          isRequired: true,
          errorText: validation.getFieldError('email'),
          focusNode: _focusEmail,
          nextFocusNode: _focusTelefono,
          prefixIcon: Icons.email_outlined,
          keyboardType: TextInputType.emailAddress,
          inputFormatters: [
            FilteringTextInputFormatter.deny(RegExp(r'\s')), // No espacios
            LengthLimitingTextInputFormatter(100),
          ],
          suffixWidget: _buildEmailValidationIndicator(),
        ),
        const SizedBox(height: 20),

        // Row para Teléfono y Empresa
        Row(
          children: [
            Expanded(
              flex: 3,
              child: _buildWizardInputField(
                controller: _telefonoController,
                label: 'Teléfono',
                hintText: '55 1234 5678',
                isRequired: true,
                errorText: validation.getFieldError('telefono'),
                focusNode: _focusTelefono,
                nextFocusNode: _focusEmpresa,
                prefixIcon: Icons.phone_outlined,
                keyboardType: TextInputType.phone,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(10),
                  _PhoneFormatter(),
                ],
                suffixWidget: _buildPhoneValidationIndicator(),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              flex: 2,
              child: _buildWizardInputField(
                controller: _empresaController,
                label: 'Empresa',
                hintText: 'Empresa (opcional)',
                isRequired: false,
                focusNode: _focusEmpresa,
                prefixIcon: Icons.business_outlined,
                keyboardType: TextInputType.text,
                inputFormatters: [
                  LengthLimitingTextInputFormatter(100),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildWizardInputField({
    required TextEditingController controller,
    required String label,
    required String hintText,
    bool isRequired = false,
    String? errorText,
    FocusNode? focusNode,
    FocusNode? nextFocusNode,
    IconData? prefixIcon,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    Widget? suffixWidget,
  }) {
    final hasError = errorText != null;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Label
        Row(
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: hasError ? Colors.red.shade700 : kTextSecondary,
              ),
            ),
            if (isRequired) ...[
              const SizedBox(width: 4),
              Text(
                '*',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.red.shade600,
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: 8),

        // Input Field
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.white.withValues(alpha: 0.9),
                Colors.white.withValues(alpha: 0.7),
              ],
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: hasError ? Colors.red.withValues(alpha: 0.4) : kBorderSoft,
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: TextFormField(
            controller: controller,
            focusNode: focusNode,
            keyboardType: keyboardType,
            inputFormatters: inputFormatters,
            decoration: InputDecoration(
              hintText: hintText,
              hintStyle: TextStyle(
                color: kTextMuted,
                fontSize: 14,
              ),
              prefixIcon: prefixIcon != null
                  ? Icon(prefixIcon, color: kTextMuted, size: 20)
                  : null,
              suffixIcon: suffixWidget,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 16,
              ),
            ),
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Colors.black87,
            ),
            onFieldSubmitted: (_) {
              if (nextFocusNode != null) {
                FocusScope.of(context).requestFocus(nextFocusNode);
              }
            },
          ),
        ),

        // Error Message
        if (hasError) ...[
          const SizedBox(height: 6),
          Row(
            children: [
              Icon(
                Icons.error_outline,
                size: 16,
                color: Colors.red.shade600,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  errorText,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.red.shade600,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildEmailValidationIndicator() {
    if (_emailValidating) {
      return const Padding(
        padding: EdgeInsets.all(12),
        child: SizedBox(
          width: 16,
          height: 16,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation<Color>(kBrandPurple),
          ),
        ),
      );
    }

    final email = _emailController.text.trim();
    if (email.isEmpty) return const SizedBox.shrink();

    if (!_isValidEmailFormat(email)) {
      return Padding(
        padding: const EdgeInsets.all(12),
        child: Icon(
          Icons.error_outline,
          color: Colors.red.shade600,
          size: 20,
        ),
      );
    }

    if (_emailValid) {
      return Padding(
        padding: const EdgeInsets.all(12),
        child: Icon(
          Icons.check_circle_outline,
          color: Colors.green.shade600,
          size: 20,
        ),
      );
    }

    return const SizedBox.shrink();
  }

  Widget _buildPhoneValidationIndicator() {
    final phoneText = _telefonoController.text.replaceAll(RegExp(r'[^\d]'), '');

    if (phoneText.isEmpty) return const SizedBox.shrink();

    if (phoneText.length == 10) {
      return Padding(
        padding: const EdgeInsets.all(12),
        child: Icon(
          Icons.check_circle_outline,
          color: Colors.green.shade600,
          size: 20,
        ),
      );
    } else {
      return Padding(
        padding: const EdgeInsets.all(12),
        child: Icon(
          Icons.error_outline,
          color: Colors.orange.shade600,
          size: 20,
        ),
      );
    }
  }

  Widget _buildPreviewCard(PersonalFormInfo personalInfo) {
    if (personalInfo.nombre.isEmpty && personalInfo.apellidos.isEmpty) {
      return const SizedBox.shrink();
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            kAccentGreen.withValues(alpha: 0.05),
            kAccentGreen.withValues(alpha: 0.02),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: kAccentGreen.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.preview_outlined,
                color: kAccentGreen,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Vista Previa',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: kAccentGreen,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      kBrandPurple.withValues(alpha: 0.2),
                      kBrandPurple.withValues(alpha: 0.1),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: kBrandPurple.withValues(alpha: 0.3),
                    width: 1.5,
                  ),
                ),
                child: Center(
                  child: Text(
                    _getInitials(personalInfo.fullName),
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: kBrandPurple,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      personalInfo.fullName.isNotEmpty
                          ? personalInfo.fullName
                          : 'Nombre del Cliente',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 4),
                    if (personalInfo.email.isNotEmpty)
                      Text(
                        personalInfo.email,
                        style: TextStyle(
                          fontSize: 14,
                          color: kTextSecondary,
                        ),
                      ),
                    if (personalInfo.empresa?.isNotEmpty == true) ...[
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          Icon(
                            Icons.business_outlined,
                            size: 14,
                            color: kTextMuted,
                          ),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              personalInfo.empresa!,
                              style: TextStyle(
                                fontSize: 13,
                                color: kTextMuted,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              if (personalInfo.isValid)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.green.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: Colors.green.withValues(alpha: 0.3),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.check_circle,
                        color: Colors.green.shade600,
                        size: 14,
                      ),
                      const SizedBox(width: 4),
                      const Text(
                        'VÁLIDO',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  // ========================================================================
  // 🔧 MÉTODOS HELPER
  // ========================================================================

  bool _isValidEmailFormat(String email) {
    return RegExp(r'^[^@]+@[^@]+\.[^@]+$').hasMatch(email.trim());
  }

  String _getInitials(String fullName) {
    if (fullName.isEmpty) return '?';

    final parts = fullName.trim().split(' ');
    if (parts.length == 1) {
      return parts[0].substring(0, 1).toUpperCase();
    }

    return '${parts[0].substring(0, 1)}${parts[1].substring(0, 1)}'
        .toUpperCase();
  }
}

/// 📱 FORMATTER PERSONALIZADO PARA TELÉFONOS MEXICANOS
class _PhoneFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final digitsOnly = newValue.text.replaceAll(RegExp(r'[^\d]'), '');

    if (digitsOnly.length <= 10) {
      String formatted = digitsOnly;

      if (digitsOnly.length > 2) {
        formatted = '${digitsOnly.substring(0, 2)} ${digitsOnly.substring(2)}';
      }
      if (digitsOnly.length > 6) {
        formatted =
            '${digitsOnly.substring(0, 2)} ${digitsOnly.substring(2, 6)} ${digitsOnly.substring(6)}';
      }

      return TextEditingValue(
        text: formatted,
        selection: TextSelection.collapsed(offset: formatted.length),
      );
    }

    return oldValue;
  }
}
