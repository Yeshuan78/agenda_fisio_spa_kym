// [address_info_step.dart] - PASO 2: DIRECCIÓN OPTIMIZADO CON GEOCODING Y GOOGLE MAPS
// 📁 Ubicación: /lib/widgets/clients/wizard/steps/address_info_step.dart
// 🎯 OBJETIVO: Layout compacto + validación con Google Maps + almacenamiento de coordenadas

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geocoding/geocoding.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/controllers/client_form_controller.dart';
import 'package:agenda_fisio_spa_kym/models/clients/client_form_model.dart';

/// 🏠 PASO 2: INFORMACIÓN DE DIRECCIÓN PARA WIZARD - OPTIMIZADO
/// Layout compacto + geocoding + coordenadas para servicios a domicilio
class AddressInfoStep extends StatefulWidget {
  final ClientFormController formController;

  const AddressInfoStep({
    super.key,
    required this.formController,
  });

  @override
  State<AddressInfoStep> createState() => _AddressInfoStepState();
}

class _AddressInfoStepState extends State<AddressInfoStep>
    with AutomaticKeepAliveClientMixin {
  // ✅ CONTROLADORES DE TEXTO
  late final TextEditingController _calleController;
  late final TextEditingController _numeroExteriorController;
  late final TextEditingController _numeroInteriorController;
  late final TextEditingController _coloniaController;
  late final TextEditingController _codigoPostalController;

  // ✅ FOCUS NODES PARA NAVEGACIÓN
  final FocusNode _focusCalle = FocusNode();
  final FocusNode _focusNumExt = FocusNode();
  final FocusNode _focusNumInt = FocusNode();
  final FocusNode _focusColonia = FocusNode();
  final FocusNode _focusCP = FocusNode();

  // ✅ ALCALDÍA Y COORDENADAS
  String? _alcaldiaSeleccionada;
  double? _latitude;
  double? _longitude;
  bool _isGeocoding = false;
  bool _isLocationVerified = false;
  String? _geocodedFullAddress;

  // ✅ ALCALDÍAS DE CDMX
  static const List<String> _alcaldiasCDMX = [
    'Álvaro Obregón',
    'Azcapotzalco',
    'Benito Juárez',
    'Coyoacán',
    'Cuajimalpa de Morelos',
    'Cuauhtémoc',
    'Gustavo A. Madero',
    'Iztacalco',
    'Iztapalapa',
    'La Magdalena Contreras',
    'Miguel Hidalgo',
    'Milpa Alta',
    'Tláhuac',
    'Tlalpan',
    'Venustiano Carranza',
    'Xochimilco',
  ];

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _initializeControllers();
    _setupListeners();
  }

  void _initializeControllers() {
    final addressInfo = widget.formController.formData.addressInfo;

    _calleController = TextEditingController(text: addressInfo.calle);
    _numeroExteriorController =
        TextEditingController(text: addressInfo.numeroExterior);
    _numeroInteriorController =
        TextEditingController(text: addressInfo.numeroInterior ?? '');
    _coloniaController = TextEditingController(text: addressInfo.colonia);
    _codigoPostalController =
        TextEditingController(text: addressInfo.codigoPostal);
    _alcaldiaSeleccionada =
        addressInfo.alcaldia.isNotEmpty ? addressInfo.alcaldia : null;
  }

  void _setupListeners() {
    // Listeners que resetean la verificación al cambiar la dirección
    _calleController.addListener(() {
      widget.formController.updateCalle(_calleController.text);
      _resetLocationVerification();
    });

    _numeroExteriorController.addListener(() {
      widget.formController
          .updateNumeroExterior(_numeroExteriorController.text);
      _resetLocationVerification();
    });

    _numeroInteriorController.addListener(() {
      widget.formController
          .updateNumeroInterior(_numeroInteriorController.text);
    });

    _coloniaController.addListener(() {
      widget.formController.updateColonia(_coloniaController.text);
      _resetLocationVerification();
    });

    _codigoPostalController.addListener(() {
      widget.formController.updateCodigoPostal(_codigoPostalController.text);
      _resetLocationVerification();
    });
  }

  void _resetLocationVerification() {
    if (_isLocationVerified) {
      setState(() {
        _isLocationVerified = false;
        _latitude = null;
        _longitude = null;
        _geocodedFullAddress = null;
      });
    }
  }

  @override
  void dispose() {
    _calleController.dispose();
    _numeroExteriorController.dispose();
    _numeroInteriorController.dispose();
    _coloniaController.dispose();
    _codigoPostalController.dispose();

    _focusCalle.dispose();
    _focusNumExt.dispose();
    _focusNumInt.dispose();
    _focusColonia.dispose();
    _focusCP.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    return ValueListenableBuilder<AddressFormInfo>(
      valueListenable: widget.formController.addressInfoNotifier,
      builder: (context, addressInfo, child) {
        return ValueListenableBuilder(
          valueListenable: widget.formController.validationNotifier,
          builder: (context, validation, child) {
            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildStepIntro(),
                  const SizedBox(height: 24),
                  _buildCompactFormFields(addressInfo, validation),
                  const SizedBox(height: 24),
                  _buildLocationVerificationCard(addressInfo),
                  if (_isLocationVerified) ...[
                    const SizedBox(height: 16),
                    _buildVerifiedLocationCard(),
                  ],
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildStepIntro() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            kAccentBlue.withValues(alpha: 0.08),
            kAccentBlue.withValues(alpha: 0.03),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: kAccentBlue.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  kAccentBlue.withValues(alpha: 0.2),
                  kAccentBlue.withValues(alpha: 0.1),
                ],
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: kAccentBlue.withValues(alpha: 0.3),
                width: 1.5,
              ),
            ),
            child: const Icon(
              Icons.location_on_outlined,
              color: kAccentBlue,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Dirección en CDMX',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: kAccentBlue,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Verifica la ubicación para servicios a domicilio',
                  style: TextStyle(
                    fontSize: 14,
                    color: kTextSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCompactFormFields(
      AddressFormInfo addressInfo, ClientFormValidation validation) {
    return Column(
      children: [
        // ✅ ROW COMPACTO: Calle + Colonia (reduce scroll)
        Row(
          children: [
            Expanded(
              flex: 3,
              child: _buildWizardInputField(
                controller: _calleController,
                label: 'Calle',
                hintText: 'Av. Insurgentes Sur',
                isRequired: true,
                errorText: validation.getFieldError('calle'),
                focusNode: _focusCalle,
                nextFocusNode: _focusColonia,
                prefixIcon: Icons.add_road,
                keyboardType: TextInputType.streetAddress,
                inputFormatters: [
                  LengthLimitingTextInputFormatter(80),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              flex: 2,
              child: _buildWizardInputField(
                controller: _coloniaController,
                label: 'Colonia',
                hintText: 'Del Valle',
                isRequired: true,
                errorText: validation.getFieldError('colonia'),
                focusNode: _focusColonia,
                nextFocusNode: _focusNumExt,
                prefixIcon: Icons.location_city_outlined,
                keyboardType: TextInputType.text,
                inputFormatters: [
                  LengthLimitingTextInputFormatter(40),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),

        // Row para Números Exterior e Interior
        Row(
          children: [
            Expanded(
              flex: 2,
              child: _buildWizardInputField(
                controller: _numeroExteriorController,
                label: 'Núm. Exterior',
                hintText: '457',
                isRequired: true,
                errorText: validation.getFieldError('numeroExterior'),
                focusNode: _focusNumExt,
                nextFocusNode: _focusNumInt,
                prefixIcon: Icons.home_outlined,
                keyboardType: TextInputType.text,
                inputFormatters: [
                  LengthLimitingTextInputFormatter(10),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              flex: 2,
              child: _buildWizardInputField(
                controller: _numeroInteriorController,
                label: 'Núm. Interior',
                hintText: 'A, 101 (opcional)',
                isRequired: false,
                focusNode: _focusNumInt,
                nextFocusNode: _focusCP,
                prefixIcon: Icons.door_back_door_outlined,
                keyboardType: TextInputType.text,
                inputFormatters: [
                  LengthLimitingTextInputFormatter(10),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              flex: 2,
              child: _buildWizardInputField(
                controller: _codigoPostalController,
                label: 'Código Postal',
                hintText: '03610',
                isRequired: true,
                errorText: validation.getFieldError('codigoPostal'),
                focusNode: _focusCP,
                prefixIcon: Icons.markunread_mailbox_outlined,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(5),
                ],
                suffixWidget: _buildCPValidationIndicator(validation),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),

        // Dropdown Alcaldía
        _buildAlcaldiaDropdown(validation),
      ],
    );
  }

  Widget _buildLocationVerificationCard(AddressFormInfo addressInfo) {
    final canVerify = addressInfo.calle.isNotEmpty &&
        addressInfo.numeroExterior.isNotEmpty &&
        addressInfo.colonia.isNotEmpty &&
        addressInfo.codigoPostal.isNotEmpty &&
        addressInfo.alcaldia.isNotEmpty;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            kAccentGreen.withValues(alpha: 0.05),
            kAccentGreen.withValues(alpha: 0.02),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: kAccentGreen.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.map_outlined,
                color: kAccentGreen,
                size: 20,
              ),
              const SizedBox(width: 8),
              const Text(
                'Verificación de Ubicación',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: kAccentGreen,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            canVerify
                ? 'Verifica la dirección con Google Maps para servicios a domicilio'
                : 'Complete todos los campos para verificar la ubicación',
            style: TextStyle(
              fontSize: 14,
              color: kTextSecondary,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: canVerify && !_isGeocoding
                      ? _verifyAddressWithGoogleMaps
                      : null,
                  icon: _isGeocoding
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor:
                                AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        )
                      : const Icon(Icons.location_searching),
                  label: Text(_isGeocoding
                      ? 'Verificando...'
                      : 'Verificar con Google Maps'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kAccentGreen,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ),
              if (_isLocationVerified) ...[
                const SizedBox(width: 12),
                ElevatedButton.icon(
                  onPressed: _openInGoogleMaps,
                  icon: const Icon(Icons.open_in_new),
                  label: const Text('Abrir Maps'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kAccentBlue,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildVerifiedLocationCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.green.withValues(alpha: 0.08),
            Colors.green.withValues(alpha: 0.03),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.green.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.green.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.check_circle,
                  color: Colors.green,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '✓ Ubicación Verificada',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Lista para servicios a domicilio',
                      style: TextStyle(
                        fontSize: 12,
                        color: kTextSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.8),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: Colors.green.withValues(alpha: 0.2),
                width: 1,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(
                      Icons.location_on,
                      color: Colors.green,
                      size: 18,
                    ),
                    SizedBox(width: 8),
                    Text(
                      'Dirección Confirmada:',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: kTextSecondary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  _geocodedFullAddress ?? 'Dirección verificada',
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.black87,
                    height: 1.4,
                  ),
                ),
                if (_latitude != null && _longitude != null) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: kAccentBlue.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: kAccentBlue.withValues(alpha: 0.2),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.gps_fixed,
                          color: kAccentBlue,
                          size: 16,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Coordenadas: ${_latitude!.toStringAsFixed(6)}, ${_longitude!.toStringAsFixed(6)}',
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: kAccentBlue,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWizardInputField({
    required TextEditingController controller,
    required String label,
    required String hintText,
    bool isRequired = false,
    String? errorText,
    FocusNode? focusNode,
    FocusNode? nextFocusNode,
    IconData? prefixIcon,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    Widget? suffixWidget,
  }) {
    final hasError = errorText != null;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Label
        Row(
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: hasError ? Colors.red.shade700 : kTextSecondary,
              ),
            ),
            if (isRequired) ...[
              const SizedBox(width: 4),
              Text(
                '*',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.red.shade600,
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: 8),

        // Input Field
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.white.withValues(alpha: 0.9),
                Colors.white.withValues(alpha: 0.7),
              ],
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: hasError ? Colors.red.withValues(alpha: 0.4) : kBorderSoft,
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: TextFormField(
            controller: controller,
            focusNode: focusNode,
            keyboardType: keyboardType,
            inputFormatters: inputFormatters,
            decoration: InputDecoration(
              hintText: hintText,
              hintStyle: TextStyle(
                color: kTextMuted,
                fontSize: 14,
              ),
              prefixIcon: prefixIcon != null
                  ? Icon(prefixIcon, color: kTextMuted, size: 20)
                  : null,
              suffixIcon: suffixWidget,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 16,
              ),
            ),
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Colors.black87,
            ),
            onFieldSubmitted: (_) {
              if (nextFocusNode != null) {
                FocusScope.of(context).requestFocus(nextFocusNode);
              }
            },
          ),
        ),

        // Error Message
        if (hasError) ...[
          const SizedBox(height: 6),
          Row(
            children: [
              Icon(
                Icons.error_outline,
                size: 16,
                color: Colors.red.shade600,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  errorText,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.red.shade600,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildAlcaldiaDropdown(ClientFormValidation validation) {
    final hasError = validation.hasFieldError('alcaldia');
    final borderColor =
        hasError ? Colors.red.withValues(alpha: 0.4) : kBorderSoft;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Label
        Row(
          children: [
            Text(
              'Alcaldía',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: hasError ? Colors.red.shade700 : kTextSecondary,
              ),
            ),
            const SizedBox(width: 4),
            Text(
              '*',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.red.shade600,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),

        // Dropdown con estilo glassmorphism
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.white.withValues(alpha: 0.9),
                Colors.white.withValues(alpha: 0.7),
              ],
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: borderColor,
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: DropdownButtonFormField<String>(
            value: _alcaldiaSeleccionada,
            hint: const Text('Seleccione una alcaldía'),
            icon: Icon(Icons.keyboard_arrow_down, color: kTextMuted),
            decoration: InputDecoration(
              prefixIcon: Icon(
                Icons.account_balance_outlined,
                color: kTextMuted,
                size: 20,
              ),
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 16,
              ),
            ),
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Colors.black87,
            ),
            dropdownColor: Colors.white,
            items: _alcaldiasCDMX.map((alcaldia) {
              return DropdownMenuItem<String>(
                value: alcaldia,
                child: Text(
                  alcaldia,
                  style: const TextStyle(fontSize: 15),
                ),
              );
            }).toList(),
            onChanged: (String? value) {
              setState(() {
                _alcaldiaSeleccionada = value;
              });
              if (value != null) {
                widget.formController.updateAlcaldia(value);
                _resetLocationVerification();
              }
            },
          ),
        ),

        // Error de alcaldía
        if (hasError) ...[
          const SizedBox(height: 6),
          Row(
            children: [
              Icon(
                Icons.error_outline,
                size: 16,
                color: Colors.red.shade600,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  validation.getFieldError('alcaldia')!,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.red.shade600,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildCPValidationIndicator(ClientFormValidation validation) {
    final hasCPError = validation.hasFieldError('codigoPostal');
    final cpText =
        _codigoPostalController.text.replaceAll(RegExp(r'[^\d]'), '');

    if (hasCPError) {
      return const Padding(
        padding: EdgeInsets.all(12),
        child: Icon(
          Icons.error_outline,
          color: Colors.red,
          size: 20,
        ),
      );
    }

    if (cpText.length == 5) {
      return const Padding(
        padding: EdgeInsets.all(12),
        child: Icon(
          Icons.check_circle_outline,
          color: Colors.green,
          size: 20,
        ),
      );
    }

    return const SizedBox.shrink();
  }

  // ========================================================================
  // 🗺️ MÉTODOS DE GEOCODING Y GOOGLE MAPS
  // ========================================================================

  Future<void> _verifyAddressWithGoogleMaps() async {
    setState(() {
      _isGeocoding = true;
    });

    try {
      // Construir dirección completa
      final fullAddress = _buildFullAddressForGeocoding();
      debugPrint('🔍 Verificando dirección: $fullAddress');

      // Geocoding con la librería geocoding
      final locations = await locationFromAddress(fullAddress);

      if (locations.isNotEmpty) {
        final location = locations.first;

        // Verificar que las coordenadas estén en CDMX (rough bounds)
        if (_isLocationInCDMX(location.latitude, location.longitude)) {
          // Reverse geocoding para obtener dirección formateada
          final placemarks = await placemarkFromCoordinates(
            location.latitude,
            location.longitude,
          );

          if (placemarks.isNotEmpty) {
            final placemark = placemarks.first;
            final formattedAddress = _formatPlacemarkAddress(placemark);

            setState(() {
              _latitude = location.latitude;
              _longitude = location.longitude;
              _geocodedFullAddress = formattedAddress;
              _isLocationVerified = true;
            });

            // Guardar coordenadas en el modelo para servicios a domicilio
            _saveLocationData(location.latitude, location.longitude);

            // Feedback háptico de éxito
            HapticFeedback.mediumImpact();

            _showSuccessMessage('✓ Ubicación verificada correctamente');
          } else {
            _showErrorMessage(
                'No se pudo obtener información detallada de la ubicación');
          }
        } else {
          _showErrorMessage(
              'La dirección no se encuentra en la Ciudad de México');
        }
      } else {
        _showErrorMessage('No se pudo encontrar la dirección especificada');
      }
    } catch (e) {
      debugPrint('❌ Error en geocoding: $e');
      _showErrorMessage('Error verificando la dirección: ${e.toString()}');
    } finally {
      setState(() {
        _isGeocoding = false;
      });
    }
  }

  Future<void> _openInGoogleMaps() async {
    if (_latitude != null && _longitude != null) {
      try {
        // Crear URL para Google Maps con coordenadas
        final String googleMapsUrl;

        // Detectar plataforma y usar el esquema apropiado
        if (Theme.of(context).platform == TargetPlatform.iOS) {
          // Para iOS, intentar abrir Google Maps app primero, luego Apple Maps
          googleMapsUrl =
              'comgooglemaps://?q=${_latitude},${_longitude}&center=${_latitude},${_longitude}&zoom=17';
          final fallbackUrl =
              'http://maps.apple.com/?q=${_latitude},${_longitude}';

          if (await canLaunchUrl(Uri.parse(googleMapsUrl))) {
            await launchUrl(Uri.parse(googleMapsUrl));
          } else {
            await launchUrl(Uri.parse(fallbackUrl),
                mode: LaunchMode.externalApplication);
          }
        } else {
          // Para Android, usar intent geo
          googleMapsUrl =
              'geo:${_latitude},${_longitude}?q=${_latitude},${_longitude}(Dirección del Cliente)';
          final fallbackUrl =
              'https://www.google.com/maps/search/?api=1&query=${_latitude},${_longitude}';

          if (await canLaunchUrl(Uri.parse(googleMapsUrl))) {
            await launchUrl(Uri.parse(googleMapsUrl));
          } else {
            await launchUrl(Uri.parse(fallbackUrl),
                mode: LaunchMode.externalApplication);
          }
        }

        HapticFeedback.lightImpact();
      } catch (e) {
        debugPrint('❌ Error abriendo Google Maps: $e');
        _showErrorMessage('No se pudo abrir Google Maps');
      }
    }
  }

  String _buildFullAddressForGeocoding() {
    final parts = <String>[];

    // Calle y número
    if (_calleController.text.isNotEmpty) {
      parts.add(_calleController.text.trim());
    }
    if (_numeroExteriorController.text.isNotEmpty) {
      parts.add(_numeroExteriorController.text.trim());
    }

    // Colonia
    if (_coloniaController.text.isNotEmpty) {
      parts.add(_coloniaController.text.trim());
    }

    // Alcaldía y código postal
    if (_alcaldiaSeleccionada != null) {
      parts.add(_alcaldiaSeleccionada!);
    }
    if (_codigoPostalController.text.isNotEmpty) {
      parts.add(_codigoPostalController.text.trim());
    }

    // Agregar "Ciudad de México, México" para mayor precisión
    parts.add('Ciudad de México');
    parts.add('México');

    return parts.join(', ');
  }

  String _formatPlacemarkAddress(Placemark placemark) {
    final parts = <String>[];

    if (placemark.street?.isNotEmpty == true) {
      parts.add(placemark.street!);
    }
    if (placemark.subLocality?.isNotEmpty == true) {
      parts.add(placemark.subLocality!);
    }
    if (placemark.locality?.isNotEmpty == true) {
      parts.add(placemark.locality!);
    }
    if (placemark.postalCode?.isNotEmpty == true) {
      parts.add('CP ${placemark.postalCode!}');
    }
    if (placemark.administrativeArea?.isNotEmpty == true) {
      parts.add(placemark.administrativeArea!);
    }

    return parts.join(', ');
  }

  bool _isLocationInCDMX(double latitude, double longitude) {
    // Bounds aproximados de la Ciudad de México
    // Norte: 19.59, Sur: 19.05, Este: -98.95, Oeste: -99.35
    return latitude >= 19.05 &&
        latitude <= 19.59 &&
        longitude >= -99.35 &&
        longitude <= -98.95;
  }

  void _saveLocationData(double latitude, double longitude) {
    // TODO: Aquí guardarías las coordenadas en tu modelo de datos
    // Esto será útil para la futura app de servicios a domicilio
    debugPrint('💾 Guardando coordenadas para servicios a domicilio:');
    debugPrint('   Latitud: $latitude');
    debugPrint('   Longitud: $longitude');
    debugPrint(
        '   Cliente: ${widget.formController.formData.personalInfo.fullName}');

    // Podrías agregar esto al modelo de cliente
    // widget.formController.updateLocationCoordinates(latitude, longitude);
  }

  void _showSuccessMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  void _showErrorMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.error, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 4),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }
}
