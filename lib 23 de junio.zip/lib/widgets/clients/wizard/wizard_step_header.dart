// [wizard_step_header.dart] - HEADER CON PROGRESO ANIMADO DEL WIZARD - OVERFLOW CORREGIDO
// 📁 Ubicación: /lib/widgets/clients/wizard/wizard_step_header.dart
// 🎯 OBJETIVO: Header fijo 80px con progreso, título y botón cerrar - SIN OVERFLOW

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/widgets/clients/wizard/wizard_controller.dart';

/// 📊 HEADER DEL WIZARD CON PROGRESO ANIMADO - SIN OVERFLOW
/// Altura fija: 80px | Progreso visual | Título dinámico | Botón cerrar
class WizardStepHeader extends StatefulWidget {
  const WizardStepHeader({super.key});

  @override
  State<WizardStepHeader> createState() => _WizardStepHeaderState();
}

class _WizardStepHeaderState extends State<WizardStepHeader>
    with SingleTickerProviderStateMixin {
  late AnimationController _progressController;
  late Animation<double> _progressAnimation;

  double _lastProgress = 0.0;

  @override
  void initState() {
    super.initState();

    _progressController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );

    _progressAnimation = CurvedAnimation(
      parent: _progressController,
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _progressController.dispose();
    super.dispose();
  }

  void _updateProgress(double newProgress) {
    if (newProgress != _lastProgress) {
      _progressAnimation = Tween<double>(
        begin: _lastProgress,
        end: newProgress,
      ).animate(CurvedAnimation(
        parent: _progressController,
        curve: Curves.easeInOut,
      ));

      _progressController.reset();
      _progressController.forward();
      _lastProgress = newProgress;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<WizardController>(
      builder: (context, wizard, child) {
        // Actualizar progreso cuando cambie
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            _updateProgress(wizard.progress);
          }
        });

        return Container(
          height: 80,
          decoration: _buildHeaderDecoration(),
          child: Padding(
            padding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 10), // ✅ PADDING MÁS REDUCIDO
            child: Row(
              // ✅ ROW ÚNICO PARA EVITAR OVERFLOW
              children: [
                _buildStepIndicator(wizard),
                const SizedBox(width: 10),
                Expanded(child: _buildTitleSection(wizard)),
                const SizedBox(width: 6),
                _buildProgressSection(wizard),
                const SizedBox(width: 6),
                _buildCloseButton(),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildStepIndicator(WizardController wizard) {
    return Container(
      width: 28, // ✅ TAMAÑO MÁS REDUCIDO
      height: 28, // ✅ TAMAÑO MÁS REDUCIDO
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            kBrandPurple.withValues(alpha: 0.2),
            kBrandPurple.withValues(alpha: 0.1),
          ],
        ),
        borderRadius: BorderRadius.circular(6), // ✅ RADIO MÁS REDUCIDO
        border: Border.all(
          color: kBrandPurple.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Center(
        child: Text(
          '${wizard.stepNumber}',
          style: const TextStyle(
            fontSize: 12, // ✅ FUENTE MÁS REDUCIDA
            fontWeight: FontWeight.bold,
            color: kBrandPurple,
          ),
        ),
      ),
    );
  }

  Widget _buildTitleSection(WizardController wizard) {
    return Padding(
      padding:
          const EdgeInsets.symmetric(vertical: 2), // ✅ PADDING VERTICAL MÍNIMO
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min, // ✅ TAMAÑO MÍNIMO PARA EVITAR OVERFLOW
        children: [
          Text(
            wizard.currentStepTitle,
            style: const TextStyle(
              fontSize: 15, // ✅ FUENTE MÁS REDUCIDA
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          Text(
            wizard.currentStepSubtitle,
            style: TextStyle(
              fontSize: 11, // ✅ FUENTE MÁS REDUCIDA
              color: kTextSecondary,
              fontWeight: FontWeight.w500,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  Widget _buildProgressSection(WizardController wizard) {
    return Row(
      // ✅ CAMBIO A ROW PARA EVITAR COLUMN OVERFLOW
      mainAxisSize: MainAxisSize.min,
      children: [
        // ✅ CONTADOR DE PASOS LEGIBLE
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(
            color: kBrandPurple.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: kBrandPurple.withValues(alpha: 0.3),
              width: 1,
            ),
          ),
          child: Text(
            '${wizard.stepNumber}/${WizardController.totalSteps}',
            style: const TextStyle(
              fontSize: 12, // ✅ FUENTE MÁS LEGIBLE
              fontWeight: FontWeight.w700,
              color: kBrandPurple,
              letterSpacing: 0.2,
            ),
          ),
        ),

        const SizedBox(width: 10),

        // ✅ BARRA DE PROGRESO VISIBLE
        Container(
          width: 50, // ✅ ANCHO VISIBLE
          height: 4, // ✅ ALTURA MÁS VISIBLE
          decoration: BoxDecoration(
            color: kBrandPurple.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(2),
          ),
          child: AnimatedBuilder(
            animation: _progressAnimation,
            builder: (context, child) {
              return FractionallySizedBox(
                alignment: Alignment.centerLeft,
                widthFactor: _progressAnimation.value,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [kBrandPurple, kAccentBlue],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              );
            },
          ),
        ),

        const SizedBox(width: 6),

        // ✅ PORCENTAJE LEGIBLE
        AnimatedBuilder(
          animation: _progressAnimation,
          builder: (context, child) {
            final percentage = (_progressAnimation.value * 100).round();
            return Text(
              '$percentage%',
              style: const TextStyle(
                fontSize: 11, // ✅ FUENTE MÁS LEGIBLE
                fontWeight: FontWeight.w700,
                color: kBrandPurple,
                letterSpacing: 0.1,
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildCloseButton() {
    return Container(
      width: 24, // ✅ TAMAÑO MÁS REDUCIDO
      height: 24, // ✅ TAMAÑO MÁS REDUCIDO
      decoration: BoxDecoration(
        color: Colors.grey.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(4), // ✅ RADIO MÁS REDUCIDO
        border: Border.all(
          color: Colors.grey.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => Navigator.of(context).pop(),
          borderRadius: BorderRadius.circular(4),
          child: Icon(
            Icons.close,
            color: kTextSecondary,
            size: 14, // ✅ ICONO MÁS REDUCIDO
          ),
        ),
      ),
    );
  }

  BoxDecoration _buildHeaderDecoration() {
    return BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white.withValues(alpha: 0.9),
          Colors.white.withValues(alpha: 0.7),
          kAccentBlue.withValues(alpha: 0.03),
        ],
      ),
      border: Border(
        bottom: BorderSide(
          color: kBorderSoft,
          width: 1,
        ),
      ),
    );
  }
}
