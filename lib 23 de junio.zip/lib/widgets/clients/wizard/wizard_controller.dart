// [wizard_controller.dart] - CONTROLADOR PRINCIPAL DEL WIZARD MODAL - VALIDACIÓN INTELIGENTE
// 📁 Ubicación: /lib/widgets/clients/wizard/wizard_controller.dart
// 🎯 OBJETIVO: Lógica de navegación, validación SOLO cuando el usuario intenta avanzar

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:agenda_fisio_spa_kym/controllers/client_form_controller.dart';
import 'package:agenda_fisio_spa_kym/models/clients/client_model.dart';
import 'package:agenda_fisio_spa_kym/models/clients/client_form_model.dart';
import 'package:agenda_fisio_spa_kym/services/clients/client_form_service.dart';

/// 🧠 CONTROLADOR PRINCIPAL DEL WIZARD MODAL - VALIDACIÓN INTELIGENTE
/// Maneja navegación, validación SOLO cuando necesario y estados de los 3 pasos
class WizardController extends ChangeNotifier {
  // ✅ CONFIGURACIÓN DEL WIZARD
  static const int totalSteps = 3;
  static const List<String> stepTitles = [
    'Información Personal',
    'Dirección en CDMX',
    'Etiquetas y Confirmación',
  ];
  static const List<String> stepSubtitles = [
    'Datos básicos de identificación',
    'Dirección completa del cliente',
    'Categorización y resumen final',
  ];

  // ✅ ESTADO INTERNO
  int _currentStep = 0;
  late ClientFormController _formController;
  bool _isInitialized = false;
  bool _isNavigating = false;
  ClientModel? _existingClient;

  // ✅ VALIDACIÓN INTELIGENTE - SOLO MOSTRAR ERRORES CUANDO EL USUARIO INTENTA AVANZAR
  bool _hasUserTriedToAdvance =
      false; // ✅ CLAVE: Solo mostrar errores después del primer intento
  final List<bool> _stepValidationStatus = [false, false, false];
  final Map<int, List<String>> _stepErrors = {};
  final Set<int> _stepsAttemptedToValidate =
      {}; // ✅ Pasos que el usuario intentó validar

  // ✅ CONSTRUCTOR
  WizardController({ClientModel? existingClient}) {
    _existingClient = existingClient;
    _initializeFormController();
  }

  // ========================================================================
  // 🎯 GETTERS PÚBLICOS
  // ========================================================================

  /// Estado actual del wizard
  int get currentStep => _currentStep;
  bool get isInitialized => _isInitialized;
  bool get isNavigating => _isNavigating;

  /// Información del paso actual
  String get currentStepTitle => stepTitles[_currentStep];
  String get currentStepSubtitle => stepSubtitles[_currentStep];
  double get progress => (_currentStep + 1) / totalSteps;
  int get stepNumber => _currentStep + 1;

  /// Estados de navegación
  bool get isFirstStep => _currentStep == 0;
  bool get isLastStep => _currentStep == totalSteps - 1;
  bool get canGoNext =>
      !_isNavigating &&
      !isLastStep; // ✅ SIMPLIFICADO: Solo verificar si no está navegando
  bool get canGoPrevious => _currentStep > 0 && !_isNavigating;
  bool get canFinish =>
      isLastStep &&
      !_isNavigating; // ✅ SIMPLIFICADO: Solo verificar si está en último paso

  /// ✅ VALIDACIÓN INTELIGENTE: Solo mostrar errores si el usuario YA INTENTÓ avanzar
  bool get currentStepValid =>
      !_shouldShowErrors || (_stepErrors[_currentStep]?.isEmpty ?? true);
  bool get _shouldShowErrors =>
      _hasUserTriedToAdvance &&
      _stepsAttemptedToValidate.contains(_currentStep);

  List<String> get currentStepErrors =>
      _shouldShowErrors ? (_stepErrors[_currentStep] ?? []) : [];
  bool get hasStepErrors => currentStepErrors.isNotEmpty;

  /// Datos del formulario
  ClientFormController get formController => _formController;
  ClientFormModel get formData => _formController.formData;
  bool get isEditMode => _existingClient != null;

  // ========================================================================
  // 🚀 MÉTODOS DE INICIALIZACIÓN
  // ========================================================================

  /// Inicializar controlador del formulario
  void _initializeFormController() {
    final formService = ClientFormService();
    _formController = ClientFormController(formService: formService);

    // ✅ REMOVER LISTENER AUTOMÁTICO - Solo actualizar en memoria, no validar
    _formController.addListener(_onFormDataChangedSilently);

    // Cargar datos existentes si es edición
    if (_existingClient != null) {
      _formController.loadExistingClient(_existingClient!);
    } else {
      _formController.initializeNewClient();
    }

    _isInitialized = true;
    notifyListeners();

    debugPrint(
        '🧠 WizardController inicializado ${isEditMode ? "(modo edición)" : "(nuevo cliente)"}');
  }

  /// ✅ LISTENER SILENCIOSO - Solo actualiza datos, NO valida automáticamente
  void _onFormDataChangedSilently() {
    // ✅ SOLO notificar cambios para actualizar UI, NO validar automáticamente
    notifyListeners();

    // ✅ SOLO revalidar silenciosamente si el usuario YA intentó validar este paso antes
    if (_stepsAttemptedToValidate.contains(_currentStep) &&
        _hasUserTriedToAdvance) {
      _validateCurrentStepSilently();
    }
  }

  /// ✅ VALIDACIÓN SILENCIOSA - No muestra errores, solo actualiza estado interno
  Future<void> _validateCurrentStepSilently() async {
    final wasValid = await _performStepValidation(_currentStep);
    _stepValidationStatus[_currentStep] = wasValid;

    // Solo limpiar errores si ahora es válido
    if (wasValid) {
      _stepErrors.remove(_currentStep);
      notifyListeners(); // Actualizar UI para quitar errores
    }
  }

  // ========================================================================
  // 🎮 MÉTODOS DE NAVEGACIÓN
  // ========================================================================

  /// ✅ IR AL SIGUIENTE PASO - AQUÍ ES DONDE SE VALIDA
  Future<void> nextStep() async {
    if (!canGoNext || _isNavigating) return;

    debugPrint(
        '🎮 Usuario intenta avanzar al paso ${_currentStep + 1} → ${_currentStep + 2}');

    // ✅ MARCAR QUE EL USUARIO INTENTÓ AVANZAR
    _hasUserTriedToAdvance = true;
    _stepsAttemptedToValidate.add(_currentStep);

    _isNavigating = true;
    notifyListeners();

    try {
      // ✅ VALIDAR PASO ACTUAL ANTES DE AVANZAR
      final isValid = await _validateCurrentStep();

      if (!isValid) {
        debugPrint('❌ Validación falló. Mostrando errores al usuario.');
        notifyListeners(); // ✅ ESTO HARÁ QUE SE MUESTREN LOS ERRORES
        return;
      }

      // ✅ VALIDACIÓN EXITOSA - AVANZAR
      HapticFeedback.lightImpact();
      _currentStep++;

      debugPrint(
          '✅ Navegación completada. Paso actual: $stepNumber/$totalSteps');
    } catch (e) {
      debugPrint('❌ Error en navegación: $e');
      _addStepError(_currentStep, 'Error de navegación: $e');
      notifyListeners();
    } finally {
      _isNavigating = false;
      notifyListeners();
    }
  }

  /// Ir al paso anterior
  Future<void> previousStep() async {
    if (!canGoPrevious || _isNavigating) return;

    debugPrint('🎮 Navegando al paso ${_currentStep + 1} → $_currentStep');

    _isNavigating = true;
    notifyListeners();

    try {
      // Feedback háptico
      HapticFeedback.lightImpact();

      // Retroceder paso
      _currentStep--;

      // ✅ NO limpiar errores - mantener estado de validación
      debugPrint(
          '✅ Navegación hacia atrás completada. Paso actual: $stepNumber/$totalSteps');
    } finally {
      _isNavigating = false;
      notifyListeners();
    }
  }

  /// Ir directamente a un paso específico
  Future<void> goToStep(int stepIndex) async {
    if (stepIndex < 0 || stepIndex >= totalSteps || stepIndex == _currentStep)
      return;

    debugPrint('🎮 Navegación directa al paso ${stepIndex + 1}');

    _isNavigating = true;
    notifyListeners();

    try {
      _currentStep = stepIndex;
      HapticFeedback.lightImpact();
    } finally {
      _isNavigating = false;
      notifyListeners();
    }
  }

  // ========================================================================
  // ✅ MÉTODOS DE VALIDACIÓN
  // ========================================================================

  /// ✅ VALIDAR EL PASO ACTUAL - Solo cuando el usuario intenta avanzar
  Future<bool> _validateCurrentStep() async {
    debugPrint(
        '🔍 Validando paso ${_currentStep + 1} (usuario intentó avanzar)...');

    _clearStepErrors(_currentStep);

    try {
      final isValid = await _performStepValidation(_currentStep);
      _stepValidationStatus[_currentStep] = isValid;

      debugPrint(
          '📊 Validación paso ${_currentStep + 1}: ${isValid ? "✅ VÁLIDO" : "❌ INVÁLIDO"}');

      return isValid;
    } catch (e) {
      debugPrint('❌ Error validando paso ${_currentStep + 1}: $e');
      _addStepError(_currentStep, 'Error de validación: $e');
      _stepValidationStatus[_currentStep] = false;
      return false;
    }
  }

  /// ✅ REALIZAR VALIDACIÓN REAL DEL PASO
  Future<bool> _performStepValidation(int stepIndex) async {
    switch (stepIndex) {
      case 0: // Paso 1: Información Personal
        return await _validatePersonalInfoStep();
      case 1: // Paso 2: Dirección
        return await _validateAddressInfoStep();
      case 2: // Paso 3: Etiquetas y Confirmación
        return await _validateTagsAndSummaryStep();
      default:
        return false;
    }
  }

  /// Validar paso 1: Información Personal
  Future<bool> _validatePersonalInfoStep() async {
    final personalInfo = _formController.formData.personalInfo;
    final errors = <String>[];

    // Validar nombre
    if (personalInfo.nombre.trim().isEmpty) {
      errors.add('Nombre es requerido');
    }

    // Validar apellidos
    if (personalInfo.apellidos.trim().isEmpty) {
      errors.add('Apellidos son requeridos');
    }

    // Validar email
    if (personalInfo.email.trim().isEmpty) {
      errors.add('Email es requerido');
    } else if (!_isValidEmail(personalInfo.email)) {
      errors.add('Email no tiene formato válido');
    } else if (!isEditMode) {
      // ✅ Solo validar email único para clientes nuevos
      try {
        final formService = ClientFormService();
        final isUnique = await formService.isEmailUnique(personalInfo.email);
        if (!isUnique) {
          errors.add('Este email ya está registrado');
        }
      } catch (e) {
        debugPrint('⚠️ No se pudo validar email único: $e');
        // Continuar sin error si no se puede validar
      }
    }

    // Validar teléfono
    if (personalInfo.telefono.trim().isEmpty) {
      errors.add('Teléfono es requerido');
    } else if (!_isValidPhoneMX(personalInfo.telefono)) {
      errors.add('Teléfono debe tener 10 dígitos');
    }

    // Registrar errores
    if (errors.isNotEmpty) {
      _stepErrors[_currentStep] = errors;
    }

    return errors.isEmpty;
  }

  /// Validar paso 2: Dirección
  Future<bool> _validateAddressInfoStep() async {
    final addressInfo = _formController.formData.addressInfo;
    final errors = <String>[];

    // Validar calle
    if (addressInfo.calle.trim().isEmpty) {
      errors.add('Calle es requerida');
    }

    // Validar número exterior
    if (addressInfo.numeroExterior.trim().isEmpty) {
      errors.add('Número exterior es requerido');
    }

    // Validar colonia
    if (addressInfo.colonia.trim().isEmpty) {
      errors.add('Colonia es requerida');
    }

    // Validar código postal
    if (addressInfo.codigoPostal.trim().isEmpty) {
      errors.add('Código postal es requerido');
    } else if (!_isValidCP(addressInfo.codigoPostal)) {
      errors.add('Código postal debe tener 5 dígitos');
    }

    // Validar alcaldía
    if (addressInfo.alcaldia.trim().isEmpty) {
      errors.add('Alcaldía es requerida');
    }

    // Registrar errores
    if (errors.isNotEmpty) {
      _stepErrors[_currentStep] = errors;
    }

    return errors.isEmpty;
  }

  /// Validar paso 3: Etiquetas y Confirmación
  Future<bool> _validateTagsAndSummaryStep() async {
    // En este paso validamos que todos los pasos anteriores estén correctos
    final errors = <String>[];

    // ✅ VALIDAR PASOS ANTERIORES
    for (int i = 0; i < 2; i++) {
      // Solo pasos 0 y 1
      final isValid = await _performStepValidation(i);
      if (!isValid) {
        errors.add('Información incompleta en paso ${i + 1}');
      }
    }

    // Validar que al menos tengamos nombre completo
    final personalInfo = _formController.formData.personalInfo;
    if (personalInfo.fullName.trim().length < 3) {
      errors.add('Nombre completo muy corto');
    }

    // Registrar errores
    if (errors.isNotEmpty) {
      _stepErrors[_currentStep] = errors;
    }

    return errors.isEmpty;
  }

  // ========================================================================
  // 🎯 MÉTODOS DE FINALIZACIÓN
  // ========================================================================

  /// ✅ FINALIZAR WIZARD Y GUARDAR CLIENTE
  Future<bool> finishWizard() async {
    debugPrint('🎯 Finalizando wizard y guardando cliente...');

    // ✅ MARCAR QUE EL USUARIO INTENTÓ FINALIZAR
    _hasUserTriedToAdvance = true;
    for (int i = 0; i < totalSteps; i++) {
      _stepsAttemptedToValidate.add(i);
    }

    try {
      // ✅ VALIDAR TODOS LOS PASOS
      bool allValid = true;
      for (int i = 0; i < totalSteps; i++) {
        final isValid = await _performStepValidation(i);
        _stepValidationStatus[i] = isValid;

        if (!isValid) {
          allValid = false;
          debugPrint('❌ Paso ${i + 1} no válido durante validación final');
        }
      }

      if (!allValid) {
        // ✅ IR AL PRIMER PASO CON ERRORES
        for (int i = 0; i < totalSteps; i++) {
          if ((_stepErrors[i]?.isNotEmpty ?? false)) {
            _currentStep = i;
            break;
          }
        }
        notifyListeners();
        return false;
      }

      // ✅ GUARDAR CLIENTE
      final success = await _formController.saveClient();

      if (success == true) {
        debugPrint('✅ Cliente guardado exitosamente');
        HapticFeedback.mediumImpact();
        return true;
      } else {
        debugPrint('❌ Error guardando cliente');
        return false;
      }
    } catch (e) {
      debugPrint('❌ Error finalizando wizard: $e');
      _addStepError(_currentStep, 'Error guardando: $e');
      return false;
    }
  }

  // ========================================================================
  // 🔧 MÉTODOS HELPER PRIVADOS
  // ========================================================================

  /// Agregar error a un paso específico
  void _addStepError(int stepIndex, String error) {
    if (!_stepErrors.containsKey(stepIndex)) {
      _stepErrors[stepIndex] = <String>[];
    }
    _stepErrors[stepIndex]!.add(error);
    _stepValidationStatus[stepIndex] = false;
  }

  /// Limpiar errores de un paso
  void _clearStepErrors(int stepIndex) {
    _stepErrors.remove(stepIndex);
  }

  /// Validar formato de email
  bool _isValidEmail(String email) {
    return RegExp(r'^[^@]+@[^@]+\.[^@]+$').hasMatch(email.trim());
  }

  /// Validar teléfono mexicano
  bool _isValidPhoneMX(String phone) {
    final cleaned = phone.replaceAll(RegExp(r'[^\d]'), '');
    return cleaned.length == 10;
  }

  /// Validar código postal
  bool _isValidCP(String cp) {
    final cleaned = cp.replaceAll(RegExp(r'[^\d]'), '');
    return cleaned.length == 5;
  }

  // ========================================================================
  // 🧹 CLEANUP
  // ========================================================================

  @override
  void dispose() {
    _formController.removeListener(_onFormDataChangedSilently);
    _formController.dispose();
    super.dispose();
    debugPrint('🧹 WizardController disposed');
  }

  // ========================================================================
  // 📊 MÉTODOS DE DEBUG Y ANALYTICS
  // ========================================================================

  /// Log del estado actual para debugging
  void logCurrentState() {
    debugPrint('📊 WizardController State:');
    debugPrint('   currentStep: ${_currentStep + 1}/$totalSteps');
    debugPrint('   hasUserTriedToAdvance: $_hasUserTriedToAdvance');
    debugPrint('   stepsAttemptedToValidate: $_stepsAttemptedToValidate');
    debugPrint('   shouldShowErrors: $_shouldShowErrors');
    debugPrint('   currentStepErrors: ${currentStepErrors.length}');
    debugPrint('   canGoNext: $canGoNext');
    debugPrint('   canFinish: $canFinish');
  }
}
