// [client_wizard_modal.dart] - MODAL PRINCIPAL DEL WIZARD ENTERPRISE - ALTURA CORREGIDA
// 📁 Ubicación: /lib/widgets/clients/wizard/client_wizard_modal.dart
// 🎯 OBJETIVO: Modal base 800px con glassmorphism y arquitectura modular - 30% MÁS ALTO

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/models/clients/client_model.dart';
import 'package:agenda_fisio_spa_kym/widgets/clients/wizard/wizard_controller.dart';
import 'package:agenda_fisio_spa_kym/widgets/clients/wizard/wizard_step_header.dart';
import 'package:agenda_fisio_spa_kym/widgets/clients/wizard/wizard_step_content.dart';
import 'package:agenda_fisio_spa_kym/widgets/clients/wizard/wizard_navigation_footer.dart';

/// 🏢 MODAL WIZARD ENTERPRISE PARA CREAR/EDITAR CLIENTES
/// Modal centrado 800px con 3 pasos: Personal → Dirección → Tags+Confirmación
class ClientWizardModal extends StatefulWidget {
  final ClientModel? existingClient;
  final VoidCallback? onClientSaved;
  final VoidCallback? onCancelled;

  const ClientWizardModal({
    super.key,
    this.existingClient,
    this.onClientSaved,
    this.onCancelled,
  });

  @override
  State<ClientWizardModal> createState() => _ClientWizardModalState();
}

class _ClientWizardModalState extends State<ClientWizardModal>
    with TickerProviderStateMixin {
  // ✅ CONTROLADORES DE ANIMACIÓN
  late AnimationController _overlayController;
  late AnimationController _modalController;
  late AnimationController _contentController;

  late Animation<double> _overlayAnimation;
  late Animation<double> _modalScaleAnimation;
  late Animation<Offset> _modalSlideAnimation;
  late Animation<double> _contentFadeAnimation;

  // ✅ CONTROLADOR DEL WIZARD
  late WizardController _wizardController;
  bool _isInitialized = false;
  bool _isClosing = false;

  // ✅ CONFIGURACIÓN DEL MODAL - 30% MÁS ALTO
  static const double modalWidth = 800.0;
  static const double modalHeight = 780.0; // 🔧 CAMBIADO: 600 → 780 (+30%)
  static const double borderRadius = 20.0;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeWizardController();
    _startEntryAnimations();
  }

  void _initializeAnimations() {
    // Overlay fade in/out
    _overlayController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _overlayAnimation = CurvedAnimation(
      parent: _overlayController,
      curve: Curves.easeOut,
    );

    // Modal scale + slide
    _modalController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _modalScaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _modalController,
      curve: Curves.easeOutCubic,
    ));
    _modalSlideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _modalController,
      curve: Curves.easeOutCubic,
    ));

    // Content fade in
    _contentController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _contentFadeAnimation = CurvedAnimation(
      parent: _contentController,
      curve: Curves.easeOut,
    );
  }

  void _initializeWizardController() {
    _wizardController = WizardController(existingClient: widget.existingClient);

    // Esperar a que el controller esté listo
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && _wizardController.isInitialized) {
        setState(() {
          _isInitialized = true;
        });
        _contentController.forward();
      }
    });
  }

  void _startEntryAnimations() {
    _overlayController.forward();

    Future.delayed(const Duration(milliseconds: 50), () {
      if (mounted) {
        _modalController.forward();
      }
    });
  }

  Future<void> _startExitAnimations() async {
    if (_isClosing) return;
    _isClosing = true;

    await Future.wait([
      _contentController.reverse(),
      _modalController.reverse(),
    ]);

    await _overlayController.reverse();
  }

  @override
  void dispose() {
    _overlayController.dispose();
    _modalController.dispose();
    _contentController.dispose();
    _wizardController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: _wizardController,
      child: PopScope(
        canPop: false,
        onPopInvoked: (didPop) {
          if (!didPop) {
            _handleBackPress();
          }
        },
        child: _buildModalScaffold(),
      ),
    );
  }

  Widget _buildModalScaffold() {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: AnimatedBuilder(
        animation: _overlayAnimation,
        builder: (context, child) {
          return Container(
            color:
                Colors.black.withValues(alpha: 0.7 * _overlayAnimation.value),
            child: Center(
              child: _buildResponsiveModal(),
            ),
          );
        },
      ),
    );
  }

  Widget _buildResponsiveModal() {
    return LayoutBuilder(
      builder: (context, constraints) {
        // Responsive: 90% en móvil, tamaño fijo en desktop
        final screenWidth = constraints.maxWidth;
        final screenHeight = constraints.maxHeight;

        final effectiveWidth =
            screenWidth > 900 ? modalWidth : screenWidth * 0.9;

        // 🔧 AJUSTE RESPONSIVO: Usar nueva altura o 85% de pantalla
        final effectiveHeight = screenHeight > 900
            ? modalHeight // 🔧 NUEVA ALTURA: 780px
            : screenHeight * 0.85;

        return AnimatedBuilder(
          animation: _modalController,
          builder: (context, child) {
            return Transform.scale(
              scale: _modalScaleAnimation.value,
              child: Transform.translate(
                offset: _modalSlideAnimation.value * 50,
                child: Container(
                  width: effectiveWidth,
                  height: effectiveHeight,
                  child: _buildModalContent(),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildModalContent() {
    if (!_isInitialized) {
      return _buildLoadingModal();
    }

    return Container(
      decoration: _buildGlassmorphismDecoration(),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: Column(
          children: [
            // Header: 80px con progreso
            const SizedBox(
              height: 80,
              child: WizardStepHeader(),
            ),

            // Content: Expandido (~620px ahora vs ~440px antes)
            Expanded(
              child: AnimatedBuilder(
                animation: _contentFadeAnimation,
                builder: (context, child) {
                  return Opacity(
                    opacity: _contentFadeAnimation.value,
                    child: const WizardStepContent(),
                  );
                },
              ),
            ),

            // Footer: 80px con navegación
            SizedBox(
              height: 80,
              child: WizardNavigationFooter(
                onCancel: _handleCancel,
                onPrevious: _handlePrevious,
                onNext: _handleNext,
                onFinish: _handleFinish,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingModal() {
    return Container(
      decoration: _buildGlassmorphismDecoration(),
      child: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(kBrandPurple),
              strokeWidth: 3,
            ),
            SizedBox(height: 24),
            Text(
              'Inicializando formulario...',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: kTextSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  BoxDecoration _buildGlassmorphismDecoration() {
    return BoxDecoration(
      // Gradiente glassmorphism multicapa
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white.withValues(alpha: 0.95),
          Colors.white.withValues(alpha: 0.85),
          kAccentBlue.withValues(alpha: 0.05),
          kAccentBlue.withValues(alpha: 0.04),
        ],
        stops: const [0.0, 0.3, 0.7, 1.0],
      ),

      borderRadius: BorderRadius.circular(borderRadius),

      // Borde glassmorphism
      border: Border.all(
        color: kAccentBlue.withValues(alpha: 0.2),
        width: 2,
      ),

      // Sombras multicapa profesionales
      boxShadow: [
        // Sombra principal coloreada
        BoxShadow(
          color: kAccentBlue.withValues(alpha: 0.2),
          blurRadius: 30,
          spreadRadius: 5,
          offset: const Offset(0, 15),
        ),
        // Sombra interna glassmorphism
        BoxShadow(
          color: Colors.white.withValues(alpha: 0.8),
          blurRadius: 20,
          spreadRadius: -8,
          offset: const Offset(0, -8),
        ),
        // Sombra de profundidad
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.1),
          blurRadius: 50,
          spreadRadius: 0,
          offset: const Offset(0, 25),
        ),
        // Sombra secundaria azul
        BoxShadow(
          color: kAccentBlue.withValues(alpha: 0.1),
          blurRadius: 40,
          spreadRadius: 2,
          offset: const Offset(5, 20),
        ),
      ],
    );
  }

  // ========================================================================
  // 🎮 MANEJADORES DE EVENTOS
  // ========================================================================

  void _handleBackPress() {
    _handleCancel();
  }

  Future<void> _handleCancel() async {
    // Mostrar confirmación si hay datos sin guardar
    final hasUnsavedData =
        _wizardController.formData.personalInfo.nombre.isNotEmpty ||
            _wizardController.formData.personalInfo.email.isNotEmpty;

    if (hasUnsavedData && !_wizardController.isEditMode) {
      final shouldClose = await _showCancelConfirmation();
      if (!shouldClose) return;
    }

    await _closeModal(cancelled: true);
  }

  Future<void> _handlePrevious() async {
    HapticFeedback.lightImpact();
    await _wizardController.previousStep();
  }

  Future<void> _handleNext() async {
    HapticFeedback.lightImpact();
    await _wizardController.nextStep();
  }

  Future<void> _handleFinish() async {
    try {
      HapticFeedback.mediumImpact();

      // Mostrar loading
      _showLoadingOverlay();

      // Intentar guardar
      final success = await _wizardController.finishWizard();

      // Cerrar loading overlay SIEMPRE
      _hideLoadingOverlay();

      if (success) {
        // Pequeña pausa para que se vea el loading cerrado
        await Future.delayed(const Duration(milliseconds: 100));

        // Éxito: cerrar modal y notificar
        await _closeModal(success: true);
      } else {
        // Error: mostrar mensaje
        _showErrorDialog(
          'Error al Guardar',
          'No se pudo guardar el cliente. Por favor, revise los datos e intente nuevamente.',
        );
      }
    } catch (e) {
      // Asegurar que se cierre el loading overlay
      _hideLoadingOverlay();
      _showErrorDialog(
        'Error Inesperado',
        'Ocurrió un error inesperado: $e',
      );
    }
  }

  Future<void> _closeModal(
      {bool success = false, bool cancelled = false}) async {
    if (_isClosing) return;

    // Marcar como cerrando para evitar múltiples ejecuciones
    _isClosing = true;

    try {
      // Ejecutar animaciones de salida
      await _startExitAnimations();

      if (mounted) {
        // Cerrar el modal
        Navigator.of(context).pop();

        // Ejecutar callbacks después del cierre
        if (success && widget.onClientSaved != null) {
          // Pequeña pausa para que se complete la animación de cierre
          await Future.delayed(const Duration(milliseconds: 100));
          widget.onClientSaved!();
        } else if (cancelled && widget.onCancelled != null) {
          widget.onCancelled!();
        }
      }
    } catch (e) {
      debugPrint('Error cerrando modal: $e');
      // Forzar cierre si hay error
      if (mounted) {
        Navigator.of(context).pop();
      }
    }
  }

  // ========================================================================
  // 🎭 DIÁLOGOS Y FEEDBACK
  // ========================================================================

  Future<bool> _showCancelConfirmation() async {
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Row(
              children: [
                Icon(Icons.warning_amber, color: Colors.orange),
                SizedBox(width: 12),
                Text('¿Cancelar creación?'),
              ],
            ),
            content: const Text(
              'Hay información sin guardar que se perderá. ¿Está seguro de que desea cancelar?',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('Continuar Editando'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.of(context).pop(true),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                child: const Text('Sí, Cancelar'),
              ),
            ],
          ),
        ) ??
        false;
  }

  void _showLoadingOverlay() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: Card(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(kBrandPurple),
                ),
                SizedBox(height: 16),
                Text(
                  'Guardando cliente...',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _hideLoadingOverlay() {
    if (mounted) {
      try {
        Navigator.of(context, rootNavigator: true).pop();
      } catch (e) {
        // Si no hay overlay que cerrar, continuar silenciosamente
        debugPrint('No hay loading overlay para cerrar');
      }
    }
  }

  void _showErrorDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            const Icon(Icons.error, color: Colors.red),
            const SizedBox(width: 12),
            Text(title),
          ],
        ),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Entendido'),
          ),
        ],
      ),
    );
  }

  // ========================================================================
  // 📊 MÉTODOS DE DEBUG
  // ========================================================================

  void _logModalState() {
    debugPrint('📊 ClientWizardModal State:');
    debugPrint('   isInitialized: $_isInitialized');
    debugPrint('   isClosing: $_isClosing');
    debugPrint(
        '   existingClient: ${widget.existingClient?.fullName ?? "null"}');
    if (_isInitialized) {
      _wizardController.logCurrentState();
    }
  }
}

/// 🎯 FUNCIÓN HELPER PARA MOSTRAR EL MODAL
/// Uso: showClientWizardModal(context, existingClient: client)
Future<bool?> showClientWizardModal(
  BuildContext context, {
  ClientModel? existingClient,
  VoidCallback? onClientSaved,
  VoidCallback? onCancelled,
}) {
  return showDialog<bool>(
    context: context,
    barrierDismissible: false,
    barrierColor: Colors.transparent, // El modal maneja su propio overlay
    builder: (context) => ClientWizardModal(
      existingClient: existingClient,
      onClientSaved: onClientSaved,
      onCancelled: onCancelled,
    ),
  );
}
