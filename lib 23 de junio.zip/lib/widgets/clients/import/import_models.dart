// [import_models.dart] - MODELOS ENTERPRISE PARA IMPORTACIÓN DE CLIENTES - CORREGIDO
// 📁 Ubicación: /lib/widgets/clients/import/import_models.dart
// 🎯 OBJETIVO: Modelos robustos para importación masiva con validación enterprise

import 'dart:typed_data';
import 'package:flutter/foundation.dart';

// ========================================================================
// 📊 ENUMS PRINCIPALES
// ========================================================================

/// 📁 FORMATOS DE ARCHIVO SOPORTADOS
enum ImportFormat {
  csv('CSV', 'text/csv', ['.csv']),
  excel(
      'Excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      ['.xlsx', '.xls']);

  const ImportFormat(this.displayName, this.mimeType, this.extensions);
  final String displayName;
  final String mimeType;
  final List<String> extensions;
}

/// 📊 ESTADOS DE IMPORTACIÓN
enum ImportStatus {
  idle('Inactivo', 'Esperando archivo'),
  analyzing('Analizando', 'Procesando archivo'),
  mapping('Mapeando', 'Configurando campos'),
  validating('Validando', 'Verificando datos'),
  importing('Importando', 'Guardando en base de datos'),
  completed('Completado', 'Importación finalizada'),
  failed('Fallido', 'Error en importación'),
  cancelled('Cancelado', 'Proceso cancelado');

  const ImportStatus(this.displayName, this.description);
  final String displayName;
  final String description;
}

/// 🔍 NIVELES DE VALIDACIÓN
enum ValidationLevel {
  error('Error', 'Impide la importación'),
  warning('Advertencia', 'Puede continuar'),
  info('Información', 'Solo informativo');

  const ValidationLevel(this.displayName, this.description);
  final String displayName;
  final String description;
}

/// 🔄 ESTRATEGIAS PARA DUPLICADOS
enum DuplicateStrategy {
  skip('Omitir', 'No importar duplicados'),
  update('Actualizar', 'Sobrescribir datos existentes'),
  createNew('Crear Nuevo', 'Crear registro adicional');

  const DuplicateStrategy(this.displayName, this.description);
  final String displayName;
  final String description;
}

/// 📋 DELIMITADORES CSV COMUNES
enum CsvDelimiter {
  comma(',', 'Coma'),
  semicolon(';', 'Punto y coma'),
  tab('\t', 'Tabulación'),
  pipe('|', 'Barra vertical');

  const CsvDelimiter(this.value, this.displayName);
  final String value;
  final String displayName;
}

// ========================================================================
// ⚙️ CONFIGURACIONES DE IMPORTACIÓN
// ========================================================================

/// ⚙️ OPCIONES DE IMPORTACIÓN CONFIGURABLES
class ImportOptions {
  final ImportFormat format;
  final bool hasHeaders;
  final CsvDelimiter delimiter;
  final String encoding;
  final bool skipEmptyRows;
  final bool trimWhitespace;
  final int maxRecords;
  final int previewRows;
  final DuplicateStrategy duplicateStrategy;

  const ImportOptions({
    required this.format,
    this.hasHeaders = true,
    this.delimiter = CsvDelimiter.comma,
    this.encoding = 'utf-8',
    this.skipEmptyRows = true,
    this.trimWhitespace = true,
    this.maxRecords = 10000,
    this.previewRows = 10,
    this.duplicateStrategy = DuplicateStrategy.skip,
  });

  /// 🏭 FACTORY: Opciones por defecto para CSV
  factory ImportOptions.defaultCsv() {
    return const ImportOptions(
      format: ImportFormat.csv,
      hasHeaders: true,
      delimiter: CsvDelimiter.comma,
      encoding: 'utf-8',
      skipEmptyRows: true,
      trimWhitespace: true,
      maxRecords: 10000,
      previewRows: 10,
      duplicateStrategy: DuplicateStrategy.skip,
    );
  }

  /// 🏭 FACTORY: Opciones por defecto para Excel
  factory ImportOptions.defaultExcel() {
    return const ImportOptions(
      format: ImportFormat.excel,
      hasHeaders: true,
      skipEmptyRows: true,
      trimWhitespace: true,
      maxRecords: 10000,
      previewRows: 10,
      duplicateStrategy: DuplicateStrategy.skip,
    );
  }

  ImportOptions copyWith({
    ImportFormat? format,
    bool? hasHeaders,
    CsvDelimiter? delimiter,
    String? encoding,
    bool? skipEmptyRows,
    bool? trimWhitespace,
    int? maxRecords,
    int? previewRows,
    DuplicateStrategy? duplicateStrategy,
  }) {
    return ImportOptions(
      format: format ?? this.format,
      hasHeaders: hasHeaders ?? this.hasHeaders,
      delimiter: delimiter ?? this.delimiter,
      encoding: encoding ?? this.encoding,
      skipEmptyRows: skipEmptyRows ?? this.skipEmptyRows,
      trimWhitespace: trimWhitespace ?? this.trimWhitespace,
      maxRecords: maxRecords ?? this.maxRecords,
      previewRows: previewRows ?? this.previewRows,
      duplicateStrategy: duplicateStrategy ?? this.duplicateStrategy,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'format': format.name,
      'hasHeaders': hasHeaders,
      'delimiter': delimiter.value,
      'encoding': encoding,
      'skipEmptyRows': skipEmptyRows,
      'trimWhitespace': trimWhitespace,
      'maxRecords': maxRecords,
      'previewRows': previewRows,
      'duplicateStrategy': duplicateStrategy.name,
    };
  }
}

// ========================================================================
// 📁 INFORMACIÓN DEL ARCHIVO
// ========================================================================

/// 📁 INFORMACIÓN DEL ARCHIVO SELECCIONADO
class ImportFileInfo {
  final String name;
  final int sizeBytes;
  final ImportFormat format;
  final Uint8List bytes;
  final DateTime selectedAt;
  final String? detectedEncoding;
  final CsvDelimiter? detectedDelimiter;

  const ImportFileInfo({
    required this.name,
    required this.sizeBytes,
    required this.format,
    required this.bytes,
    required this.selectedAt,
    this.detectedEncoding,
    this.detectedDelimiter,
  });

  /// 📊 PROPIEDADES CALCULADAS
  String get sizeFormatted {
    if (sizeBytes < 1024) {
      return '$sizeBytes B';
    }
    if (sizeBytes < 1024 * 1024) {
      return '${(sizeBytes / 1024).toStringAsFixed(1)} KB';
    }
    return '${(sizeBytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  bool get isValidSize => sizeBytes <= ImportLimits.maxFileSizeBytes;

  String get extension => name.split('.').last.toLowerCase();

  ImportFileInfo copyWith({
    String? name,
    int? sizeBytes,
    ImportFormat? format,
    Uint8List? bytes,
    DateTime? selectedAt,
    String? detectedEncoding,
    CsvDelimiter? detectedDelimiter,
  }) {
    return ImportFileInfo(
      name: name ?? this.name,
      sizeBytes: sizeBytes ?? this.sizeBytes,
      format: format ?? this.format,
      bytes: bytes ?? this.bytes,
      selectedAt: selectedAt ?? this.selectedAt,
      detectedEncoding: detectedEncoding ?? this.detectedEncoding,
      detectedDelimiter: detectedDelimiter ?? this.detectedDelimiter,
    );
  }
}

// ========================================================================
// 🗺️ MAPEO DE CAMPOS
// ========================================================================

/// 🗺️ MAPEO DE CAMPO INDIVIDUAL
class FieldMapping {
  final String sourceColumn;
  final String targetField;
  final bool isRequired;
  final bool isAutoMapped;
  final List<FieldValidator> validators;
  final String? displayName;

  const FieldMapping({
    required this.sourceColumn,
    required this.targetField,
    required this.isRequired,
    this.isAutoMapped = false,
    this.validators = const [],
    this.displayName,
  });

  String get effectiveDisplayName => displayName ?? targetField;

  FieldMapping copyWith({
    String? sourceColumn,
    String? targetField,
    bool? isRequired,
    bool? isAutoMapped,
    List<FieldValidator>? validators,
    String? displayName,
  }) {
    return FieldMapping(
      sourceColumn: sourceColumn ?? this.sourceColumn,
      targetField: targetField ?? this.targetField,
      isRequired: isRequired ?? this.isRequired,
      isAutoMapped: isAutoMapped ?? this.isAutoMapped,
      validators: validators ?? this.validators,
      displayName: displayName ?? this.displayName,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'sourceColumn': sourceColumn,
      'targetField': targetField,
      'isRequired': isRequired,
      'isAutoMapped': isAutoMapped,
      'displayName': displayName,
    };
  }
}

/// 🗺️ CONFIGURACIÓN COMPLETA DE MAPEO
class MappingConfiguration {
  final List<FieldMapping> mappings;
  final List<String> unmappedColumns;
  final List<String> missingRequiredFields;
  final int totalColumns;
  final double autoMappingAccuracy;

  const MappingConfiguration({
    required this.mappings,
    required this.unmappedColumns,
    required this.missingRequiredFields,
    required this.totalColumns,
    required this.autoMappingAccuracy,
  });

  /// 📊 PROPIEDADES CALCULADAS
  bool get isComplete => missingRequiredFields.isEmpty;
  int get mappedColumns => mappings.length;
  int get autoMappedColumns => mappings.where((m) => m.isAutoMapped).length;

  double get completionPercentage {
    if (totalColumns == 0) return 0.0;
    return (mappedColumns / totalColumns) * 100;
  }

  String get statusMessage {
    if (isComplete) {
      return 'Mapeo completo - Listo para importar';
    } else if (missingRequiredFields.length == 1) {
      return 'Falta mapear 1 campo requerido';
    } else {
      return 'Faltan mapear ${missingRequiredFields.length} campos requeridos';
    }
  }

  MappingConfiguration copyWith({
    List<FieldMapping>? mappings,
    List<String>? unmappedColumns,
    List<String>? missingRequiredFields,
    int? totalColumns,
    double? autoMappingAccuracy,
  }) {
    return MappingConfiguration(
      mappings: mappings ?? this.mappings,
      unmappedColumns: unmappedColumns ?? this.unmappedColumns,
      missingRequiredFields:
          missingRequiredFields ?? this.missingRequiredFields,
      totalColumns: totalColumns ?? this.totalColumns,
      autoMappingAccuracy: autoMappingAccuracy ?? this.autoMappingAccuracy,
    );
  }
}

// ========================================================================
// ✅ VALIDACIÓN DE DATOS
// ========================================================================

/// ❌ ERROR DE VALIDACIÓN INDIVIDUAL
class ValidationError {
  final int rowIndex;
  final String columnName;
  final String originalValue;
  final ValidationLevel level;
  final String message;
  final String? suggestedFix;

  const ValidationError({
    required this.rowIndex,
    required this.columnName,
    required this.originalValue,
    required this.level,
    required this.message,
    this.suggestedFix,
  });

  String get displayRowNumber => '${rowIndex + 1}';

  Map<String, dynamic> toMap() {
    return {
      'rowIndex': rowIndex,
      'columnName': columnName,
      'originalValue': originalValue,
      'level': level.name,
      'message': message,
      'suggestedFix': suggestedFix,
    };
  }
}

/// ✅ RESULTADO DE VALIDACIÓN
class ValidationResult {
  final List<ValidationError> errors;
  final List<ValidationError> warnings;
  final List<ValidationError> infos;
  final int totalRows;
  final int validRows;
  final DateTime validatedAt;

  const ValidationResult({
    required this.errors,
    required this.warnings,
    required this.infos,
    required this.totalRows,
    required this.validRows,
    required this.validatedAt,
  });

  /// 📊 PROPIEDADES CALCULADAS
  bool get hasErrors => errors.isNotEmpty;
  bool get hasWarnings => warnings.isNotEmpty;
  bool get canProceed => !hasErrors;

  int get errorRows => errors.map((e) => e.rowIndex).toSet().length;
  int get warningRows => warnings.map((e) => e.rowIndex).toSet().length;

  double get successRate {
    if (totalRows == 0) return 0.0;
    return (validRows / totalRows) * 100;
  }

  String get summaryMessage {
    if (!hasErrors && !hasWarnings) {
      return 'Todos los datos son válidos';
    } else if (hasErrors) {
      return '$errorRows filas con errores críticos';
    } else {
      return '$warningRows filas con advertencias';
    }
  }

  ValidationResult copyWith({
    List<ValidationError>? errors,
    List<ValidationError>? warnings,
    List<ValidationError>? infos,
    int? totalRows,
    int? validRows,
    DateTime? validatedAt,
  }) {
    return ValidationResult(
      errors: errors ?? this.errors,
      warnings: warnings ?? this.warnings,
      infos: infos ?? this.infos,
      totalRows: totalRows ?? this.totalRows,
      validRows: validRows ?? this.validRows,
      validatedAt: validatedAt ?? this.validatedAt,
    );
  }
}

// ========================================================================
// 📊 RESULTADOS DE IMPORTACIÓN
// ========================================================================

/// 📊 RESULTADO FINAL DE IMPORTACIÓN
class ImportResult {
  final bool isSuccess;
  final int totalRows;
  final int successfulRows;
  final int errorRows;
  final int skippedRows;
  final List<ImportError> errors;
  final Duration processingTime;
  final DateTime completedAt;
  final Map<String, dynamic>? metadata;

  const ImportResult({
    required this.isSuccess,
    required this.totalRows,
    required this.successfulRows,
    required this.errorRows,
    required this.skippedRows,
    required this.errors,
    required this.processingTime,
    required this.completedAt,
    this.metadata,
  });

  /// 🏭 FACTORY: Resultado exitoso
  factory ImportResult.success({
    required int totalRows,
    required int successfulRows,
    required Duration processingTime,
    int skippedRows = 0,
    Map<String, dynamic>? metadata,
  }) {
    return ImportResult(
      isSuccess: true,
      totalRows: totalRows,
      successfulRows: successfulRows,
      errorRows: totalRows - successfulRows - skippedRows,
      skippedRows: skippedRows,
      errors: [],
      processingTime: processingTime,
      completedAt: DateTime.now(),
      metadata: metadata,
    );
  }

  /// 🏭 FACTORY: Resultado con errores
  factory ImportResult.withErrors({
    required int totalRows,
    required int successfulRows,
    required List<ImportError> errors,
    required Duration processingTime,
    int skippedRows = 0,
    Map<String, dynamic>? metadata,
  }) {
    return ImportResult(
      isSuccess: errors.isEmpty,
      totalRows: totalRows,
      successfulRows: successfulRows,
      errorRows: totalRows - successfulRows - skippedRows,
      skippedRows: skippedRows,
      errors: errors,
      processingTime: processingTime,
      completedAt: DateTime.now(),
      metadata: metadata,
    );
  }

  /// 🏭 FACTORY: Resultado fallido
  factory ImportResult.failed({
    required String errorMessage,
    required Duration processingTime,
    Map<String, dynamic>? metadata,
  }) {
    return ImportResult(
      isSuccess: false,
      totalRows: 0,
      successfulRows: 0,
      errorRows: 0,
      skippedRows: 0,
      errors: [ImportError.critical(message: errorMessage)],
      processingTime: processingTime,
      completedAt: DateTime.now(),
      metadata: metadata,
    );
  }

  /// 📊 PROPIEDADES CALCULADAS
  double get successRate {
    if (totalRows == 0) return 0.0;
    return (successfulRows / totalRows) * 100;
  }

  String get summaryText {
    if (isSuccess && errorRows == 0) {
      return '$successfulRows de $totalRows clientes importados exitosamente';
    } else if (successfulRows > 0) {
      return '$successfulRows exitosos, $errorRows con errores de $totalRows total';
    } else {
      return 'Importación fallida: ${errors.first.message}';
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'isSuccess': isSuccess,
      'totalRows': totalRows,
      'successfulRows': successfulRows,
      'errorRows': errorRows,
      'skippedRows': skippedRows,
      'errors': errors.map((e) => e.toMap()).toList(),
      'processingTime': processingTime.inMilliseconds,
      'completedAt': completedAt.toIso8601String(),
      'metadata': metadata,
    };
  }
}

/// ❌ ERROR DE IMPORTACIÓN
class ImportError {
  final int? rowIndex;
  final String message;
  final String? details;
  final ValidationLevel level;
  final DateTime occurredAt;

  const ImportError({
    this.rowIndex,
    required this.message,
    this.details,
    required this.level,
    required this.occurredAt,
  });

  /// 🏭 FACTORY: Error crítico
  factory ImportError.critical({
    int? rowIndex,
    required String message,
    String? details,
  }) {
    return ImportError(
      rowIndex: rowIndex,
      message: message,
      details: details,
      level: ValidationLevel.error,
      occurredAt: DateTime.now(),
    );
  }

  /// 🏭 FACTORY: Advertencia
  factory ImportError.warning({
    int? rowIndex,
    required String message,
    String? details,
  }) {
    return ImportError(
      rowIndex: rowIndex,
      message: message,
      details: details,
      level: ValidationLevel.warning,
      occurredAt: DateTime.now(),
    );
  }

  String get displayRowNumber =>
      rowIndex != null ? '${rowIndex! + 1}' : 'General';

  Map<String, dynamic> toMap() {
    return {
      'rowIndex': rowIndex,
      'message': message,
      'details': details,
      'level': level.name,
      'occurredAt': occurredAt.toIso8601String(),
    };
  }
}

// ========================================================================
// 🛡️ VALIDADORES DE CAMPOS
// ========================================================================

/// 🛡️ VALIDADOR ABSTRACTO BASE
abstract class FieldValidator {
  bool validate(String value);
  String get errorMessage;
  String? get suggestedFix => null;
}

/// 📧 VALIDADOR DE EMAIL
class EmailValidator extends FieldValidator {
  static final RegExp _emailRegex = RegExp(
    r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',
  );

  @override
  bool validate(String value) {
    if (value.trim().isEmpty) return false;
    return _emailRegex.hasMatch(value.trim().toLowerCase());
  }

  @override
  String get errorMessage => 'Formato de email inválido';

  @override
  String get suggestedFix => 'Verificar formato: usuario@dominio.com';
}

/// 📱 VALIDADOR DE TELÉFONO (MÉXICO)
class PhoneValidator extends FieldValidator {
  static final RegExp _phoneRegex = RegExp(
    r'^(\+52|52)?\s*(\d{2})\s*(\d{4})\s*(\d{4})$',
  );

  @override
  bool validate(String value) {
    if (value.trim().isEmpty) return false;
    final cleaned = value.replaceAll(RegExp(r'[^\d+]'), '');
    return _phoneRegex.hasMatch(cleaned) || cleaned.length == 10;
  }

  @override
  String get errorMessage => 'Formato de teléfono inválido';

  @override
  String get suggestedFix => 'Formato: 5512345678 o +52 55 1234 5678';
}

/// ✅ VALIDADOR DE CAMPO REQUERIDO
class RequiredValidator extends FieldValidator {
  @override
  bool validate(String value) {
    return value.trim().isNotEmpty;
  }

  @override
  String get errorMessage => 'Este campo es requerido';

  @override
  String get suggestedFix => 'Proporcionar un valor válido';
}

/// 📏 VALIDADOR DE LONGITUD
class LengthValidator extends FieldValidator {
  final int? minLength;
  final int? maxLength;

  LengthValidator({this.minLength, this.maxLength});

  @override
  bool validate(String value) {
    final length = value.trim().length;
    if (minLength != null && length < minLength!) return false;
    if (maxLength != null && length > maxLength!) return false;
    return true;
  }

  @override
  String get errorMessage {
    if (minLength != null && maxLength != null) {
      return 'Debe tener entre $minLength y $maxLength caracteres';
    } else if (minLength != null) {
      return 'Debe tener al menos $minLength caracteres';
    } else {
      return 'Debe tener máximo $maxLength caracteres';
    }
  }
}

/// 🔢 VALIDADOR DE CÓDIGO POSTAL MEXICANO
class PostalCodeValidator extends FieldValidator {
  static final RegExp _postalRegex = RegExp(r'^\d{5}$');

  @override
  bool validate(String value) {
    if (value.trim().isEmpty) return true; // Opcional
    return _postalRegex.hasMatch(value.trim());
  }

  @override
  String get errorMessage => 'Código postal debe tener 5 dígitos';

  @override
  String get suggestedFix => 'Ejemplo: 06700';
}

// ========================================================================
// ⚙️ LÍMITES Y CONSTANTES DEL SISTEMA
// ========================================================================

/// ⚙️ LÍMITES DEL SISTEMA DE IMPORTACIÓN
class ImportLimits {
  // ✅ CONSTANTES PRINCIPALES (CAMEL CASE - ESTILO DART RECOMENDADO)
  static const int maxFileSizeMb = 50;
  static const int maxFileSizeBytes = maxFileSizeMb * 1024 * 1024;
  static const int maxRecordsPerImport = 10000;
  static const int batchSizeFirestore = 500;
  static const Duration operationTimeout = Duration(minutes: 10);
  static const int previewRowsCount = 10;
  static const int maxValidationErrorsDisplay = 100;
  static const double minAutoMappingConfidence = 0.7;

  // 🆕 CONSTANTES ADICIONALES PARA COMPATIBILIDAD (SNAKE_CASE)
  static const int MAX_FILE_SIZE_MB = maxFileSizeMb;
  static const int MAX_FILE_SIZE_BYTES = maxFileSizeBytes;
  static const int MAX_RECORDS_PER_IMPORT = maxRecordsPerImport;
  static const int BATCH_SIZE_FIRESTORE = batchSizeFirestore;
  static const int PREVIEW_ROWS_COUNT = previewRowsCount;
  static const int MAX_VALIDATION_ERRORS_DISPLAY = maxValidationErrorsDisplay;
}

/// 🗺️ CAMPOS OBJETIVO DISPONIBLES PARA MAPEO
class TargetFields {
  static const Map<String, String> requiredFields = {
    'nombre': 'Nombre',
    'email': 'Email',
  };

  static const Map<String, String> optionalFields = {
    'apellidos': 'Apellidos',
    'telefono': 'Teléfono',
    'empresa': 'Empresa',
    'calle': 'Calle',
    'numeroExterior': 'Número Exterior',
    'numeroInterior': 'Número Interior',
    'colonia': 'Colonia',
    'codigoPostal': 'Código Postal',
    'alcaldia': 'Alcaldía/Municipio',
    'referencias': 'Referencias',
    'notas': 'Notas',
  };

  static const Map<String, String> allFields = {
    ...requiredFields,
    ...optionalFields,
  };

  // 🆕 ALIAS PARA COMPATIBILIDAD
  static const Map<String, String> REQUIRED_FIELDS = requiredFields;

  /// 🔍 PATRONES PARA AUTO-MAPEO INTELIGENTE
  static const Map<String, List<String>> fieldPatterns = {
    'nombre': ['nombre', 'name', 'first_name', 'primer_nombre', 'nombres'],
    'apellidos': ['apellidos', 'apellido', 'last_name', 'surname', 'familia'],
    'email': ['email', 'correo', 'mail', 'e-mail', 'correo_electronico'],
    'telefono': ['telefono', 'phone', 'tel', 'celular', 'movil', 'whatsapp'],
    'empresa': ['empresa', 'company', 'organizacion', 'negocio', 'corporacion'],
    'calle': ['calle', 'street', 'direccion', 'address', 'via'],
    'numeroExterior': ['numero_exterior', 'num_ext', 'number', 'numero', '#'],
    'numeroInterior': [
      'numero_interior',
      'num_int',
      'interior',
      'depto',
      'apt'
    ],
    'colonia': ['colonia', 'neighborhood', 'barrio', 'fraccionamiento'],
    'codigoPostal': ['codigo_postal', 'cp', 'zip', 'postal_code', 'zip_code'],
    'alcaldia': ['alcaldia', 'municipio', 'delegacion', 'city', 'ciudad'],
    'referencias': [
      'referencias',
      'reference',
      'observaciones',
      'instrucciones'
    ],
    'notas': ['notas', 'notes', 'comentarios', 'comments', 'observaciones'],
  };

  /// 🛡️ VALIDADORES POR CAMPO
  static List<FieldValidator> getValidators(String field) {
    switch (field) {
      case 'nombre':
        return [
          RequiredValidator(),
          LengthValidator(minLength: 2, maxLength: 50)
        ];
      case 'email':
        return [RequiredValidator(), EmailValidator()];
      case 'telefono':
        return [PhoneValidator()];
      case 'codigoPostal':
        return [PostalCodeValidator()];
      default:
        return [];
    }
  }
}

// ========================================================================
// 📊 PROGRESO DE IMPORTACIÓN
// ========================================================================

/// 📊 ESTADO DE PROGRESO EN TIEMPO REAL
class ImportProgress {
  final ImportStatus status;
  final double percentage;
  final int processedRows;
  final int totalRows;
  final String currentOperation;
  final Duration elapsed;
  final Duration? estimatedRemaining;
  final List<String> recentErrors;

  const ImportProgress({
    required this.status,
    required this.percentage,
    required this.processedRows,
    required this.totalRows,
    required this.currentOperation,
    required this.elapsed,
    this.estimatedRemaining,
    this.recentErrors = const [],
  });

  /// 🏭 FACTORY: Progreso inicial
  factory ImportProgress.initial() {
    return const ImportProgress(
      status: ImportStatus.idle,
      percentage: 0.0,
      processedRows: 0,
      totalRows: 0,
      currentOperation: 'Esperando inicio',
      elapsed: Duration.zero,
    );
  }

  /// 📊 PROPIEDADES CALCULADAS
  bool get isActive =>
      status != ImportStatus.idle &&
      status != ImportStatus.completed &&
      status != ImportStatus.failed &&
      status != ImportStatus.cancelled;

  String get remainingText {
    if (estimatedRemaining == null) return 'Calculando...';
    final minutes = estimatedRemaining!.inMinutes;
    final seconds = estimatedRemaining!.inSeconds % 60;
    if (minutes > 0) {
      return '${minutes}m ${seconds}s restantes';
    } else {
      return '${seconds}s restantes';
    }
  }

  String get progressText => '$processedRows de $totalRows filas procesadas';

  ImportProgress copyWith({
    ImportStatus? status,
    double? percentage,
    int? processedRows,
    int? totalRows,
    String? currentOperation,
    Duration? elapsed,
    Duration? estimatedRemaining,
    List<String>? recentErrors,
  }) {
    return ImportProgress(
      status: status ?? this.status,
      percentage: percentage ?? this.percentage,
      processedRows: processedRows ?? this.processedRows,
      totalRows: totalRows ?? this.totalRows,
      currentOperation: currentOperation ?? this.currentOperation,
      elapsed: elapsed ?? this.elapsed,
      estimatedRemaining: estimatedRemaining ?? this.estimatedRemaining,
      recentErrors: recentErrors ?? this.recentErrors,
    );
  }
}
