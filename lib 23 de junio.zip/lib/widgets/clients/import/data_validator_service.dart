// [data_validator_service.dart] - VALIDADOR ENTERPRISE CON REGLAS FLEXIBLES PARA MÉXICO
// 📁 Ubicación: /lib/widgets/clients/import/data_validator_service.dart
// 🎯 OBJETIVO: Validación robusta pero flexible que acepta variaciones comunes

import 'package:flutter/foundation.dart';
import 'package:collection/collection.dart';
import 'import_models.dart';

// ========================================================================
// 🛡️ SERVICIO PRINCIPAL DE VALIDACIÓN
// ========================================================================

/// 🛡️ VALIDADOR ENTERPRISE PARA DATOS DE IMPORTACIÓN - VERSIÓN FLEXIBLE
class DataValidatorService {
  static final DataValidatorService _instance =
      DataValidatorService._internal();
  factory DataValidatorService() => _instance;
  DataValidatorService._internal();

  // ========================================================================
  // 🎯 MÉTODO PRINCIPAL DE VALIDACIÓN
  // ========================================================================

  /// 🎯 VALIDAR DATOS COMPLETOS CON MAPEO - REGLAS FLEXIBLES
  Future<ValidationResult> validateData(
    List<List<String>> rawData,
    List<FieldMapping> mappings, {
    Function(double)? onProgress,
  }) async {
    final stopwatch = Stopwatch()..start();

    try {
      debugPrint(
          '🛡️ Iniciando validación flexible de ${rawData.length} filas');

      final errors = <ValidationError>[];
      final warnings = <ValidationError>[];
      final infos = <ValidationError>[];

      // 📊 CONVERTIR DATOS A FORMATO MAPEADO
      final mappedData = _mapRawDataToFields(rawData, mappings);

      int validRows = 0;

      // 🔍 VALIDAR CADA FILA CON REGLAS FLEXIBLES
      for (int rowIndex = 0; rowIndex < mappedData.length; rowIndex++) {
        final rowData = mappedData[rowIndex];
        bool rowIsValid = true;

        // 📊 REPORTE DE PROGRESO
        if (onProgress != null && rowIndex % 100 == 0) {
          final progress = (rowIndex / mappedData.length) * 0.8;
          onProgress(progress);
        }

        // 🛡️ VALIDAR CADA CAMPO MAPEADO CON FLEXIBILIDAD
        for (final mapping in mappings) {
          final value = rowData[mapping.targetField] ?? '';
          final fieldErrors = _validateFieldFlexible(
            value,
            mapping,
            rowIndex,
          );

          for (final error in fieldErrors) {
            switch (error.level) {
              case ValidationLevel.error:
                errors.add(error);
                rowIsValid = false;
                break;
              case ValidationLevel.warning:
                warnings.add(error);
                break;
              case ValidationLevel.info:
                infos.add(error);
                break;
            }
          }
        }

        if (rowIsValid) validRows++;

        // 🚨 LÍMITE DE ERRORES PARA PERFORMANCE
        if (errors.length > ImportLimits.MAX_VALIDATION_ERRORS_DISPLAY) {
          debugPrint(
              '⚠️ Límite de errores alcanzado, deteniendo validación detallada');
          break;
        }
      }

      // 📊 ACTUALIZAR PROGRESO A 80%
      onProgress?.call(0.8);

      // 🔍 VALIDACIONES GLOBALES MÁS PERMISIVAS
      await _performFlexibleGlobalValidations(
        mappedData,
        mappings,
        errors,
        warnings,
        infos,
      );

      // 📊 ACTUALIZAR PROGRESO A 100%
      onProgress?.call(1.0);

      stopwatch.stop();
      debugPrint(
          '✅ Validación flexible completada en ${stopwatch.elapsed.inMilliseconds}ms');
      debugPrint(
          '📊 Resultado: $validRows válidas, ${errors.length} errores, ${warnings.length} advertencias');

      return ValidationResult(
        errors: errors,
        warnings: warnings,
        infos: infos,
        totalRows: rawData.length,
        validRows: validRows,
        validatedAt: DateTime.now(),
      );
    } catch (e, stackTrace) {
      stopwatch.stop();
      debugPrint('❌ Error en validación: $e');
      debugPrint('🔍 Stack trace: $stackTrace');

      return ValidationResult(
        errors: [
          ValidationError(
            rowIndex: -1,
            columnName: 'Sistema',
            originalValue: '',
            level: ValidationLevel.error,
            message: 'Error interno de validación: ${e.toString()}',
          ),
        ],
        warnings: [],
        infos: [],
        totalRows: rawData.length,
        validRows: 0,
        validatedAt: DateTime.now(),
      );
    }
  }

  // ========================================================================
  // 🗺️ MAPEO DE DATOS (MANTENIDO)
  // ========================================================================

  List<Map<String, String>> _mapRawDataToFields(
    List<List<String>> rawData,
    List<FieldMapping> mappings,
  ) {
    final mappedData = <Map<String, String>>[];

    for (final row in rawData) {
      final mappedRow = <String, String>{};

      for (final mapping in mappings) {
        final sourceIndex =
            _findColumnIndex(rawData.first ?? [], mapping.sourceColumn);

        if (sourceIndex != -1 && sourceIndex < row.length) {
          mappedRow[mapping.targetField] = row[sourceIndex].trim();
        } else {
          mappedRow[mapping.targetField] = '';
        }
      }

      mappedData.add(mappedRow);
    }

    return mappedData;
  }

  int _findColumnIndex(List<String> headers, String columnName) {
    return headers.indexWhere((header) => header.trim() == columnName.trim());
  }

  // ========================================================================
  // 🛡️ VALIDACIÓN POR CAMPO - VERSIÓN FLEXIBLE
  // ========================================================================

  /// 🛡️ VALIDAR CAMPO INDIVIDUAL CON REGLAS FLEXIBLES
  List<ValidationError> _validateFieldFlexible(
    String value,
    FieldMapping mapping,
    int rowIndex,
  ) {
    final errors = <ValidationError>[];

    // 🔍 SALTAR VALIDACIÓN PARA CAMPOS VACÍOS NO REQUERIDOS
    if (value.trim().isEmpty && !mapping.isRequired) {
      return errors; // Campo vacío opcional = válido
    }

    // 🔍 VALIDAR CON CADA VALIDADOR CONFIGURADO - MODO FLEXIBLE
    for (final validator in mapping.validators) {
      if (!_validateFlexible(validator, value, mapping.targetField)) {
        final level =
            _determineFlexibleValidationLevel(validator, mapping, value);

        errors.add(ValidationError(
          rowIndex: rowIndex,
          columnName: mapping.sourceColumn,
          originalValue: value,
          level: level,
          message:
              _getFlexibleErrorMessage(validator, mapping.targetField, value),
          suggestedFix:
              _getFlexibleSuggestion(validator, mapping.targetField, value),
        ));

        // Si es error crítico, no seguir validando este campo
        if (level == ValidationLevel.error) break;
      }
    }

    return errors;
  }

  /// 🎯 VALIDACIÓN FLEXIBLE POR TIPO
  bool _validateFlexible(
      FieldValidator validator, String value, String fieldType) {
    final trimmedValue = value.trim();

    if (validator is RequiredValidator) {
      return trimmedValue.isNotEmpty;
    }

    if (validator is EmailValidator) {
      return _validateEmailFlexible(trimmedValue);
    }

    if (validator is PhoneValidator) {
      return _validatePhoneFlexible(trimmedValue);
    }

    if (validator is LengthValidator) {
      return _validateLengthFlexible(validator, trimmedValue);
    }

    if (validator is PostalCodeValidator) {
      return _validatePostalCodeFlexible(trimmedValue);
    }

    // Validador desconocido - asumir válido
    return true;
  }

  /// 📧 VALIDACIÓN DE EMAIL FLEXIBLE
  bool _validateEmailFlexible(String email) {
    if (email.isEmpty)
      return true; // Campo vacío = válido para campos opcionales

    // Reglas flexibles para email
    if (!email.contains('@')) return false;
    if (!email.contains('.')) return false;
    if (email.length < 5) return false;
    if (email.startsWith('@') || email.endsWith('@')) return false;
    if (email.startsWith('.') || email.endsWith('.')) return false;

    // Verificar que no tenga múltiples @
    if (email.split('@').length != 2) return false;

    final parts = email.split('@');
    final localPart = parts[0];
    final domainPart = parts[1];

    if (localPart.isEmpty || domainPart.isEmpty) return false;
    if (!domainPart.contains('.')) return false;

    return true;
  }

  /// 📱 VALIDACIÓN DE TELÉFONO FLEXIBLE PARA MÉXICO
  bool _validatePhoneFlexible(String phone) {
    if (phone.isEmpty)
      return true; // Campo vacío = válido para campos opcionales

    // Limpiar el teléfono - remover todo excepto dígitos
    final cleanPhone = phone.replaceAll(RegExp(r'[^\d]'), '');

    // Casos válidos para México:
    // 1. 10 dígitos: 5512345678
    if (cleanPhone.length == 10) {
      return _isValidMexicanAreaCode(cleanPhone.substring(0, 2));
    }

    // 2. 12 dígitos con código de país: 525512345678
    if (cleanPhone.length == 12 && cleanPhone.startsWith('52')) {
      final localNumber = cleanPhone.substring(2);
      return _isValidMexicanAreaCode(localNumber.substring(0, 2));
    }

    // 3. 13 dígitos con 1 adicional: 15512345678 (algunos formatos internacionales)
    if (cleanPhone.length == 13 && cleanPhone.startsWith('152')) {
      final localNumber = cleanPhone.substring(3);
      return _isValidMexicanAreaCode(localNumber.substring(0, 2));
    }

    // 4. Números de 8 dígitos (líneas fijas sin código de área)
    if (cleanPhone.length == 8) {
      return true; // Aceptar números locales
    }

    return false;
  }

  /// 🇲🇽 VERIFICAR CÓDIGO DE ÁREA MEXICANO VÁLIDO
  bool _isValidMexicanAreaCode(String areaCode) {
    // Códigos de área comunes en México
    const validAreaCodes = [
      '55', '56', // Ciudad de México
      '33', // Guadalajara
      '81', // Monterrey
      '222', '223', // Puebla
      '228', // Veracruz
      '999', // Mérida
      '664', // Tijuana
      '656', // Juárez
      '867', // Matamoros
      '998', // Cancún
      // Y muchos más... para simplificar, aceptamos códigos que empiecen con estos dígitos
    ];

    // Verificación flexible - aceptar si empieza con dígitos comunes
    if (areaCode.length >= 2) {
      final firstTwo = areaCode.substring(0, 2);
      return [
        '55',
        '56',
        '33',
        '81',
        '22',
        '99',
        '66',
        '86',
        '44',
        '77',
        '61',
        '46',
        '83'
      ].contains(firstTwo);
    }

    return true; // Aceptar por defecto si no podemos verificar
  }

  /// 📏 VALIDACIÓN DE LONGITUD FLEXIBLE
  bool _validateLengthFlexible(LengthValidator validator, String value) {
    if (value.isEmpty)
      return true; // Campo vacío = válido para campos opcionales

    final length = value.length;
    if (validator.minLength != null && length < validator.minLength!)
      return false;
    if (validator.maxLength != null && length > validator.maxLength!)
      return false;
    return true;
  }

  /// 🏷️ VALIDACIÓN DE CÓDIGO POSTAL FLEXIBLE
  bool _validatePostalCodeFlexible(String postalCode) {
    if (postalCode.isEmpty)
      return true; // Campo vacío = válido para campos opcionales

    // Remover espacios y caracteres especiales
    final cleanCode = postalCode.replaceAll(RegExp(r'[^\d]'), '');

    // México: 5 dígitos
    if (cleanCode.length == 5) {
      // Verificar que esté en rango válido (01000-99999)
      final code = int.tryParse(cleanCode);
      return code != null && code >= 1000 && code <= 99999;
    }

    return false;
  }

  /// 🎯 DETERMINAR NIVEL DE VALIDACIÓN FLEXIBLE
  ValidationLevel _determineFlexibleValidationLevel(
    FieldValidator validator,
    FieldMapping mapping,
    String value,
  ) {
    // Solo campos requeridos vacíos son errores críticos
    if (validator is RequiredValidator &&
        mapping.isRequired &&
        value.trim().isEmpty) {
      return ValidationLevel.error;
    }

    // Formatos incorrectos son advertencias, no errores
    if (validator is EmailValidator || validator is PhoneValidator) {
      return ValidationLevel.warning;
    }

    // Longitud incorrecta es advertencia
    if (validator is LengthValidator) {
      return ValidationLevel.warning;
    }

    // Por defecto, información
    return ValidationLevel.info;
  }

  /// 💬 MENSAJES DE ERROR FLEXIBLES
  String _getFlexibleErrorMessage(
      FieldValidator validator, String fieldType, String value) {
    if (validator is RequiredValidator) {
      return 'Campo requerido';
    }

    if (validator is EmailValidator) {
      return 'Formato de email inválido';
    }

    if (validator is PhoneValidator) {
      return 'Formato de teléfono no reconocido';
    }

    if (validator is LengthValidator) {
      return validator.errorMessage;
    }

    if (validator is PostalCodeValidator) {
      return 'Código postal debe tener 5 dígitos';
    }

    return 'Formato inválido';
  }

  /// 💡 SUGERENCIAS FLEXIBLES
  String? _getFlexibleSuggestion(
      FieldValidator validator, String fieldType, String value) {
    if (validator is RequiredValidator) {
      return 'Proporcionar un valor válido';
    }

    if (validator is EmailValidator) {
      return 'Verificar formato: usuario@dominio.com';
    }

    if (validator is PhoneValidator) {
      final cleanPhone = value.replaceAll(RegExp(r'[^\d]'), '');
      if (cleanPhone.length > 10) {
        return 'Intentar: ${cleanPhone.substring(cleanPhone.length - 10)}';
      } else if (cleanPhone.length < 10) {
        return 'Agregar código de área: 55$cleanPhone';
      }
      return 'Formato: 5512345678 o +52 55 1234 5678';
    }

    if (validator is PostalCodeValidator) {
      final cleanCode = value.replaceAll(RegExp(r'[^\d]'), '');
      if (cleanCode.isNotEmpty) {
        return 'Intentar: ${cleanCode.padLeft(5, '0')}';
      }
      return 'Ejemplo: 06700';
    }

    return null;
  }

  // ========================================================================
  // 🌍 VALIDACIONES GLOBALES FLEXIBLES
  // ========================================================================

  /// 🌍 REALIZAR VALIDACIONES GLOBALES MÁS PERMISIVAS
  Future<void> _performFlexibleGlobalValidations(
    List<Map<String, String>> mappedData,
    List<FieldMapping> mappings,
    List<ValidationError> errors,
    List<ValidationError> warnings,
    List<ValidationError> infos,
  ) async {
    // 🔍 VALIDAR DUPLICADOS POR EMAIL (SOLO ADVERTENCIAS)
    if (_hasMappingForField(mappings, 'email')) {
      await _validateDuplicateEmailsFlexible(mappedData, warnings, infos);
    }

    // 🔍 VALIDAR DUPLICADOS POR TELÉFONO (SOLO INFORMACIÓN)
    if (_hasMappingForField(mappings, 'telefono')) {
      await _validateDuplicatePhonesFlexible(mappedData, infos);
    }

    // 📊 VALIDAR DISTRIBUCIÓN DE DATOS (SOLO INFORMACIÓN)
    await _validateDataDistributionFlexible(mappedData, infos);
  }

  bool _hasMappingForField(List<FieldMapping> mappings, String fieldName) {
    return mappings.any((mapping) => mapping.targetField == fieldName);
  }

  /// 📧 VALIDAR EMAILS DUPLICADOS - VERSIÓN FLEXIBLE
  Future<void> _validateDuplicateEmailsFlexible(
    List<Map<String, String>> mappedData,
    List<ValidationError> warnings,
    List<ValidationError> infos,
  ) async {
    final emailCounts = <String, List<int>>{};

    for (int i = 0; i < mappedData.length; i++) {
      final email = mappedData[i]['email']?.trim().toLowerCase() ?? '';
      if (email.isNotEmpty && email.contains('@')) {
        emailCounts.putIfAbsent(email, () => []).add(i);
      }
    }

    for (final entry in emailCounts.entries) {
      if (entry.value.length > 1) {
        for (final rowIndex in entry.value) {
          infos.add(ValidationError(
            rowIndex: rowIndex,
            columnName: 'email',
            originalValue: entry.key,
            level: ValidationLevel.info,
            message: 'Email duplicado en ${entry.value.length} registros',
            suggestedFix: 'Verificar si son clientes diferentes',
          ));
        }
      }
    }
  }

  /// 📱 VALIDAR TELÉFONOS DUPLICADOS - VERSIÓN FLEXIBLE
  Future<void> _validateDuplicatePhonesFlexible(
    List<Map<String, String>> mappedData,
    List<ValidationError> infos,
  ) async {
    final phoneCounts = <String, List<int>>{};

    for (int i = 0; i < mappedData.length; i++) {
      final phone = _normalizePhoneFlexible(mappedData[i]['telefono'] ?? '');
      if (phone.isNotEmpty) {
        phoneCounts.putIfAbsent(phone, () => []).add(i);
      }
    }

    for (final entry in phoneCounts.entries) {
      if (entry.value.length > 1) {
        for (final rowIndex in entry.value) {
          infos.add(ValidationError(
            rowIndex: rowIndex,
            columnName: 'telefono',
            originalValue: entry.key,
            level: ValidationLevel.info,
            message: 'Teléfono similar en ${entry.value.length} registros',
            suggestedFix: 'Verificar si pertenecen a la misma persona',
          ));
        }
      }
    }
  }

  /// 📱 NORMALIZAR TELÉFONO FLEXIBLE
  String _normalizePhoneFlexible(String phone) {
    final digits = phone.replaceAll(RegExp(r'[^\d]'), '');

    // Manejar formato mexicano
    if (digits.startsWith('52') && digits.length == 12) {
      return digits.substring(2); // Remover código de país
    } else if (digits.startsWith('152') && digits.length == 13) {
      return digits.substring(3); // Remover 1+52
    } else if (digits.length == 10) {
      return digits;
    } else if (digits.length == 8) {
      return '55$digits'; // Asumir CDMX para números de 8 dígitos
    }

    return digits;
  }

  /// 📊 VALIDAR DISTRIBUCIÓN DE DATOS - VERSIÓN FLEXIBLE
  Future<void> _validateDataDistributionFlexible(
    List<Map<String, String>> mappedData,
    List<ValidationError> infos,
  ) async {
    if (mappedData.isEmpty) return;

    final fieldCompleteness = <String, double>{};

    for (final field in mappedData.first.keys) {
      final nonEmptyCount = mappedData
          .where((row) => (row[field] ?? '').trim().isNotEmpty)
          .length;

      fieldCompleteness[field] = (nonEmptyCount / mappedData.length) * 100;
    }

    // Solo reportar campos con muy baja completitud
    for (final entry in fieldCompleteness.entries) {
      if (entry.value < 30.0) {
        // Umbral más bajo
        infos.add(ValidationError(
          rowIndex: -1,
          columnName: entry.key,
          originalValue: '',
          level: ValidationLevel.info,
          message:
              'Campo "${entry.key}" tiene solo ${entry.value.toStringAsFixed(1)}% de datos',
          suggestedFix: 'Campo opcional con pocos datos - es normal',
        ));
      }
    }

    infos.add(ValidationError(
      rowIndex: -1,
      columnName: 'General',
      originalValue: '',
      level: ValidationLevel.info,
      message: 'Validación flexible: ${mappedData.length} registros procesados',
    ));
  }

  // ========================================================================
  // 🎯 MÉTODOS DE UTILIDAD PÚBLICA (MANTENIDOS)
  // ========================================================================

  Future<List<ValidationError>> validateSingleRow(
    Map<String, String> rowData,
    List<FieldMapping> mappings,
    int rowIndex,
  ) async {
    final errors = <ValidationError>[];

    for (final mapping in mappings) {
      final value = rowData[mapping.targetField] ?? '';
      errors.addAll(_validateFieldFlexible(value, mapping, rowIndex));
    }

    return errors;
  }

  Map<String, dynamic> getValidationStatistics(ValidationResult result) {
    if (result.totalRows == 0) return {};

    return {
      'totalRows': result.totalRows,
      'validRows': result.validRows,
      'errorRows': result.errors.map((e) => e.rowIndex).toSet().length,
      'warningRows': result.warnings.map((e) => e.rowIndex).toSet().length,
      'successRate': result.successRate,
      'totalErrors': result.errors.length,
      'totalWarnings': result.warnings.length,
      'totalInfos': result.infos.length,
      'canProceed': result.canProceed,
      'validatedAt': result.validatedAt.toIso8601String(),
      'validationMode': 'flexible', // Indicar que usa validación flexible
    };
  }

  Map<String, List<ValidationError>> groupErrorsByType(
      ValidationResult result) {
    final grouped = <String, List<ValidationError>>{};

    for (final error in result.errors) {
      final key = '${error.columnName}: ${error.message}';
      grouped.putIfAbsent(key, () => []).add(error);
    }

    for (final warning in result.warnings) {
      final key = '${warning.columnName}: ${warning.message}';
      grouped.putIfAbsent(key, () => []).add(warning);
    }

    return grouped;
  }

  List<MapEntry<String, int>> getMostFrequentErrors(ValidationResult result,
      {int limit = 10}) {
    final errorCounts = <String, int>{};

    for (final error in [...result.errors, ...result.warnings]) {
      final key = error.message;
      errorCounts[key] = (errorCounts[key] ?? 0) + 1;
    }

    final sortedErrors = errorCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return sortedErrors.take(limit).toList();
  }

  void dispose() {
    debugPrint('🧹 DataValidatorService (flexible) disposed');
  }
}
