// [import_validation_section.dart] - VALIDACIÓN EN TIEMPO REAL DURANTE MAPEO - REFACTOR COMPACTO
// 📁 Ubicación: /lib/widgets/clients/import/import_validation_section.dart
// 🎯 OBJETIVO: Validación proactiva compacta con preview de errores y sugerencias

import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'import_models.dart';
import 'data_validator_service.dart';

/// ✅ SECCIÓN DE VALIDACIÓN EN TIEMPO REAL COMPACTA
class ImportValidationSection extends StatefulWidget {
  final List<List<String>> sampleData;
  final List<FieldMapping> mappings;
  final Function(ValidationResult)? onValidationChanged;
  final bool isValidating;

  const ImportValidationSection({
    super.key,
    required this.sampleData,
    required this.mappings,
    this.onValidationChanged,
    this.isValidating = false,
  });

  @override
  State<ImportValidationSection> createState() =>
      _ImportValidationSectionState();
}

class _ImportValidationSectionState extends State<ImportValidationSection>
    with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  final DataValidatorService _validator = DataValidatorService();
  ValidationResult? _currentValidation;
  bool _isValidating = false;
  bool _showDetails = true;

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );

    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.1,
    ).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    ));

    // Validar inmediatamente si hay datos
    if (widget.sampleData.isNotEmpty && widget.mappings.isNotEmpty) {
      _performValidation();
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(ImportValidationSection oldWidget) {
    super.didUpdateWidget(oldWidget);

    // Re-validar si cambió el mapeo
    if (oldWidget.mappings != widget.mappings) {
      _performValidation();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(
          left: 12, right: 16, top: 8, bottom: 8), // ← PADDING INTERNO AGREGADO
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildCompactHeader(),
          const SizedBox(height: 12),
          if (_isValidating)
            _buildCompactValidatingIndicator()
          else if (_currentValidation != null)
            Expanded(child: _buildCompactValidationResults())
          else
            _buildCompactNoValidationState(),
        ],
      ),
    );
  }

  // ========================================================================
  // 🎨 COMPONENTES COMPACTOS
  // ========================================================================

  /// 🎨 HEADER COMPACTO
  Widget _buildCompactHeader() {
    return Container(
      height: 44, // ← ALTURA REDUCIDA
      child: Row(
        children: [
          // ÍCONO Y TÍTULO COMPACTOS
          Icon(
            Icons.verified_user,
            color: _getHeaderColor(),
            size: 16, // ← ÍCONO MÁS PEQUEÑO
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              'Validación en Tiempo Real',
              style: TextStyle(
                fontSize: 14, // ← TEXTO MÁS PEQUEÑO
                fontWeight: FontWeight.w600,
                color: _getHeaderColor(),
                fontFamily: kFontFamily,
              ),
            ),
          ),

          // TOGGLE DETALLES
          IconButton(
            onPressed: () => setState(() => _showDetails = !_showDetails),
            icon: Icon(
              _showDetails
                  ? Icons.keyboard_arrow_up
                  : Icons.keyboard_arrow_down,
              size: 16,
              color: kTextSecondary,
            ),
            tooltip: _showDetails ? 'Ocultar detalles' : 'Mostrar detalles',
            padding: const EdgeInsets.all(4),
            constraints: const BoxConstraints(minWidth: 24, minHeight: 24),
          ),

          // BADGE COMPACTO
          if (_currentValidation != null) _buildCompactValidationBadge(),
        ],
      ),
    );
  }

  /// 🏷️ BADGE COMPACTO DE ESTADO
  Widget _buildCompactValidationBadge() {
    final validation = _currentValidation!;
    Color badgeColor;
    String badgeText;
    IconData badgeIcon;

    if (!validation.hasErrors && !validation.hasWarnings) {
      badgeColor = kAccentGreen;
      badgeText = '✓';
      badgeIcon = Icons.check_circle;
    } else if (validation.hasErrors) {
      badgeColor = kErrorColor;
      badgeText = '${validation.errors.length}';
      badgeIcon = Icons.error;
    } else {
      badgeColor = kWarningColor;
      badgeText = '${validation.warnings.length}';
      badgeIcon = Icons.warning;
    }

    return Container(
      width: 28,
      height: 28,
      decoration: BoxDecoration(
        color: badgeColor.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: badgeColor.withValues(alpha: 0.3), width: 1),
      ),
      child: Center(
        child: Text(
          badgeText,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.bold,
            color: badgeColor,
            fontFamily: kFontFamily,
          ),
        ),
      ),
    );
  }

  /// ⏳ INDICADOR COMPACTO DE VALIDACIÓN
  Widget _buildCompactValidatingIndicator() {
    return Container(
      height: 80, // ← ALTURA FIJA COMPACTA
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedBuilder(
              animation: _pulseAnimation,
              builder: (context, child) {
                return Transform.scale(
                  scale: _pulseAnimation.value,
                  child: Container(
                    width: 36, // ← MÁS PEQUEÑO
                    height: 36,
                    decoration: BoxDecoration(
                      color: kBrandPurple.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: const Center(
                      child: SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          valueColor:
                              AlwaysStoppedAnimation<Color>(kBrandPurple),
                          strokeWidth: 2,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 8),
            Text(
              'Validando...',
              style: TextStyle(
                fontSize: 12, // ← TEXTO MÁS PEQUEÑO
                color: kTextSecondary,
                fontFamily: kFontFamily,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// ❌ ESTADO SIN VALIDACIÓN COMPACTO
  Widget _buildCompactNoValidationState() {
    return Container(
      height: 120, // ← ALTURA FIJA COMPACTA
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.pending_actions,
              color: kTextMuted,
              size: 32, // ← ÍCONO MÁS PEQUEÑO
            ),
            const SizedBox(height: 8),
            Text(
              'Mapea campos para\nver validación',
              style: TextStyle(
                fontSize: 12,
                color: kTextMuted,
                fontFamily: kFontFamily,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  /// 📊 RESULTADOS COMPACTOS DE VALIDACIÓN
  Widget _buildCompactValidationResults() {
    final validation = _currentValidation!;

    return Column(
      children: [
        // RESUMEN ULTRA-COMPACTO
        _buildUltraCompactSummary(validation),

        const SizedBox(height: 12),

        // DETALLES CONDICIONALES
        if (_showDetails)
          Expanded(child: _buildCompactValidationDetails(validation))
        else
          _buildCollapsedSummary(validation),
      ],
    );
  }

  /// 📊 RESUMEN ULTRA-COMPACTO
  Widget _buildUltraCompactSummary(ValidationResult validation) {
    return Container(
      padding: const EdgeInsets.all(10), // ← PADDING REDUCIDO
      decoration: BoxDecoration(
        color: _getValidationSummaryColor().withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
            color: _getValidationSummaryColor().withValues(alpha: 0.15)),
      ),
      child: Column(
        children: [
          // MÉTRICAS EN FILA COMPACTA
          Row(
            children: [
              Expanded(
                  child: _buildMiniSummaryCard(
                      'Válidas',
                      '${validation.validRows}',
                      kAccentGreen,
                      Icons.check_circle)),
              const SizedBox(width: 6),
              Expanded(
                  child: _buildMiniSummaryCard('Errores',
                      '${validation.errorRows}', kErrorColor, Icons.error)),
              const SizedBox(width: 6),
              Expanded(
                  child: _buildMiniSummaryCard(
                      'Avisos',
                      '${validation.warningRows}',
                      kWarningColor,
                      Icons.warning)),
            ],
          ),

          const SizedBox(height: 8),

          // PROGRESS BAR COMPACTO
          Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Éxito',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: kTextSecondary,
                      fontFamily: kFontFamily,
                    ),
                  ),
                  Text(
                    '${validation.successRate.toStringAsFixed(1)}%',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: _getSuccessRateColor(validation.successRate),
                      fontFamily: kFontFamily,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              LinearProgressIndicator(
                value: validation.successRate / 100,
                backgroundColor: Colors.grey.shade200,
                valueColor: AlwaysStoppedAnimation<Color>(
                    _getSuccessRateColor(validation.successRate)),
                minHeight: 3,
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// 📊 MINI CARD DE RESUMEN
  Widget _buildMiniSummaryCard(
      String label, String value, Color color, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(6), // ← PADDING MÍNIMO
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 14), // ← ÍCONO PEQUEÑO
          const SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: color,
              fontFamily: kFontFamily,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: 9, // ← TEXTO MUY PEQUEÑO
              color: color,
              fontFamily: kFontFamily,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  /// 📋 RESUMEN COLAPSADO
  Widget _buildCollapsedSummary(ValidationResult validation) {
    if (validation.hasErrors || validation.hasWarnings) {
      final issueCount = validation.errors.length + validation.warnings.length;
      return Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: (validation.hasErrors ? kErrorColor : kWarningColor)
              .withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
              color: (validation.hasErrors ? kErrorColor : kWarningColor)
                  .withValues(alpha: 0.2)),
        ),
        child: Row(
          children: [
            Icon(
              validation.hasErrors ? Icons.error : Icons.warning,
              color: validation.hasErrors ? kErrorColor : kWarningColor,
              size: 14,
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                '$issueCount ${validation.hasErrors ? "errores" : "advertencias"} encontrados',
                style: TextStyle(
                  fontSize: 11,
                  color: validation.hasErrors ? kErrorColor : kWarningColor,
                  fontFamily: kFontFamily,
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: kAccentGreen.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: kAccentGreen.withValues(alpha: 0.2)),
      ),
      child: Row(
        children: [
          const Icon(Icons.check_circle, color: kAccentGreen, size: 14),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              'Todos los datos son válidos',
              style: TextStyle(
                fontSize: 11,
                color: kAccentGreen,
                fontFamily: kFontFamily,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// 📋 DETALLES COMPACTOS DE VALIDACIÓN
  Widget _buildCompactValidationDetails(ValidationResult validation) {
    final allIssues = [
      ...validation.errors,
      ...validation.warnings,
      ...validation.infos,
    ];

    if (allIssues.isEmpty) {
      return _buildCompactNoIssuesFound();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // HEADER DE DETALLES COMPACTO
        Text(
          'Detalles (${allIssues.length})',
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: kTextSecondary,
            fontFamily: kFontFamily,
          ),
        ),
        const SizedBox(height: 6),

        // LISTA COMPACTA DE ISSUES
        Expanded(
          child: ListView.builder(
            itemCount: allIssues.length,
            itemBuilder: (context, index) {
              final issue = allIssues[index];
              return _buildCompactValidationIssueCard(issue);
            },
          ),
        ),
      ],
    );
  }

  /// ✅ NO HAY PROBLEMAS - VERSIÓN COMPACTA
  Widget _buildCompactNoIssuesFound() {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 48, // ← MÁS PEQUEÑO
              height: 48,
              decoration: BoxDecoration(
                color: kAccentGreen.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Icon(Icons.verified, color: kAccentGreen, size: 24),
            ),
            const SizedBox(height: 12),
            Text(
              'Excelente!',
              style: TextStyle(
                fontSize: 16, // ← MÁS PEQUEÑO
                fontWeight: FontWeight.bold,
                color: kAccentGreen,
                fontFamily: kFontFamily,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Datos válidos',
              style: TextStyle(
                fontSize: 12,
                color: kTextSecondary,
                fontFamily: kFontFamily,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  /// 🔍 CARD COMPACTO DE PROBLEMA
  Widget _buildCompactValidationIssueCard(ValidationError issue) {
    Color cardColor;
    IconData cardIcon;

    switch (issue.level) {
      case ValidationLevel.error:
        cardColor = kErrorColor;
        cardIcon = Icons.error;
        break;
      case ValidationLevel.warning:
        cardColor = kWarningColor;
        cardIcon = Icons.warning;
        break;
      case ValidationLevel.info:
        cardColor = kAccentBlue;
        cardIcon = Icons.info;
        break;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 6), // ← MARGIN REDUCIDO
      padding: const EdgeInsets.all(8), // ← PADDING REDUCIDO
      decoration: BoxDecoration(
        color: cardColor.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: cardColor.withValues(alpha: 0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // HEADER COMPACTO
          Row(
            children: [
              Icon(cardIcon, color: cardColor, size: 12), // ← ÍCONO MÁS PEQUEÑO
              const SizedBox(width: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                decoration: BoxDecoration(
                  color: cardColor.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(3),
                ),
                child: Text(
                  issue.rowIndex >= 0 ? 'F${issue.displayRowNumber}' : 'Gen',
                  style: TextStyle(
                    fontSize: 9, // ← TEXTO MUY PEQUEÑO
                    fontWeight: FontWeight.w600,
                    color: cardColor,
                    fontFamily: kFontFamily,
                  ),
                ),
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  issue.columnName,
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                    color: cardColor,
                    fontFamily: kFontFamily,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),

          const SizedBox(height: 4),

          // MENSAJE PRINCIPAL
          Text(
            issue.message,
            style: TextStyle(
              fontSize: 11, // ← TEXTO MÁS PEQUEÑO
              color: cardColor,
              fontFamily: kFontFamily,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),

          // VALOR ORIGINAL (SI EXISTE)
          if (issue.originalValue.isNotEmpty) ...[
            const SizedBox(height: 2),
            Text(
              'Valor: "${issue.originalValue.length > 20 ? "${issue.originalValue.substring(0, 20)}..." : issue.originalValue}"',
              style: TextStyle(
                fontSize: 9,
                color: cardColor.withValues(alpha: 0.7),
                fontFamily: kFontFamily,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],

          // SUGERENCIA (SI EXISTE)
          if (issue.suggestedFix != null) ...[
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: cardColor.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Row(
                children: [
                  Icon(Icons.lightbulb_outline, color: cardColor, size: 10),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      issue.suggestedFix!,
                      style: TextStyle(
                        fontSize: 9,
                        color: cardColor,
                        fontFamily: kFontFamily,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ========================================================================
  // 🔧 LÓGICA DE VALIDACIÓN (MANTENIDA)
  // ========================================================================

  /// ✅ REALIZAR VALIDACIÓN
  Future<void> _performValidation() async {
    if (widget.sampleData.isEmpty || widget.mappings.isEmpty) {
      setState(() {
        _currentValidation = null;
      });
      return;
    }

    final activeMappings =
        widget.mappings.where((m) => m.sourceColumn.isNotEmpty).toList();

    if (activeMappings.isEmpty) {
      setState(() {
        _currentValidation = null;
      });
      return;
    }

    setState(() {
      _isValidating = true;
    });

    _pulseController.repeat(reverse: true);

    try {
      final result = await _validator.validateData(
        widget.sampleData,
        activeMappings,
      );

      if (mounted) {
        setState(() {
          _currentValidation = result;
          _isValidating = false;
        });

        _pulseController.stop();
        _pulseController.reset();

        widget.onValidationChanged?.call(result);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isValidating = false;
        });

        _pulseController.stop();
        _pulseController.reset();

        debugPrint('Error en validación: $e');
      }
    }
  }

  // ========================================================================
  // 🎨 HELPERS DE COLORES (MANTENIDOS)
  // ========================================================================

  Color _getHeaderColor() {
    if (_currentValidation == null) return kTextSecondary;

    if (_currentValidation!.hasErrors) return kErrorColor;
    if (_currentValidation!.hasWarnings) return kWarningColor;
    return kAccentGreen;
  }

  Color _getValidationSummaryColor() {
    if (_currentValidation == null) return kTextSecondary;

    if (_currentValidation!.hasErrors) return kErrorColor;
    if (_currentValidation!.hasWarnings) return kWarningColor;
    return kAccentGreen;
  }

  Color _getSuccessRateColor(double successRate) {
    if (successRate >= 90) return kAccentGreen;
    if (successRate >= 70) return kWarningColor;
    return kErrorColor;
  }
}
