// [clients_list_section.dart] - SECCIÓN DE LISTA DE CLIENTES - CORREGIDA
// 📁 Ubicación: /lib/screens/clients/widgets/clients_list_section.dart
// 🎯 OBJETIVO: Widget para lista de clientes + bulk toolbar

import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/models/clients/client_model.dart';
import 'package:agenda_fisio_spa_kym/enums/view_mode.dart';
import 'package:agenda_fisio_spa_kym/widgets/clients/client_card_factory.dart';
import 'package:agenda_fisio_spa_kym/widgets/clients/clients_bulk_toolbar.dart';

/// 📋 SECCIÓN DE LISTA - EXTRAÍDA DEL SCREEN PRINCIPAL
class ClientsListSection extends StatelessWidget {
  final List<ClientModel> clients;
  final List<ClientModel>? allClients; // ✅ OPCIONAL
  final List<ClientModel>? filteredClients; // ✅ OPCIONAL
  final Set<String> selectedClients;
  final int totalFilteredClients;
  final ViewMode currentViewMode;
  final String? tableSortColumn;
  final bool tableSortAscending;
  final Function(String) onClientSelect;
  final Function(ClientModel) onClientEdit;
  final Function(String) onClientDelete;
  final Function(ClientModel) onClientPreview;
  final Function(String) onTableSort;
  final Function(List<String>) onBulkDelete;
  final Function(List<String>, List<ClientTag>) onBulkAddTags;
  final Function(List<String>) onBulkExport;
  final VoidCallback onClearSelection;
  final VoidCallback onSelectAll;
  final Animation<double> cardsAnimation;
  final Animation<double> viewModeTransition;

  const ClientsListSection({
    super.key,
    required this.clients,
    this.allClients, // ✅ OPCIONAL
    this.filteredClients, // ✅ OPCIONAL
    required this.selectedClients,
    required this.totalFilteredClients,
    required this.currentViewMode,
    required this.tableSortColumn,
    required this.tableSortAscending,
    required this.onClientSelect,
    required this.onClientEdit,
    required this.onClientDelete,
    required this.onClientPreview,
    required this.onTableSort,
    required this.onBulkDelete,
    required this.onBulkAddTags,
    required this.onBulkExport,
    required this.onClearSelection,
    required this.onSelectAll,
    required this.cardsAnimation,
    required this.viewModeTransition,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // BULK TOOLBAR
        _buildBulkToolbar(),

        // CLIENTS LIST
        _buildClientsList(),
      ],
    );
  }

  // ====================================================================
  // 🔧 BULK TOOLBAR (CORREGIDO)
  // ====================================================================

  Widget _buildBulkToolbar() {
    return ClientsBulkToolbar(
      selectedClients: selectedClients,
      allClients: allClients ?? clients,
      filteredClients: filteredClients ?? clients, // ✅ AGREGADO
      totalFilteredClients: totalFilteredClients,
      onSelectAll: onSelectAll,
      onBulkDelete: onBulkDelete,
      onBulkAddTags: onBulkAddTags,
      onBulkExport: onBulkExport,
      onClearSelection: onClearSelection,
    );
  }

  // ====================================================================
  // 📋 CLIENTS LIST (COPIADO EXACTO)
  // ====================================================================

  Widget _buildClientsList() {
    return AnimatedBuilder(
      animation: cardsAnimation,
      builder: (context, child) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 30, 20, 20),
          child: Column(
            children: [
              // HEADER DE TABLA SI ES NECESARIO
              if (currentViewMode == ViewMode.table)
                _buildTableHeaderIfNeeded(),

              // LISTA DE CLIENTES
              ...clients.asMap().entries.map((entry) {
                final index = entry.key;
                final client = entry.value;

                return Center(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      maxWidth: currentViewMode == ViewMode.table ? 1200 : 800,
                    ),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: AnimatedBuilder(
                        animation: viewModeTransition,
                        builder: (context, child) {
                          return Opacity(
                            opacity: viewModeTransition.value,
                            child: Transform.translate(
                              offset: Offset(
                                  0, 20 * (1 - viewModeTransition.value)),
                              child: _buildClientCard(client, index),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                );
              }).toList(),
            ],
          ),
        );
      },
    );
  }

  // ====================================================================
  // 🏗️ TABLE HEADER (COPIADO EXACTO)
  // ====================================================================

  Widget _buildTableHeaderIfNeeded() {
    if (currentViewMode != ViewMode.table) {
      return const SizedBox.shrink();
    }

    return ClientCardFactory.buildTableHeader(
      showSortIndicators: true,
      sortColumn: tableSortColumn,
      sortAscending: tableSortAscending,
      onSort: onTableSort,
    );
  }

  // ====================================================================
  // 🎯 CLIENT CARD BUILDER (COPIADO EXACTO)
  // ====================================================================

  Widget _buildClientCard(ClientModel client, int index) {
    final isSelected = selectedClients.contains(client.clientId);

    // Parámetros adicionales según el modo
    Map<String, dynamic>? additionalParams;
    if (currentViewMode == ViewMode.table) {
      additionalParams = {
        'isEvenRow': index % 2 == 0,
      };
    }

    return ClientCardFactory.buildCard(
      viewMode: currentViewMode,
      client: client,
      isSelected: isSelected,
      onSelect: () => onClientSelect(client.clientId),
      onEdit: () => onClientEdit(client),
      onDelete: () => onClientDelete(client.clientId),
      onQuickPreview: () => onClientPreview(client),
      enableCache: true,
      enableHoverEffects: currentViewMode != ViewMode.table,
      additionalParams: additionalParams,
    );
  }
}
