// [clients_premium_screen.dart] - ARCHIVO PRINCIPAL CON EXPORTACIÓN INTEGRADA
// 📁 Ubicación: /lib/screens/clients/clients_premium_screen.dart
// 🎯 OBJETIVO: Screen principal limpio usando componentes modulares + EXPORT INTEGRADO

import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/theme/theme.dart';
import 'package:agenda_fisio_spa_kym/models/clients/client_model.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/services/client_service.dart';
import 'package:agenda_fisio_spa_kym/services/cost_control/background_cost_monitor.dart';
import 'package:agenda_fisio_spa_kym/services/cost_control/cost_data_models.dart';
import 'package:agenda_fisio_spa_kym/enums/view_mode.dart';

// 🏗️ CONTROLLERS
import 'controllers/clients_screen_controller.dart';
import 'controllers/clients_animation_controller.dart';

// 🎨 WIDGETS MODULARES
import 'widgets/clients_header_section.dart';
import 'widgets/clients_search_section.dart';
import 'widgets/clients_list_section.dart';
import 'widgets/clients_fab_section.dart';

// 🎯 MIXINS
import 'mixins/clients_handlers_mixin.dart';
import 'mixins/clients_dialogs_mixin.dart';
import 'mixins/clients_snackbars_mixin.dart';

/// 🏢 PANTALLA PRINCIPAL ENTERPRISE DE CLIENTES - CON EXPORTACIÓN INTEGRADA
class ClientsPremiumScreen extends StatefulWidget {
  const ClientsPremiumScreen({super.key});

  @override
  State<ClientsPremiumScreen> createState() => _ClientsPremiumScreenState();
}

class _ClientsPremiumScreenState extends State<ClientsPremiumScreen>
    with
        TickerProviderStateMixin,
        ClientsHandlersMixin,
        ClientsDialogsMixin,
        ClientsSnackbarsMixin {
  // ✅ CONTROLLERS
  late ClientsScreenController _screenController;
  late ClientsAnimationController _animationController;

  // ✅ SERVICIOS
  final ClientService _clientService = ClientService();
  final BackgroundCostMonitor _costMonitor = BackgroundCostMonitor();

  // ====================================================================
  // 🚀 LIFECYCLE
  // ====================================================================

  @override
  void initState() {
    super.initState();
    _initializeControllers();
    _setupListeners();
    _initializeServices();
  }

  void _initializeControllers() {
    _screenController = ClientsScreenController();
    _animationController = ClientsAnimationController(vsync: this);
  }

  void _setupListeners() {
    // Listener para búsqueda con debounce
    _screenController.searchController
        .addListener(_screenController.onSearchChanged);

    // Listener para scroll infinito
    _screenController.scrollController.addListener(_screenController.onScroll);

    // Listener para cambios de estado
    _screenController.addListener(_onScreenControllerChanged);
  }

  Future<void> _initializeServices() async {
    try {
      // Inicializar servicios en controllers
      await _screenController.initializeServices();
      await _screenController.loadUserViewMode();

      // Iniciar animaciones cuando esté listo
      if (_screenController.isInitialized) {
        _animationController.startAnimations();
      }
    } catch (e) {
      showErrorSnackBar('Error inicializando: $e');
    }
  }

  void _onScreenControllerChanged() {
    // Reaccionar a cambios en el controller si es necesario
    if (mounted) {
      setState(() {});
    }
  }

  @override
  void dispose() {
    _screenController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  // ====================================================================
  // 🎨 UI BUILD
  // ====================================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      body: _buildBody(),
      floatingActionButton: _buildFloatingActionButton(),
    );
  }

  Widget _buildBody() {
    if (!_screenController.isInitialized) {
      return _buildLoadingScreen();
    }

    return CustomScrollView(
      controller: _screenController.scrollController,
      slivers: [
        // 🌀 HEADER CON MANDALA + DASHBOARD
        SliverToBoxAdapter(
          child: ClientsHeaderSection(
            analytics: _screenController.analytics,
            totalClients: _screenController.allClients.length,
            filteredClients: _screenController.filteredClients.length,
            selectedClients: _screenController.selectedClients.length,
            onRefresh: _handleRefreshAnalytics,
            onForceRefresh: _handleForceRefresh,
            headerAnimation: _animationController.headerAnimation,
            costMonitor: _costMonitor,
          ),
        ),

        // 🔍 BÚSQUEDA Y CONTROLES - ✅ CON EXPORTACIÓN INTEGRADA
        SliverToBoxAdapter(
          child: ClientsSearchSection(
            searchController: _screenController.searchController,
            currentViewMode: _screenController.currentViewMode,
            isSearching: _screenController.isSearching,
            sortOption: _screenController.sortOption,
            currentFilter: _screenController.currentFilter,
            // ✅ NUEVOS PARÁMETROS PARA EXPORTACIÓN
            allClients: _screenController.allClients,
            filteredClients: _screenController.filteredClients,
            selectedClients: _screenController.selectedClients,
            searchQuery: _screenController.searchController.text,
            onViewModeChanged: _handleViewModeChanged,
            onClearSearch: _handleClearSearch,
            onSort: _handleSort,
            onToggleFilters: _handleToggleFilters,
            onAction: _handleAction,
            cardsAnimation: _animationController.cardsAnimation,
            // ✅ CALLBACK DE EXPORTACIÓN COMPLETADA
            onExportCompleted: () {
              showSuccessSnackBar('Exportación completada exitosamente');
            },
          ),
        ),

        // 📋 LISTA DE CLIENTES - ✅ CON EXPORTACIÓN INTEGRADA
        SliverToBoxAdapter(
          child: ClientsListSection(
            clients: _screenController.getDisplayedClients(),
            // ✅ NUEVOS PARÁMETROS REQUERIDOS
            allClients: _screenController.allClients,
            filteredClients: _screenController.filteredClients,
            selectedClients: _screenController.selectedClients,
            totalFilteredClients: _screenController.filteredClients.length,
            currentViewMode: _screenController.currentViewMode,
            tableSortColumn: _screenController.tableSortColumn,
            tableSortAscending: _screenController.tableSortAscending,
            onClientSelect: _handleClientSelect,
            onClientEdit: _handleClientEdit,
            onClientDelete: _handleClientDelete,
            onClientPreview: _handleClientPreview,
            onTableSort: _screenController.handleTableSort,
            onBulkDelete: _handleBulkDelete,
            onBulkAddTags: _handleBulkAddTags,
            onBulkExport: _handleBulkExport,
            onClearSelection: _handleClearSelection,
            onSelectAll: _handleSelectAll,
            cardsAnimation: _animationController.cardsAnimation,
            viewModeTransition: _animationController.viewModeTransition,
          ),
        ),
      ],
    );
  }

  Widget _buildLoadingScreen() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(kBrandPurple),
            strokeWidth: 3,
          ),
          SizedBox(height: 16),
          Text(
            'Cargando clientes...',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: kTextSecondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFloatingActionButton() {
    return ClientsFabSection(
      onPressed: _handleCreateNewClient,
      fabAnimation: _animationController.fabAnimation,
    );
  }

  // ====================================================================
  // 🎯 EVENT HANDLERS (DELEGACIÓN A MIXINS Y CONTROLLERS)
  // ====================================================================

  // 🔄 REFRESH HANDLERS
  Future<void> _handleRefreshAnalytics() async {
    await handleRefreshAnalytics(
      _clientService,
      () => _screenController.handleRefreshAnalytics(),
      showErrorSnackBar,
    );
  }

  Future<void> _handleForceRefresh() async {
    await handleForceRefresh(
      _clientService,
      () => _screenController.handleForceRefresh(),
      showErrorSnackBar,
      _checkCostLimits,
    );
  }

  // 🎨 VIEW MODE HANDLERS
  Future<void> _handleViewModeChanged(ViewMode newMode) async {
    try {
      await _animationController.startViewModeTransition();
      await _screenController.handleViewModeChanged(newMode);
      await _animationController.completeViewModeTransition();
    } catch (e) {
      showErrorSnackBar('Error cambiando vista: $e');
    }
  }

  // 🔍 SEARCH HANDLERS
  void _handleClearSearch() {
    clearSearch(_screenController.searchController, () {
      _screenController.clearSearch();
    });
  }

  void _handleSort(String sortOption) {
    _screenController.setSortOption(sortOption);
  }

  void _handleToggleFilters() {
    toggleFiltersPanel(
      _screenController.showFiltersPanel,
      _screenController.toggleFiltersPanel,
      _showFiltersBottomSheet,
    );
  }

  // ✅ ACTUALIZADO: _handleAction CON EXPORTACIÓN
  void _handleAction(String action) {
    switch (action) {
      case 'export':
        // Legacy - mostrar desarrollo
        showDevelopmentFeatureSnackBar('Exportación legacy');
        break;
      case 'export_completed': // ✅ NUEVO: Callback desde export widget
        showSuccessSnackBar('Exportación completada exitosamente');
        break;
      case 'import':
        importClients();
        showDevelopmentFeatureSnackBar('Importación');
        break;
      case 'refresh':
        _handleForceRefresh();
        break;
      case 'settings':
        showDevelopmentFeatureSnackBar('Configuración');
        break;
    }
  }

  // 👥 CLIENT HANDLERS
  void _handleClientSelect(String clientId) {
    _screenController.toggleClientSelection(clientId);
  }

  Future<void> _handleClientEdit(ClientModel client) async {
    await editClient(client, () => _screenController.handleForceRefresh());
  }

  Future<void> _handleClientDelete(String clientId) async {
    await deleteClient(
      clientId,
      _screenController.allClients,
      _clientService,
      () => _screenController.handleForceRefresh(),
      showErrorSnackBar,
    );
  }

  void _handleClientPreview(ClientModel client) {
    showClientPreview(client, _screenController.currentViewMode.name);
    showPreviewDevelopmentSnackBar(client.fullName);
  }

  Future<void> _handleCreateNewClient() async {
    await createNewClient(() => _screenController.handleForceRefresh());
  }

  // 📦 BULK HANDLERS
  Future<void> _handleBulkDelete(List<String> clientIds) async {
    await handleBulkDelete(
      clientIds,
      _clientService,
      () => _screenController.handleForceRefresh(),
      showErrorSnackBar,
      _showConfirmDialog,
    );
  }

  Future<void> _handleBulkAddTags(
      List<String> clientIds, List<ClientTag> tags) async {
    await handleBulkAddTags(
      clientIds,
      tags,
      _clientService,
      () => _screenController.handleForceRefresh(),
      showErrorSnackBar,
    );
  }

  // ✅ ACTUALIZADO: _handleBulkExport SIN LÓGICA ESPECÍFICA
  void _handleBulkExport(List<String> clientIds) {
    // El modal de exportación ya maneja todo
    // Solo mostrar mensaje de desarrollo si es necesario
    final selectedClients = _screenController.allClients
        .where((client) => clientIds.contains(client.clientId))
        .toList();

    debugPrint(
        '🎯 Bulk export iniciado para ${selectedClients.length} clientes');
    // El éxito se maneja en el callback onExportCompleted
  }

  void _handleSelectAll() {
    selectAllClients(
      _screenController.filteredClients,
      _screenController.selectedClients,
      () => setState(() {}),
    );
  }

  void _handleClearSelection() {
    clearSelection(_screenController.selectedClients, () => setState(() {}));
  }

  // ====================================================================
  // 🛠️ HELPER METHODS
  // ====================================================================

  void _showFiltersBottomSheet() {
    showFiltersBottomSheet(
      context,
      _screenController.currentFilter,
      _screenController.getAvailableTags(),
      _screenController.getAvailableAlcaldias(),
      (filter) => _screenController.setCurrentFilter(filter),
      () => _screenController.clearFilter(),
    );
  }

  Future<bool> _showConfirmDialog(String title, String message) async {
    return await showConfirmDialog(title, message);
  }

  void _checkCostLimits() {
    if (_costMonitor.currentStats.dailyReadCount >=
        CostControlConfig.dailyReadLimit) {
      throw Exception('Límite de costos alcanzado. Intente más tarde.');
    }
  }

  // ✅ MÉTODO HELPER PARA MOSTRAR SNACKBAR DE ÉXITO
  void showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: kAccentGreen,
        duration: const Duration(seconds: 3),
      ),
    );
  }
}
