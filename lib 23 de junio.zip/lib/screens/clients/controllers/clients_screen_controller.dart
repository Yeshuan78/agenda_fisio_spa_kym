// [clients_screen_controller.dart] - CONTROLLER PRINCIPAL DE LÓGICA DE NEGOCIO
// 📁 Ubicación: /lib/screens/clients/controllers/clients_screen_controller.dart
// 🎯 OBJETIVO: Extraer toda la lógica de negocio del screen principal

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:agenda_fisio_spa_kym/models/clients/client_model.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/services/client_service.dart';
import 'package:agenda_fisio_spa_kym/screens/clients/utils/client_constants.dart';
import 'package:agenda_fisio_spa_kym/services/cost_control/background_cost_monitor.dart';
import 'package:agenda_fisio_spa_kym/services/cost_control/cost_data_models.dart';
import 'package:agenda_fisio_spa_kym/enums/view_mode.dart';
import 'package:agenda_fisio_spa_kym/services/user_preferences_service.dart';
import 'package:agenda_fisio_spa_kym/widgets/clients/client_card_factory.dart';

/// 🧠 CONTROLLER PRINCIPAL - LÓGICA DE NEGOCIO EXTRAÍDA
class ClientsScreenController extends ChangeNotifier {
  // ✅ CONTROLADORES Y SERVICIOS (COPIADO EXACTO)
  final TextEditingController searchController = TextEditingController();
  final ClientService _clientService = ClientService();
  final BackgroundCostMonitor _costMonitor = BackgroundCostMonitor();
  final ScrollController scrollController = ScrollController();
  final UserPreferencesService _preferencesService = UserPreferencesService.instance;

  // ✅ ESTADO DE LA APLICACIÓN (COPIADO EXACTO)
  List<ClientModel> _allClients = [];
  List<ClientModel> _filteredClients = [];
  final Set<String> _selectedClients = <String>{};
  ClientFilterCriteria _currentFilter = const ClientFilterCriteria();
  ClientAnalytics? _analytics;

  // ✅ ESTADO DE UI (COPIADO EXACTO)
  bool _isSearching = false;
  bool _showFiltersPanel = false;
  bool _isInitialized = false;
  String _sortOption = ClientConstants.SORT_OPTIONS.first;
  int _currentPage = 0;
  String _searchQuery = '';

  // ✅ ESTADO DEL SISTEMA DE VISTAS MÚLTIPLES (COPIADO EXACTO)
  ViewMode _currentViewMode = ViewMode.table; // DEFAULT ENTERPRISE
  String? _tableSortColumn;
  bool _tableSortAscending = true;

  // ✅ CONFIGURACIÓN DE PERFORMANCE (COPIADO EXACTO)
  static const int _pageSize = ClientConstants.CLIENTS_PER_PAGE;

  // ====================================================================
  // 🎯 GETTERS PÚBLICOS (COPIADO EXACTO)
  // ====================================================================

  List<ClientModel> get allClients => List.unmodifiable(_allClients);
  List<ClientModel> get filteredClients => List.unmodifiable(_filteredClients);
  Set<String> get selectedClients => Set.unmodifiable(_selectedClients);
  ClientFilterCriteria get currentFilter => _currentFilter;
  ClientAnalytics? get analytics => _analytics;
  bool get isSearching => _isSearching;
  bool get showFiltersPanel => _showFiltersPanel;
  bool get isInitialized => _isInitialized;
  String get sortOption => _sortOption;
  int get currentPage => _currentPage;
  String get searchQuery => _searchQuery;
  ViewMode get currentViewMode => _currentViewMode;
  String? get tableSortColumn => _tableSortColumn;
  bool get tableSortAscending => _tableSortAscending;

  // ====================================================================
  // 🚀 MÉTODOS DE INICIALIZACIÓN (COPIADO EXACTO)
  // ====================================================================

  Future<void> initializeServices() async {
    debugPrint('🚀 Inicializando ClientsScreenController...');

    try {
      // Inicializar servicios
      await _clientService.initialize();
      await _preferencesService.initialize();

      // Cargar datos iniciales
      await _loadInitialData();

      // Marcar como inicializado
      _isInitialized = true;
      notifyListeners();

      debugPrint('✅ ClientsScreenController inicializado correctamente');
    } catch (e) {
      debugPrint('❌ Error inicializando ClientsScreenController: $e');
      _isInitialized = false;
      notifyListeners();
      rethrow;
    }
  }

  Future<void> _loadInitialData() async {
    debugPrint('📊 Cargando datos iniciales...');

    // Cargar clientes
    final clients = await _clientService.getAllClients();

    // Cargar analytics
    final analytics = await _clientService.getBasicAnalytics();

    _allClients = clients;
    _filteredClients = clients;
    _analytics = analytics;

    _applyCurrentFilters();
    notifyListeners();
  }

  // ✅ CARGAR PREFERENCIA DEL USUARIO (COPIADO EXACTO)
  Future<void> loadUserViewMode() async {
    try {
      final savedMode = await _preferencesService.getViewMode();
      _currentViewMode = savedMode;
      notifyListeners();
      debugPrint('📱 ViewMode cargado: ${savedMode.displayName}');
    } catch (e) {
      debugPrint('❌ Error cargando ViewMode: $e');
      // Usar default si hay error
    }
  }

  // ====================================================================
  // 🔍 MÉTODOS DE BÚSQUEDA Y FILTROS (COPIADO EXACTO)
  // ====================================================================

  void onSearchChanged() {
    final query = searchController.text.trim();
    if (query == _searchQuery) return;

    _searchQuery = query;
    _isSearching = query.isNotEmpty;
    notifyListeners();

    // Debounce de búsqueda
    Future.delayed(ClientConstants.SEARCH_DEBOUNCE, () {
      if (searchController.text.trim() == query) {
        _performSearch(query);
      }
    });
  }

  void _performSearch(String query) {
    debugPrint('🔍 Realizando búsqueda: "$query"');

    final stopwatch = Stopwatch()..start();

    List<ClientModel> results;
    if (query.isEmpty) {
      results = _allClients;
    } else if (query.length < ClientConstants.MIN_SEARCH_CHARS) {
      results = _filteredClients;
    } else {
      results = _allClients.search(query);
    }

    // Aplicar filtros actuales
    if (!_currentFilter.isEmpty) {
      results = results.filterByCriteria(_currentFilter);
    }

    // Aplicar ordenamiento
    results = _applySorting(results);

    _filteredClients = results;
    _currentPage = 0;
    _isSearching = false;
    notifyListeners();

    stopwatch.stop();
    debugPrint('⚡ Búsqueda completada en ${stopwatch.elapsedMilliseconds}ms');

    // Log de performance si está habilitado
    if (ClientConstants.ENABLE_PERFORMANCE_LOGS) {
      if (stopwatch.elapsedMilliseconds > ClientConstants.MAX_SEARCH_TIME_MS) {
        debugPrint('⚠️ Búsqueda lenta detectada: ${stopwatch.elapsedMilliseconds}ms');
      }
    }
  }

  void applyCurrentFilters() {
    debugPrint('🔍 Aplicando filtros...');

    List<ClientModel> filtered = _allClients;

    // Aplicar criterios de filtro
    if (!_currentFilter.isEmpty) {
      filtered = filtered.filterByCriteria(_currentFilter);
    }

    // Aplicar búsqueda si existe
    if (_searchQuery.isNotEmpty) {
      filtered = filtered.search(_searchQuery);
    }

    // Aplicar ordenamiento
    filtered = _applySorting(filtered);

    _filteredClients = filtered;
    _currentPage = 0;
    notifyListeners();
  }

  void _applyCurrentFilters() => applyCurrentFilters();

  // ✅ APLICAR ORDENAMIENTO (COPIADO EXACTO)
  List<ClientModel> _applySorting(List<ClientModel> clients) {
    // Si estamos en modo tabla y hay ordenamiento específico, usarlo
    if (_currentViewMode == ViewMode.table && _tableSortColumn != null) {
      return clients; // Ya aplicado en _applySortingByColumn
    }

    // Usar ordenamiento existente para otros modos
    switch (_sortOption) {
      case 'Nombre A-Z':
        return clients.sortByName();
      case 'Nombre Z-A':
        final sorted = clients.sortByName();
        return sorted.reversed.toList();
      case 'Fecha creación (reciente)':
        return clients.sortByCreatedDate();
      case 'Fecha creación (antigua)':
        final sorted = clients.sortByCreatedDate();
        return sorted.reversed.toList();
      case 'Citas (más)':
        return clients.sortByAppointments();
      case 'Citas (menos)':
        final sorted = clients.sortByAppointments();
        return sorted.reversed.toList();
      case 'Satisfacción (mayor)':
        return clients.sortBySatisfaction();
      case 'Satisfacción (menor)':
        final sorted = clients.sortBySatisfaction();
        return sorted.reversed.toList();
      default:
        return clients;
    }
  }

  // ====================================================================
  // 🎯 MÉTODOS DE VISTA MÚLTIPLE (COPIADO EXACTO)
  // ====================================================================

  Future<void> handleViewModeChanged(ViewMode newMode) async {
    if (_currentViewMode == newMode) return;

    try {
      _currentViewMode = newMode;
      // Reset sorting específico de tabla al cambiar modo
      if (newMode != ViewMode.table) {
        _tableSortColumn = null;
        _tableSortAscending = true;
      }
      notifyListeners();

      // Guardar preferencia
      await _preferencesService.setViewMode(newMode);

      // Limpiar cache del factory para optimizar el cambio
      ClientCardFactory.clearCache();

      // Registrar evento para analytics
      await _preferencesService.recordUsageEvent('view_mode_changed', {
        'newMode': newMode.name,
        'timestamp': DateTime.now().toIso8601String(),
      });

      // Feedback háptico
      HapticFeedback.mediumImpact();

      debugPrint('🎯 ViewMode cambiado a: ${newMode.displayName}');
    } catch (e) {
      debugPrint('❌ Error cambiando ViewMode: $e');
      rethrow;
    }
  }

  // ✅ MANEJAR ORDENAMIENTO EN TABLA (COPIADO EXACTO)
  void handleTableSort(String column) {
    if (_tableSortColumn == column) {
      _tableSortAscending = !_tableSortAscending;
    } else {
      _tableSortColumn = column;
      _tableSortAscending = true;
    }
    notifyListeners();

    // Aplicar ordenamiento
    _applySortingByColumn(column, _tableSortAscending);

    HapticFeedback.lightImpact();
    debugPrint('📊 Tabla ordenada por: $column (${_tableSortAscending ? 'ASC' : 'DESC'})');
  }

  // ✅ APLICAR ORDENAMIENTO POR COLUMNA (COPIADO EXACTO)
  void _applySortingByColumn(String column, bool ascending) {
    List<ClientModel> sorted = List.from(_filteredClients);

    switch (column) {
      case 'name':
        sorted.sort((a, b) => ascending
            ? a.fullName.compareTo(b.fullName)
            : b.fullName.compareTo(a.fullName));
        break;
      case 'email':
        sorted.sort((a, b) => ascending
            ? a.email.compareTo(b.email)
            : b.email.compareTo(a.email));
        break;
      case 'phone':
        sorted.sort((a, b) => ascending
            ? a.phone.compareTo(b.phone)
            : b.phone.compareTo(a.phone));
        break;
      case 'company':
        sorted.sort((a, b) => ascending
            ? a.empresa.compareTo(b.empresa)
            : b.empresa.compareTo(a.empresa));
        break;
      case 'status':
        sorted.sort((a, b) => ascending
            ? a.statusDisplayName.compareTo(b.statusDisplayName)
            : b.statusDisplayName.compareTo(a.statusDisplayName));
        break;
    }

    _filteredClients = sorted;
    notifyListeners();
  }

  // ====================================================================
  // 📊 MÉTODOS DE PAGINACIÓN Y SCROLL (COPIADO EXACTO)
  // ====================================================================

  void onScroll() {
    // Implementar scroll infinito si es necesario
    if (scrollController.position.pixels >=
        scrollController.position.maxScrollExtent - 200) {
      _loadMoreClients();
    }
  }

  void _loadMoreClients() {
    // Implementación de paginación si es necesario
    if ((_currentPage + 1) * _pageSize < _filteredClients.length) {
      _currentPage++;
      notifyListeners();
    }
  }

  List<ClientModel> getDisplayedClients() {
    final endIndex = ((_currentPage + 1) * _pageSize).clamp(0, _filteredClients.length);
    return _filteredClients.sublist(0, endIndex);
  }

  // ====================================================================
  // 🔧 MÉTODOS DE GESTIÓN DE ESTADO (COPIADO EXACTO)
  // ====================================================================

  void setSortOption(String newSortOption) {
    _sortOption = newSortOption;
    applyCurrentFilters();
  }

  void setCurrentFilter(ClientFilterCriteria newFilter) {
    _currentFilter = newFilter;
    applyCurrentFilters();
  }

  void clearFilter() {
    _currentFilter = const ClientFilterCriteria();
    applyCurrentFilters();
  }

  void toggleClientSelection(String clientId) {
    if (_selectedClients.contains(clientId)) {
      _selectedClients.remove(clientId);
    } else {
      _selectedClients.add(clientId);
    }
    notifyListeners();
  }

  void selectAllClients() {
    _selectedClients.addAll(_filteredClients.map((c) => c.clientId));
    notifyListeners();
  }

  void clearSelection() {
    _selectedClients.clear();
    notifyListeners();
  }

  void clearSearch() {
    searchController.clear();
    _searchQuery = '';
    _isSearching = false;
    applyCurrentFilters();
  }

  void toggleFiltersPanel() {
    _showFiltersPanel = !_showFiltersPanel;
    notifyListeners();
  }

  // ====================================================================
  // 📊 MÉTODOS DE REFRESH Y ACTUALIZACIÓN (COPIADO EXACTO)
  // ====================================================================

  Future<void> handleRefreshAnalytics() async {
    try {
      final analytics = await _clientService.getBasicAnalytics();
      _analytics = analytics;
      notifyListeners();
    } catch (e) {
      debugPrint('❌ Error actualizando analytics: $e');
      rethrow;
    }
  }

  Future<void> handleForceRefresh() async {
    if (_costMonitor.currentStats.dailyReadCount >= CostControlConfig.dailyReadLimit) {
      throw Exception('Límite de costos alcanzado. Intente más tarde.');
    }

    try {
      debugPrint('🔄 Forzando actualización completa...');

      // Limpiar cache primero
      await _clientService.clearCache();
      ClientCardFactory.clearCache();

      // Forzar sincronización desde Firestore
      await _clientService.forceSync();

      // Recargar datos locales
      await _loadInitialData();

      debugPrint('✅ Actualización completa exitosa');
    } catch (e) {
      debugPrint('❌ Error actualizando datos: $e');
      rethrow;
    }
  }

  // ====================================================================
  // 🔧 MÉTODOS HELPER (COPIADO EXACTO)
  // ====================================================================

  List<String> getAvailableTags() {
    final tags = <String>{};
    for (final client in _allClients) {
      for (final tag in client.tags) {
        tags.add(tag.label);
      }
    }
    return tags.toList()..sort();
  }

  List<String> getAvailableAlcaldias() {
    final alcaldias = <String>{};
    for (final client in _allClients) {
      final alcaldia = client.addressInfo.alcaldia;
      if (alcaldia.isNotEmpty) {
        alcaldias.add(alcaldia);
      }
    }
    return alcaldias.toList()..sort();
  }

  int getActiveFiltersCount() {
    int count = 0;
    if (_currentFilter.statuses.isNotEmpty) count++;
    if (_currentFilter.tags.isNotEmpty) count++;
    if (_currentFilter.dateRange != null) count++;
    if (_currentFilter.alcaldias.isNotEmpty) count++;
    if (_currentFilter.minAppointments != null) count++;
    return count;
  }

  void logViewModeStats(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final expectedClients = _currentViewMode.getExpectedClientsPerScreen(screenHeight);
    final factoryReport = ClientCardFactory.getPerformanceReport();

    debugPrint('📊 ViewMode Stats:');
    debugPrint('   Current mode: ${_currentViewMode.displayName}');
    debugPrint('   Expected clients per screen: $expectedClients');
    debugPrint('   Actual clients showing: ${getDisplayedClients().length}');
    debugPrint('   Factory performance: $factoryReport');
  }

  // ====================================================================
  // 🗑️ CLEANUP (COPIADO EXACTO)
  // ====================================================================

  @override
  void dispose() {
    searchController.dispose();
    scrollController.dispose();
    super.dispose();
  }
}