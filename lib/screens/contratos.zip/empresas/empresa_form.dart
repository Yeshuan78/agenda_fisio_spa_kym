import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/models/empresa_model.dart';
import 'package:agenda_fisio_spa_kym/services/empresa_service.dart';
import 'package:uuid/uuid.dart';

class EmpresaForm extends StatefulWidget {
  final EmpresaModel? empresaExistente;

  const EmpresaForm({Key? key, this.empresaExistente}) : super(key: key);

  @override
  State<EmpresaForm> createState() => _EmpresaFormState();
}

class _EmpresaFormState extends State<EmpresaForm> {
  final _formKey = GlobalKey<FormState>();
  final _empresaService = EmpresaService();

  late TextEditingController _nombreCtrl;
  late TextEditingController _rfcCtrl;
  late TextEditingController _direccionCtrl;
  late TextEditingController _logoUrlCtrl;
  late TextEditingController _qrUrlCtrl;
  late TextEditingController _observacionesCtrl;

  String _estado = 'activo';

  @override
  void initState() {
    super.initState();
    final empresa = widget.empresaExistente;

    _nombreCtrl = TextEditingController(text: empresa?.nombre ?? '');
    _rfcCtrl = TextEditingController(text: empresa?.rfc ?? '');
    _direccionCtrl = TextEditingController(text: empresa?.direccion ?? '');
    _logoUrlCtrl = TextEditingController(text: empresa?.logoUrl ?? '');
    _qrUrlCtrl = TextEditingController(text: empresa?.qrUrl ?? '');
    _observacionesCtrl =
        TextEditingController(text: empresa?.observaciones ?? '');
    _estado = empresa?.estado ?? 'activo';
  }

  @override
  void dispose() {
    _nombreCtrl.dispose();
    _rfcCtrl.dispose();
    _direccionCtrl.dispose();
    _logoUrlCtrl.dispose();
    _qrUrlCtrl.dispose();
    _observacionesCtrl.dispose();
    super.dispose();
  }

  Future<void> _guardarEmpresa() async {
    if (!_formKey.currentState!.validate()) return;

    final nuevaEmpresa = EmpresaModel(
      id: widget.empresaExistente?.id ?? const Uuid().v4(),
      nombre: _nombreCtrl.text.trim(),
      rfc: _rfcCtrl.text.trim(),
      direccion: _direccionCtrl.text.trim(),
      contactos: widget.empresaExistente?.contactos ?? [],
      estado: _estado,
      logoUrl: _logoUrlCtrl.text.trim(),
      fechaAlta: widget.empresaExistente?.fechaAlta ?? DateTime.now(),
      qrUrl: _qrUrlCtrl.text.trim(),
      observaciones: _observacionesCtrl.text.trim(),
    );

    if (widget.empresaExistente == null) {
      await _empresaService.crearEmpresa(nuevaEmpresa);
    } else {
      await _empresaService.actualizarEmpresa(nuevaEmpresa);
    }

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.empresaExistente == null
            ? 'Nueva Empresa'
            : 'Editar Empresa'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _nombreCtrl,
                decoration: const InputDecoration(labelText: 'Nombre'),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Campo requerido' : null,
              ),
              TextFormField(
                controller: _rfcCtrl,
                decoration: const InputDecoration(labelText: 'RFC'),
              ),
              TextFormField(
                controller: _direccionCtrl,
                decoration: const InputDecoration(labelText: 'Dirección'),
              ),
              TextFormField(
                controller: _logoUrlCtrl,
                decoration: const InputDecoration(labelText: 'Logo URL'),
              ),
              TextFormField(
                controller: _qrUrlCtrl,
                decoration: const InputDecoration(labelText: 'QR URL'),
              ),
              TextFormField(
                controller: _observacionesCtrl,
                decoration: const InputDecoration(labelText: 'Observaciones'),
                maxLines: 3,
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _estado,
                items: ['activo', 'suspendido', 'eliminado'].map((estado) {
                  return DropdownMenuItem(value: estado, child: Text(estado));
                }).toList(),
                onChanged: (valor) =>
                    setState(() => _estado = valor ?? 'activo'),
                decoration: const InputDecoration(labelText: 'Estado'),
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                icon: const Icon(Icons.save),
                label: const Text('Guardar'),
                onPressed: _guardarEmpresa,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
