import 'package:flutter/material.dart';
import 'package:agenda_fisio_spa_kym/models/empresa_model.dart';
import 'package:agenda_fisio_spa_kym/services/empresa_service.dart';
import 'package:agenda_fisio_spa_kym/screens/empresas/empresa_form.dart';

class EmpresasScreen extends StatefulWidget {
  const EmpresasScreen({Key? key}) : super(key: key);

  @override
  State<EmpresasScreen> createState() => _EmpresasScreenState();
}

class _EmpresasScreenState extends State<EmpresasScreen> {
  final EmpresaService _empresaService = EmpresaService();
  late Future<List<EmpresaModel>> _empresasFuture;

  @override
  void initState() {
    super.initState();
    _empresasFuture = _empresaService.getEmpresas();
  }

  Future<void> _refreshEmpresas() async {
    setState(() {
      _empresasFuture = _empresaService.getEmpresas();
    });
  }

  void _abrirFormulario({EmpresaModel? empresa}) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EmpresaForm(empresaExistente: empresa),
      ),
    );
    _refreshEmpresas();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Empresas'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshEmpresas,
          ),
          IconButton(
            icon: const Icon(Icons.add_business),
            onPressed: () => _abrirFormulario(),
          ),
        ],
      ),
      body: FutureBuilder<List<EmpresaModel>>(
        future: _empresasFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          final empresas = snapshot.data ?? [];

          if (empresas.isEmpty) {
            return const Center(child: Text('No hay empresas registradas.'));
          }

          return ListView.builder(
            itemCount: empresas.length,
            itemBuilder: (context, index) {
              final empresa = empresas[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: ListTile(
                  title: Text(empresa.nombre),
                  subtitle: Text(empresa.rfc),
                  trailing: Text(empresa.estado),
                  onTap: () => _abrirFormulario(empresa: empresa),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
